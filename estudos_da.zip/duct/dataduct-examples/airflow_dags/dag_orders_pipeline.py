from datetime import datetime

from airflow import DAG
from dataduct.integrations.airflow import DataductOperator

with DAG(
    dag_id="dataduct_orders_marketplace_pipeline",
    start_date=datetime(2024, 1, 1),
    schedule="@daily",
    catchup=False,
    tags=["dataduct", "marketplace", "pipeline"],
    doc_md="""
    ## Orders Marketplace Pipeline

    Pipeline multi-step com dependências entre tasks:
    1. `jdbc_to_raw` — extrai orders do PostgreSQL para Raw Zone (Parquet)
    2. `raw_to_curated` — filtra, enriquece e cataloga na Curated Zone

    Usa `{{ ds }}` (execution date do Airflow) como dt_referencia,
    garantindo idempotência e backfill automático.
    """,
) as dag:

    jdbc_to_raw = DataductOperator(
        task_id="orders_jdbc_to_raw",
        job_package_name="examples.orders_marketplace.jdbc_to_raw",
        engine="spark",
        env="dev",
        custom={
            "dt_referencia": "{{ ds }}",
        },
    )

    raw_to_curated = DataductOperator(
        task_id="orders_raw_to_curated",
        job_package_name="examples.orders_marketplace.raw_to_curated",
        engine="spark",
        env="dev",
        custom={
            "dt_referencia": "{{ ds }}",
        },
    )

    jdbc_to_raw >> raw_to_curated
