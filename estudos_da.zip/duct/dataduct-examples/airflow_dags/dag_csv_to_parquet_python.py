from datetime import datetime

from airflow import DAG
from airflow.operators.python import PythonOperator


def run_csv_to_parquet(**context):
    from dataduct.core.job.factory import JobFactory
    from dataduct.engines import load_engine

    config = JobFactory.build_config(
        job_package_name="examples.csv_to_parquet",
        custom={"filter_value": "true"},
    )

    engine = load_engine("duckdb", {"database": ":memory:"})
    try:
        job = JobFactory.get(config, engine=engine)
        job.execute()
    finally:
        engine.stop_session()


with DAG(
    dag_id="dataduct_csv_to_parquet_python",
    start_date=datetime(2024, 1, 1),
    schedule="@daily",
    catchup=False,
    tags=["dataduct", "example"],
    doc_md="""
    ## CSV to Parquet (PythonOperator)

    Executa o job `csv_to_parquet` usando a API programática
    do dataduct diretamente no callable do PythonOperator.
    """,
) as dag:

    run_job = PythonOperator(
        task_id="csv_to_parquet",
        python_callable=run_csv_to_parquet,
    )
