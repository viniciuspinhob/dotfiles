from datetime import datetime

from airflow import DAG
from dataduct.integrations.airflow import DataductOperator

with DAG(
    dag_id="dataduct_csv_to_parquet_custom_op",
    start_date=datetime(2024, 1, 1),
    schedule="@daily",
    catchup=False,
    tags=["dataduct", "example"],
    doc_md="""
    ## CSV to Parquet (DataductOperator)

    Usa o operator customizado do dataduct — abordagem recomendada.
    Suporta template rendering do Airflow nos campos:
    job_package_name, env, custom, engine.
    """,
) as dag:

    run_job = DataductOperator(
        task_id="csv_to_parquet",
        job_package_name="examples.csv_to_parquet",
        engine="duckdb",
        custom={"filter_value": "true"},
    )
