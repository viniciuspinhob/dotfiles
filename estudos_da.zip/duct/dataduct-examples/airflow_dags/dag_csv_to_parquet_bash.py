from datetime import datetime

from airflow import DAG
from airflow.operators.bash import BashOperator

with DAG(
    dag_id="dataduct_csv_to_parquet_bash",
    start_date=datetime(2024, 1, 1),
    schedule="@daily",
    catchup=False,
    tags=["dataduct", "example"],
    doc_md="""
    ## CSV to Parquet (BashOperator)

    Executa o job `csv_to_parquet` via CLI do dataduct.
    Abordagem mais simples — chama o comando diretamente.
    """,
) as dag:

    run_job = BashOperator(
        task_id="csv_to_parquet",
        bash_command=(
            "python -m dataduct run "
            "--job examples.csv_to_parquet "
            "--engine duckdb "
            '--custom \'{"filter_value": "true"}\''
        ),
    )
