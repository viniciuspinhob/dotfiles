"""
Exemplos de uso programático do dataduct sem a CLI.
Útil para:
  - Orquestradores que instanciam jobs diretamente (Airflow, Prefect, etc)
  - Testes de integração em Python
  - Scripts de automação
  - Notebooks de exploração
"""
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


# ─────────────────────────────────────────────
# 1. Execução básica via JobFactory (recomendado)
# ─────────────────────────────────────────────

def exemplo_basico():
    from dataduct.core.job.factory import JobFactory
    from dataduct.engines import load_engine

    config = JobFactory.build_config(
        job_package_name="examples.csv_to_parquet",
        env="dev",
        custom={"filter_value": "true"},
    )

    engine = load_engine("duckdb", {"database": ":memory:"})
    try:
        job = JobFactory.get(config, engine=engine)
        job.execute()
    finally:
        engine.stop_session()


# ─────────────────────────────────────────────
# 2. Execução com Steps (hooks before/after)
# ─────────────────────────────────────────────

def exemplo_com_steps():
    from dataduct.core.job.factory import JobFactory
    from dataduct.engines import load_engine

    config = JobFactory.build_config(
        job_package_name="examples.csv_to_parquet",
        custom={"filter_value": "true"},
    )

    engine = load_engine("duckdb")
    try:
        job = JobFactory.get(config, engine=engine)

        @job.steps.before
        def validar_parametros(j):
            dt = j.custom.get("filter_value")
            if not dt:
                raise ValueError("filter_value é obrigatório")
            logging.info("Parâmetros válidos: filter_value=%s", dt)

        @job.steps.after
        def notificar_conclusao(j):
            logging.info("Job concluído. Sinks: %s", list(j.sinks.keys()))

        job.execute()
    finally:
        engine.stop_session()


# ─────────────────────────────────────────────
# 3. Dry-run: validar config sem executar
# ─────────────────────────────────────────────

def exemplo_dry_run():
    import json
    from dataduct.core.job.factory import JobFactory

    config = JobFactory.build_config(
        job_package_name="examples.csv_to_parquet",
        env="dev",
        custom={"filter_value": "true"},
    )

    print("Config final:")
    print(json.dumps(config, indent=2, default=str))


# ─────────────────────────────────────────────
# 4. Usar engine e connectors diretamente (sem Job)
# ─────────────────────────────────────────────

def exemplo_engine_direta():
    from dataduct.engines import load_engine
    from dataduct.connectors.parquet.extractor import ParquetExtractor
    from dataduct.connectors.parquet.loader import ParquetLoader

    engine = load_engine("duckdb", {"database": ":memory:"})
    try:
        extractor = ParquetExtractor(engine=engine, path="/tmp/input/*.parquet")
        extractor.extract()

        resultado = engine.execute_sql("""
            SELECT cidade, count(*) as total
            FROM df
            GROUP BY cidade
            ORDER BY total DESC
        """)

        loader = ParquetLoader(engine=engine, path="/tmp/output/resultado.parquet", mode="overwrite")
        loader.save(resultado)

    finally:
        engine.stop_session()


# ─────────────────────────────────────────────
# 5. Aplicar masking programaticamente
# ─────────────────────────────────────────────

def exemplo_masking_programatico():
    from dataduct.engines import load_engine
    from dataduct.services.masking import apply_masking

    engine = load_engine("duckdb")
    try:
        dados = engine.execute_sql("""
            SELECT
                '123.456.789-00'     as cpf,
                'joao@email.com'     as email,
                'João Silva'         as nome,
                30                   as idade
        """)

        dados_mascarados = apply_masking(
            data=dados,
            masking_config={
                "provider": "hash",
                "columns": [
                    {"column": "cpf",   "algorithm": "sha256"},
                    {"column": "email", "algorithm": "sha256"},
                ],
            },
            engine=engine,
        )

        rows = dados_mascarados.fetchall()
        cols = [d[0] for d in dados_mascarados.description]
        for row in rows:
            print(dict(zip(cols, row)))

    finally:
        engine.stop_session()


# ─────────────────────────────────────────────
# 6. Múltiplos jobs em sequência (pipeline)
# ─────────────────────────────────────────────

def exemplo_pipeline_sequencial(dt_referencia: str):
    """
    Simula um pipeline completo:
    1. landing_to_raw   → lê CSV da landing, persiste em raw
    2. raw_to_curated   → lê raw, aplica PII masking, persiste em curated

    Em produção, cada job rodaria como step separado no orquestrador.
    """
    from dataduct.core.job.factory import JobFactory
    from dataduct.engines import load_engine

    custom = {"dt_referencia": dt_referencia, "env": "dev"}

    jobs = [
        "examples.landing_to_raw",
        "examples.raw_to_curated_pii",
    ]

    for job_package in jobs:
        logging.info("Iniciando job: %s", job_package)
        config = JobFactory.build_config(job_package, custom=custom, env="dev")
        engine = load_engine(config.get("engine", "duckdb"), config.get("engine_config", {}))
        try:
            job = JobFactory.get(config, engine=engine)
            job.execute()
            logging.info("Job concluído: %s", job_package)
        finally:
            engine.stop_session()


# ─────────────────────────────────────────────
# 7. Registrar novo conector em runtime
# ─────────────────────────────────────────────

def exemplo_custom_connector():
    """
    Registra um conector customizado sem criar arquivos novos.
    Útil para prototipagem rápida ou conectores one-off.
    """
    from dataduct.connectors.base import BaseExtractor
    from dataduct.core.registry import register_connector
    from dataduct.engines import load_engine

    @register_connector("inline", "extractor")
    class InlineExtractor(BaseExtractor):
        """Conector que gera dados inline para testes."""
        def extract(self):
            return self._engine.execute_sql("""
                SELECT * FROM (VALUES
                    (1, 'Alice', 'alice@test.com'),
                    (2, 'Bob',   'bob@test.com'),
                    (3, 'Carol', 'carol@test.com')
                ) t(id, nome, email)
            """)

    engine = load_engine("duckdb")
    try:
        from dataduct.connectors import ExtractorFactory
        extractor = ExtractorFactory.get({"format": "inline"}, engine=engine)
        df = extractor.extract()
        print(df.fetchall())
    finally:
        engine.stop_session()


if __name__ == "__main__":
    print("\n=== 1. Dry-run ===")
    exemplo_dry_run()

    print("\n=== 2. Engine direta ===")
    exemplo_engine_direta()

    print("\n=== 3. Masking programático ===")
    exemplo_masking_programatico()

    print("\n=== 4. Custom connector ===")
    exemplo_custom_connector()
