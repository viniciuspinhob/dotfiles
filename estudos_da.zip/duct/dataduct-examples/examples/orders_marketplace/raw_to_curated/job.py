from dataduct.core.job.base import Job


class OrdersRawToCuratedJob(Job):
    """
    Pipeline: Raw Zone -> Curated Zone

    Reads orders from raw, filters delivered/shipped,
    enriches with processing metadata, and catalogs
    the result in Unity Catalog (curated.marketplace.orders).
    """

    def run(self):
        dt_referencia = self.custom.get("dt_referencia")

        orders_curated = self.engine.execute_sql(f"""
            SELECT
                id_order,
                id_product,
                id_seller,
                buyer_email,
                quantity,
                unit_price,
                total_amount,
                status,
                ordered_at,
                updated_at,
                '{dt_referencia}' AS dt_referencia,
                dt_ingestao,
                current_timestamp AS dt_processamento
            FROM orders_raw
            WHERE status IN ('delivered', 'shipped')
        """)

        self.sinks.orders_curated.save(orders_curated)
