from dataduct.core.job.base import Job


class OrdersJdbcToRawJob(Job):
    """
    Pipeline: PostgreSQL (orders) -> Raw Zone

    Reads all orders from the relational database and persists
    as partitioned Parquet in dataduct-raw.
    """

    def run(self):
        dt_referencia = self.custom.get("dt_referencia")

        orders = self.engine.execute_sql(f"""
            SELECT
                id_order,
                id_product,
                id_seller,
                buyer_email,
                quantity,
                unit_price,
                total_amount,
                status,
                ordered_at,
                updated_at,
                '{dt_referencia}' AS dt_referencia,
                current_timestamp AS dt_ingestao
            FROM orders_db
        """)

        self.sinks.orders_raw.save(orders)
