from dataduct.core.job.base import Job


class LandingToRawJob(Job):
    """
    Pipeline: Landing Zone -> Raw Zone

    Reads raw product data from landing (CSV with ; separator),
    adds technical tracking columns, and persists as Parquet
    partitioned by dt_referencia.

    Masking is applied in the raw->curated step, not here.
    """

    def run(self):
        dt_referencia = self.custom.get("dt_referencia")

        products = self.engine.execute_sql(f"""
            SELECT
                id_product,
                id_seller,
                name,
                description,
                price,
                stock,
                category,
                status,
                created_at,
                updated_at,
                '{dt_referencia}' as dt_referencia,
                current_timestamp as dt_ingestao
            FROM products_landing
        """)

        self.sinks.products_raw.save(products)
