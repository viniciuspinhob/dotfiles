from dataduct.core.job.base import Job


class JdbcToRawJob(Job):
    """
    Pipeline: Relational DB (JDBC) -> Raw Zone

    Reads orders incrementally by time window (dt_referencia)
    and persists as partitioned Parquet.

    Credentials via env vars:
      DB_USER / DB_PASS       (prod)
      DEV_DB_USER / DEV_DB_PASS (dev)

    For AWS environments, use SSM:
      credentials:
        type: ssm
        user_param: "/prod/marketplace/db/username"
        password_param: "/prod/marketplace/db/password"
    """

    def run(self):
        dt_referencia = self.custom.get("dt_referencia")

        orders = self.engine.execute_sql(f"""
            SELECT
                id_order,
                id_product,
                id_seller,
                buyer_email,
                quantity,
                unit_price,
                total_amount,
                status,
                ordered_at,
                updated_at,
                '{dt_referencia}' as dt_referencia,
                current_timestamp as dt_ingestao
            FROM orders_db
        """)

        self.sinks.orders_raw.save(orders)
