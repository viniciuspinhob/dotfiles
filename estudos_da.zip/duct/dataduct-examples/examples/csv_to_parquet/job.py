from dataduct.core.job.base import Job


class CsvToParquetJob(Job):
    def run(self):
        filter_value = self.custom.get("filter_value", "true")

        active_users = self.engine.execute_sql(
            f"SELECT * FROM users WHERE active = '{filter_value}'"
        )

        self.sinks.active_users.save(active_users)
