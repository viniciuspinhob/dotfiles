from dataduct.core.job.base import Job


class RawToCuratedPiiJob(Job):
    """
    Pipeline: Raw Zone -> Curated Zone (with PII anonymisation)

    The masking (email -> SHA256) is applied declaratively via
    config.yaml BEFORE job.run() is called.
    self.sources.sellers_raw already arrives with masked data.

    Responsibilities:
    - Enrich with technical columns (dt_processamento, schema_version)
    - Filter inactive sellers
    - Save to Curated partitioned by dt_referencia
    - Glue cataloguing happens automatically after save (via config.yaml)
    """

    def run(self):
        dt_referencia = self.custom.get("dt_referencia")

        sellers_curated = self.engine.execute_sql(f"""
            SELECT
                id_seller,
                name,
                email,
                category,
                rating,
                active,
                created_at,
                updated_at,
                dt_referencia,
                dt_ingestao,
                current_timestamp as dt_processamento,
                '1.0'             as schema_version
            FROM sellers_raw
            WHERE active = true
              AND dt_referencia = '{dt_referencia}'
        """)

        self.sinks.sellers_curated.save(sellers_curated)
