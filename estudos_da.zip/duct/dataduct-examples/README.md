# dataduct-examples

Exemplos práticos de jobs dataduct baseados nos padrões de Data Lake.

## Pré-requisitos

1. **dataduct** instalado: `pip install -e /path/to/dataduct[all]`
2. **dataduct-examples** instalado: `pip install -e /path/to/dataduct-examples`
3. **duct_infra** rodando (para exemplos que usam serviços): `cd /path/to/duct_infra && make up`

## Estrutura

```
dataduct-examples/
├── examples/                # pacote Python instalável (pip install -e .)
│   ├── csv_to_parquet/      # CSV → Parquet com filtro (DuckDB)
│   ├── landing_to_raw/      # Landing Zone → Raw Zone (Spark)
│   ├── raw_to_curated_pii/  # Raw → Curated com masking PII
│   ├── jdbc_to_raw/         # Banco relacional (JDBC) → Raw Zone
│   ├── orders_marketplace/  # Pipeline multi-etapa (JDBC → Raw → Curated)
│   └── data/                # Dados de exemplo
├── api_programatica/        # Como usar a API Python sem a CLI
├── airflow_dags/            # Exemplos de DAGs para Apache Airflow
└── pyproject.toml
```

## Fluxo do Data Lake

```
              [JDBC / CSV / API]
                    ↓
           ┌─────────────────┐
           │   Landing Zone  │  (dados brutos, qualquer formato)
           └────────┬────────┘
                    │  landing_to_raw
                    ↓
           ┌─────────────────┐
           │    Raw Zone     │  (Parquet, de-identificado, particionado)
           └────────┬────────┘
                    │  raw_to_curated_pii
                    ↓
           ┌─────────────────┐
           │  Curated Zone   │  (Parquet, PII mascarado, catalogado)
           └─────────────────┘
```

## Como executar

```bash
# Instalar dependência
pip install -e /path/to/dataduct[all]

# csv_to_parquet (DuckDB, sem infra externa)
python -m dataduct run --job examples.csv_to_parquet --engine duckdb

# landing_to_raw (Spark, modo dev)
python -m dataduct run --job examples.landing_to_raw --env dev --engine spark

# raw_to_curated_pii (modo dev)
python -m dataduct run --job examples.raw_to_curated_pii --env dev --engine duckdb

# jdbc_to_raw (requer PostgreSQL via duct_infra)
python -m dataduct run --job examples.jdbc_to_raw --env dev --engine spark

# API programática
python api_programatica/exemplos.py
```

## Configuração por ambiente

| Arquivo | Ambiente | Engine | Destino |
|---------|----------|--------|---------|
| `config.yaml` | prod | Spark | S3 real |
| `config-dev.yaml` | dev | DuckDB ou Spark local | /tmp local |

Override via CLI:
```bash
python -m dataduct run --job examples.landing_to_raw --env dev --engine duckdb
python -m dataduct run --job examples.landing_to_raw --env dev -c '{"dt_referencia": "2024-06-15"}'
```

## Airflow

Exemplos de integração com Apache Airflow (2.7+):

```bash
# Instalar suporte Airflow
pip install dataduct[airflow]
```

| DAG | Abordagem | Descrição |
|-----|-----------|-----------|
| `dag_csv_to_parquet_bash.py` | BashOperator | Chama CLI diretamente |
| `dag_csv_to_parquet_python.py` | PythonOperator | Usa API programática |
| `dag_csv_to_parquet_custom.py` | DataductOperator | Operator customizado (recomendado) |
| `dag_orders_pipeline.py` | DataductOperator | Pipeline multi-step com dependências |

Para usar, copie os DAGs para seu `$AIRFLOW_HOME/dags/` ou configure o `dags_folder`.

### DataductOperator

O operator customizado suporta template rendering do Airflow:

```python
from dataduct.integrations.airflow import DataductOperator

DataductOperator(
    task_id="landing_to_raw",
    job_package_name="examples.orders_marketplace.jdbc_to_raw",
    engine="spark",
    env="dev",
    custom={"dt_referencia": "{{ ds }}"},
)
```

Campos com template rendering: `job_package_name`, `env`, `custom`, `engine`.
