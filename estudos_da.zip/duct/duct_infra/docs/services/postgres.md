# PostgreSQL

OLTP relational database. Serves as both the **data source** (pipelines read from it via JDBC) and the **Airflow metadata store**.

---

## Quick Access

| Property | Value |
|----------|-------|
| Host (from host machine) | `localhost:5432` |
| Host (from inside Docker) | `postgres:5432` |
| Database (marketplace) | `marketplace_dev` |
| Database (airflow) | `airflow` |
| User | `dataduct` |
| Password | `dataduct123` |
| Image | `postgres:15-alpine` |
| Container name | `dataduct-postgres` |
| Docker profile | `postgres`, `storage`, `query`, `airflow`, `dev`, `all` |

---

## Start Independently

```bash
docker compose --profile postgres up -d
```

Check health:
```bash
docker compose ps postgres
# STATUS should show "(healthy)"
```

---

## Connect

### psql (interactive shell)
```bash
# From your host machine
docker compose exec postgres psql -U dataduct -d marketplace_dev

# From any container on dataduct-net
psql -h postgres -U dataduct -d marketplace_dev
```

### From a GUI (TablePlus, DBeaver, DataGrip)
```
Host:     localhost
Port:     5432
Database: marketplace_dev
User:     dataduct
Password: dataduct123
```

### JDBC URL
```
# From host machine
jdbc:postgresql://localhost:5432/marketplace_dev

# From inside Docker
jdbc:postgresql://postgres:5432/marketplace_dev
```

---

## Databases

| Database | Purpose |
|----------|---------|
| `marketplace_dev` | Sample marketplace data — source for ETL pipelines |
| `airflow` | Airflow metadata (DAG runs, task state, connections) |

---

## Schema — marketplace_dev

The database is seeded automatically on first start via `docker/postgres/01-marketplace-seed.sql`.

### Tables

#### `seller`
| Column | Type | Description |
|--------|------|-------------|
| id_seller | SERIAL PK | Auto-increment ID |
| name | VARCHAR(100) | Seller name |
| email | VARCHAR(150) | Unique email |
| category | VARCHAR(50) | Business category |
| rating | DECIMAL(3,2) | Average rating (0–5) |
| active | BOOLEAN | Account status |
| created_at | TIMESTAMP | Creation timestamp |
| updated_at | TIMESTAMP | Last update |

#### `product`
| Column | Type | Description |
|--------|------|-------------|
| id_product | SERIAL PK | Auto-increment ID |
| id_seller | INTEGER FK | References seller |
| name | VARCHAR(200) | Product name |
| description | TEXT | Full description |
| price | DECIMAL(12,2) | Unit price |
| stock | INTEGER | Available units |
| category | VARCHAR(50) | Product category |
| status | VARCHAR(20) | `active` / `inactive` |

#### `orders`
| Column | Type | Description |
|--------|------|-------------|
| id_order | SERIAL PK | Auto-increment ID |
| id_product | INTEGER FK | References product |
| id_seller | INTEGER FK | References seller |
| buyer_email | VARCHAR(150) | Buyer contact |
| quantity | INTEGER | Units ordered |
| unit_price | DECIMAL(12,2) | Price at time of order |
| total_amount | DECIMAL(12,2) | quantity × unit_price |
| status | VARCHAR(20) | `pending` / `shipped` / `delivered` |
| ordered_at | TIMESTAMP | Order creation time |
| updated_at | TIMESTAMP | Last update |

### Sample counts
- 10 sellers
- 15 products
- 30 orders (Jan–Feb 2024)

---

## Configuration Files

| File | Purpose |
|------|---------|
| `docker/postgres/00-create-airflow-db.sql` | Creates the `airflow` database |
| `docker/postgres/01-marketplace-seed.sql` | Creates and seeds marketplace tables |

Both files are mounted as init scripts and run automatically on first container start.

---

## Environment Variables

Set via `.env` (defaults shown):

```bash
POSTGRES_DB=marketplace_dev
POSTGRES_USER=dataduct
POSTGRES_PASSWORD=dataduct123
```

---

## Common Operations

```bash
# List all tables
docker compose exec postgres psql -U dataduct -d marketplace_dev -c "\dt"

# Quick row count
docker compose exec postgres psql -U dataduct -d marketplace_dev \
  -c "SELECT 'seller' AS t, COUNT(*) FROM seller
      UNION ALL SELECT 'product', COUNT(*) FROM product
      UNION ALL SELECT 'orders', COUNT(*) FROM orders;"

# View recent orders
docker compose exec postgres psql -U dataduct -d marketplace_dev \
  -c "SELECT id_order, buyer_email, total_amount, status FROM orders ORDER BY ordered_at DESC LIMIT 5;"

# Airflow metadata DB
docker compose exec postgres psql -U dataduct -d airflow -c "\dt"
```

---

## Interactions

| Consumer | How | Purpose |
|----------|-----|---------|
| `dataduct-dev` | JDBC (`postgres:5432`) | Read marketplace tables as pipeline source |
| `trino` | JDBC connector (`postgresql` catalog) | Federated SQL queries |
| `cloudbeaver` | JDBC | Interactive SQL via web IDE |
| `airflow-*` | SQLAlchemy | DAG run state, task history, connections |

---

## Resetting Data

Data persists in the `postgres_data` Docker volume. To wipe and re-seed from scratch:

```bash
make down          # stops containers AND removes volumes
make up            # recreates everything with fresh seed data
```

> **Warning:** `make down` removes ALL volumes including MinIO and Unity Catalog data.

To reset only PostgreSQL:
```bash
docker compose stop postgres
docker volume rm dataduct-dev_postgres_data
docker compose --profile postgres up -d
```

---

## Troubleshooting

**Container exits immediately on start:**
Check logs:
```bash
docker compose logs postgres
```
Usually caused by a corrupted volume. Run:
```bash
docker volume rm dataduct-dev_postgres_data
docker compose --profile postgres up -d
```

**Connection refused from host:**
Verify the container is healthy:
```bash
docker compose ps postgres
```
Port 5432 must not be in use by a local PostgreSQL instance.

**Init scripts not running:**
Init scripts only run when the data directory is empty (first start). After the first start, they are skipped even if you change the files. Run `make down` to reset.
