# Unity Catalog

Open-source data catalog that stores **metadata** for all curated datasets. Pipelines register tables here after writing files to MinIO. Trino uses Unity Catalog as an Iceberg REST catalog to query those tables.

---

## Quick Access

| Property | Value |
|----------|-------|
| REST API (from host) | `http://localhost:8080` |
| REST API (from Docker) | `http://unity-catalog:8080` or `http://server:8080` |
| REST API base path | `/api/2.1/unity-catalog/` |
| Iceberg REST endpoint | `/api/2.1/unity-catalog/iceberg` |
| Web UI | `http://localhost:3000` |
| Authentication | None (open by default) |
| Image | `unitycatalog/unitycatalog:latest` |
| Container name | `dataduct-unity-catalog` |
| Docker profile | `catalog`, `query`, `dev`, `all` |

> The `server` alias is required for the Iceberg REST client inside Trino (it resolves catalog token URLs using this alias).

---

## Start Independently

```bash
# Starts Unity Catalog + bootstrap + UI
docker compose --profile catalog up -d

# Without the UI
docker compose up -d unity-catalog unity-catalog-init
```

---

## Catalog Structure

Created automatically by `unity-catalog-init` on first start:

```
dataduct_curated
├── marketplace      ← curated pipeline output tables
└── default

dataduct_analytics
└── default
```

---

## REST API

### List catalogs
```bash
curl http://localhost:8080/api/2.1/unity-catalog/catalogs
```

### List schemas in a catalog
```bash
curl http://localhost:8080/api/2.1/unity-catalog/schemas?catalog_name=dataduct_curated
```

### List tables in a schema
```bash
curl http://localhost:8080/api/2.1/unity-catalog/tables?catalog_name=dataduct_curated&schema_name=marketplace
```

### Get table details
```bash
curl http://localhost:8080/api/2.1/unity-catalog/tables/dataduct_curated.marketplace.orders_enriched
```

### Create a catalog
```bash
curl -X POST http://localhost:8080/api/2.1/unity-catalog/catalogs \
  -H "Content-Type: application/json" \
  -d '{"name": "my_catalog", "comment": "My catalog"}'
```

### Create a schema
```bash
curl -X POST http://localhost:8080/api/2.1/unity-catalog/schemas \
  -H "Content-Type: application/json" \
  -d '{"name": "my_schema", "catalog_name": "dataduct_curated", "comment": "My schema"}'
```

### Delete a table
```bash
curl -X DELETE http://localhost:8080/api/2.1/unity-catalog/tables/dataduct_curated.marketplace.orders_enriched
```

---

## Web UI

1. Open `http://localhost:3000`
2. Browse catalogs, schemas, and tables
3. View column definitions, metadata, and storage locations

The UI connects to the API at `http://localhost:8080` (configured via `REACT_APP_UNITY_CATALOG_URL`).

---

## Configuration Files

| File | Purpose |
|------|---------|
| `docker/unity-catalog/bootstrap.sh` | Creates initial catalogs and schemas via REST |
| `docker/unity-catalog/etc/conf/` | Unity Catalog server config and auth keys |

---

## Environment Variables

None required — Unity Catalog uses no authentication by default.

---

## How Pipelines Register Tables

After writing curated parquet files to MinIO, pipelines call the Unity Catalog REST API to register the table:

```python
import requests

requests.post(
    "http://unity-catalog:8080/api/2.1/unity-catalog/tables",
    json={
        "name": "orders_enriched",
        "catalog_name": "dataduct_curated",
        "schema_name": "marketplace",
        "table_type": "EXTERNAL",
        "data_source_format": "PARQUET",
        "storage_location": "s3://dataduct-curated/marketplace/orders_enriched/",
        "columns": [...],
    }
)
```

---

## Interactions

| Consumer | How | Purpose |
|----------|-----|---------|
| `dataduct-dev` | REST API (`unity-catalog:8080`) | Register curated tables after pipeline runs |
| `trino` | Iceberg REST (`unity-catalog:8080/api/2.1/unity-catalog/iceberg`) | Read table metadata for `unity_catalog` catalog |
| `unity-catalog-ui` | REST API (`unity-catalog:8080`) | Browse catalogs in browser |
| `unity-catalog-init` | REST API (`unity-catalog:8080`) | Bootstrap initial catalogs/schemas on first start |

---

## Adding a New Catalog or Schema

**Via REST API:**
```bash
# New catalog
curl -X POST http://localhost:8080/api/2.1/unity-catalog/catalogs \
  -H "Content-Type: application/json" \
  -d '{"name": "my_new_catalog"}'

# New schema inside that catalog
curl -X POST http://localhost:8080/api/2.1/unity-catalog/schemas \
  -H "Content-Type: application/json" \
  -d '{"name": "my_schema", "catalog_name": "my_new_catalog"}'
```

**To make it persistent (survive `make down`):**
Add the catalog/schema to `docker/unity-catalog/bootstrap.sh`.

---

## Troubleshooting

**UI shows "Cannot connect to server":**
The UI uses `http://localhost:8080` from the browser. If Unity Catalog is not running or port 8080 is blocked, the UI will fail. Check:
```bash
curl http://localhost:8080/api/2.1/unity-catalog/catalogs
docker compose ps unity-catalog
```

**Tables registered but not visible in Trino:**
Trino caches schema metadata. Force a refresh:
```sql
-- In Trino
SHOW SCHEMAS FROM unity_catalog;
```
If the table still doesn't appear, check that the `storage_location` in Unity Catalog points to a valid MinIO path.

**Init container failed:**
The bootstrap only runs after Unity Catalog is healthy (takes ~30s on first start). Check logs:
```bash
docker compose logs unity-catalog-init
docker compose logs unity-catalog
```
