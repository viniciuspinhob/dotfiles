# Apache Airflow

Pipeline orchestration platform. DAGs written locally are uploaded to MinIO, synced to Airflow, and executed via `DataductOperator` — which runs dataduct jobs in-process on the Airflow scheduler (LocalExecutor).

---

## Quick Access

| Property | Value |
|----------|-------|
| Web UI | `http://localhost:8082` |
| Admin user | `airflow` |
| Admin password | `airflow123` |
| Executor | `LocalExecutor` |
| Image | Custom (`apache/airflow:2.10.5-python3.11`) |
| Webserver container | `dataduct-airflow-webserver` |
| Scheduler container | `dataduct-airflow-scheduler` |
| Docker profile | `airflow`, `all` |

---

## Start

```bash
# Full Airflow stack (postgres + minio + all airflow services)
docker compose --profile airflow up -d
```

First start takes a few minutes: Airflow runs DB migrations, creates the admin user, and sets up connections.

Check status:
```bash
docker compose ps | grep airflow
# airflow-init should be "Exited (0)"
# airflow-webserver and airflow-scheduler should be "healthy" / "running"
```

---

## Components

| Container | Role |
|-----------|------|
| `airflow-init` | One-shot: runs `airflow db migrate`, creates admin user and connections |
| `airflow-webserver` | Serves the Airflow UI on port 8082 |
| `airflow-scheduler` | Parses DAGs and executes tasks |
| `airflow-dag-upload` | One-shot: mirrors local `dags/` to MinIO bucket `dataduct-dags` |
| `airflow-dag-sync` | Long-running: polls MinIO every 30s and syncs DAGs to the shared volume |

---

## Pre-configured Connections

Airflow connections are created by `airflow-init`:

| Connection ID | Type | Target |
|--------------|------|--------|
| `postgres_marketplace` | PostgreSQL | `postgres:5432/marketplace_dev` |
| `minio_s3` | AWS (S3) | `http://minio:9000` |

---

## DAG Development Workflow

1. Write or edit a DAG file in the local `dags/` directory
2. Upload to MinIO:
   ```bash
   make dags-upload
   ```
3. Wait up to 30 seconds — `airflow-dag-sync` will pick up the change
4. Open `http://localhost:8082` to see the DAG

### Trigger a DAG run manually

```bash
# Via CLI inside the scheduler
docker compose exec airflow-scheduler airflow dags trigger orders_marketplace_pipeline

# Or from the UI: click the DAG, then the ▶ button
```

### Check task logs

```bash
# Follow scheduler logs
make airflow-logs

# Or open the UI, click on a DAG run → task → Logs tab
```

---

## Shell Access

```bash
# Open a shell in the scheduler (where tasks execute)
make airflow-shell
# or:
docker compose exec airflow-scheduler bash

# Useful commands inside the shell
airflow dags list
airflow tasks list orders_marketplace_pipeline
airflow dags test orders_marketplace_pipeline 2024-01-01
```

---

## Example DAG — orders_marketplace_pipeline

Located at `dags/orders_marketplace_pipeline.py`.

```
orders_marketplace_pipeline
├── jdbc_to_raw      (DataductOperator)
│   └── reads PostgreSQL tables → writes parquet to s3://dataduct-raw/
└── raw_to_curated   (DataductOperator)
    └── reads dataduct-raw → transforms → writes to s3://dataduct-curated/
        └── registers table in Unity Catalog
```

Tasks run in-process on the Airflow scheduler. The scheduler container mounts `dataduct` and `dataduct-examples` and installs them in editable mode on startup.

### DAG config (`dags/orders_marketplace_pipeline.py`)

| Setting | Value |
|---------|-------|
| Operator | `DataductOperator` |
| Job packages | `examples.orders_marketplace.jdbc_to_raw`, `examples.orders_marketplace.raw_to_curated` |
| Schedule | `@daily` |
| Start date | `2024-01-01` |
| Catchup | `false` |

---

## Configuration Files

| File | Purpose |
|------|---------|
| `docker/airflow/Dockerfile` | Airflow image + Java 21 + Spark/JDBC jars + dataduct runtime deps |
| `docker/airflow/requirements.txt` | Providers: postgres, amazon; pyspark, duckdb, boto3 |
| `dags/orders_marketplace_pipeline.py` | Example pipeline DAG (`DataductOperator`) |

---

## Environment Variables

Set via `.env` (defaults shown):

```bash
AIRFLOW_ADMIN_USER=airflow
AIRFLOW_ADMIN_PASSWORD=airflow123
AIRFLOW__CORE__FERNET_KEY=zTfXqFcc0y0FZ3q2MvABCDeFgHiJkLmNoPqRsTuVwXy=
POSTGRES_USER=dataduct
POSTGRES_PASSWORD=dataduct123
MINIO_ROOT_USER=minioadmin
MINIO_ROOT_PASSWORD=minioadmin123
```

The scheduler container mounts `../dataduct` and `../dataduct-examples` and installs them on startup. Pipeline tasks use the same env vars as `dataduct-dev` (`DEV_DB_USER`, `AWS_ENDPOINT_URL`, etc.).

---

## Interactions

| Talks to | How | Purpose |
|----------|-----|---------|
| `postgres` | SQLAlchemy (`postgres:5432/airflow`) | DAG run state, task history, variables, connections |
| `postgres` | JDBC (`postgres:5432/marketplace_dev`) | Pipeline source data via `DataductOperator` tasks |
| `minio` | boto3 / Spark S3A | DAG file sync; pipeline raw/curated zone I/O |
| `unity-catalog` | REST API | Catalog registration from curated sink |
| `dataduct-net` | Docker networking | Scheduler reaches all services on the shared network |

---

## Rebuilding the Airflow Image

When you change `docker/airflow/Dockerfile` or `requirements.txt`:

```bash
docker compose build airflow-webserver airflow-scheduler airflow-init
docker compose --profile airflow up -d
```

---

## Troubleshooting

**DAG not appearing in UI after upload:**
- Check that `dags-upload` completed: `docker compose logs airflow-dag-upload`
- Wait 30 seconds for sync
- Check sync logs: `docker compose logs airflow-dag-sync`
- Verify DAG has no syntax errors: `docker compose exec airflow-scheduler airflow dags list`

**Task stuck in "queued" state:**
The scheduler must be running. Check:
```bash
docker compose ps airflow-scheduler
docker compose logs airflow-scheduler
```

**Task fails with `ModuleNotFoundError: examples` or `dataduct`:**
The scheduler installs packages on startup. Check scheduler logs for pip errors:
```bash
docker compose logs airflow-scheduler | head -50
```

**Spark / JDBC errors in pipeline tasks:**
Verify JDBC jars exist at `/opt/jars/` inside the scheduler and that `config-dev.yaml` overlays use Docker hostnames (`postgres`, `minio`, `unity-catalog`).

**Airflow init container exits with non-zero code:**
PostgreSQL must be healthy before init runs. Check:
```bash
docker compose logs airflow-init
docker compose ps postgres
```

**Fernet key warning or decryption errors:**
The Fernet key in `.env` must remain the same across restarts or encrypted connection passwords will break. Never change `AIRFLOW__CORE__FERNET_KEY` after the first run.
