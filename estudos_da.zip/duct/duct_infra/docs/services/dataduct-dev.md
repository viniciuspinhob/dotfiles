# dataduct-dev

The primary compute container for running ETL pipelines locally. It comes pre-installed with Python 3.11, OpenJDK 21, PySpark, DuckDB, PyArrow, and boto3, and is configured to reach all other services by their Docker network hostnames.

---

## Quick Access

| Property | Value |
|----------|-------|
| Shell | `docker compose exec dataduct-dev bash` |
| Working directory | `/app` → mounts `../dataduct` |
| Examples directory | `/examples` → mounts `../dataduct-examples` |
| Image | Custom build: `dataduct-dev:latest` |
| Container name | `dataduct-dev` |
| Docker profile | `dev`, `all` |

---

## Start

```bash
# Dev container + all dependencies (postgres + minio + unity-catalog)
docker compose --profile dev up -d
```

The container takes ~30 seconds to start because it installs `dataduct[all]` and `dataduct-examples` in editable mode before becoming idle.

Check readiness:
```bash
docker compose logs dataduct-dev | tail -5
# Should show: "dataduct-dev ready"
```

---

## Open a Shell

```bash
make shell
# or:
docker compose exec dataduct-dev bash
```

---

## Runtime Environment

All service connections are pre-configured via environment variables:

| Variable | Value | Purpose |
|----------|-------|---------|
| `POSTGRES_HOST` | `postgres` | PostgreSQL hostname |
| `POSTGRES_PORT` | `5432` | PostgreSQL port |
| `POSTGRES_DB` | `marketplace_dev` | Database name |
| `DEV_DB_USER` | `dataduct` | Database user |
| `DEV_DB_PASS` | `dataduct123` | Database password |
| `AWS_ACCESS_KEY_ID` | `minioadmin` | MinIO access key |
| `AWS_SECRET_ACCESS_KEY` | `minioadmin123` | MinIO secret key |
| `AWS_ENDPOINT_URL` | `http://minio:9000` | MinIO endpoint |
| `AWS_DEFAULT_REGION` | `us-east-1` | AWS region (any value works for MinIO) |
| `UNITY_CATALOG_HOST` | `http://unity-catalog:8080` | Unity Catalog REST API |
| `JAVA_HOME` | `/usr/lib/jvm/java-21-openjdk-arm64` | Java home for PySpark |
| `PYSPARK_PYTHON` | `python3` | Python interpreter for PySpark workers |

---

## JDBC Drivers

The following drivers are pre-installed at `/opt/jars/`:

| Driver | Version | Purpose |
|--------|---------|---------|
| `postgresql-42.7.2.jar` | 42.7.2 | JDBC connection to PostgreSQL |
| `hadoop-aws-3.3.4.jar` | 3.3.4 | S3 filesystem for PySpark |
| `aws-java-sdk-bundle-1.12.262.jar` | 1.12.262 | AWS SDK for S3 access |

---

## Running Pipelines

### Inside the container

```bash
# Open shell
make shell

# Run a pipeline job
python -m dataduct run --job examples.orders_marketplace.jdbc_to_raw

# With a specific engine
python -m dataduct run --job examples.orders_marketplace.jdbc_to_raw --engine duckdb

# With a dev overlay config
python -m dataduct run --job examples.orders_marketplace.jdbc_to_raw --env dev

# With custom parameters
python -m dataduct run --job examples.orders_marketplace.jdbc_to_raw \
  -c '{"dt_referencia": "2024-01-15"}'

# Dry run (validate config only)
python -m dataduct run --job examples.orders_marketplace.jdbc_to_raw --dry-run
```

### From the host machine (without opening a shell)

```bash
docker compose exec dataduct-dev \
  python -m dataduct run --job examples.orders_marketplace.jdbc_to_raw
```

---

## Mounted Directories

| Mount | Container path | Source |
|-------|---------------|--------|
| dataduct library | `/app` | `../dataduct` (sibling repo) |
| example pipelines | `/examples` | `../dataduct-examples` (sibling repo) |

Both are installed in editable mode (`pip install -e`) on container start, so changes to source files take effect immediately without rebuilding.

### Mounting your own job repository

Add a volume to `docker-compose.yml`:

```yaml
services:
  dataduct-dev:
    volumes:
      - ../dataduct:/app
      - ../dataduct-examples:/examples
      - /path/to/my-jobs:/my-jobs    # add this
```

Then inside the container:
```bash
pip install -e /my-jobs
python -m dataduct run --job my_domain.my_job --env dev
```

---

## Connection Strings (from inside container)

| Service | Connection |
|---------|-----------|
| PostgreSQL (JDBC) | `jdbc:postgresql://postgres:5432/marketplace_dev` |
| MinIO (S3) | `s3://dataduct-raw/` via `http://minio:9000` |
| Unity Catalog | `http://unity-catalog:8080/api/2.1/unity-catalog/` |
| Trino | `http://trino:8080` |

---

## Python Dependencies

Installed via `docker/dataduct-dev/requirements.txt`:

```
pyspark
duckdb
pyarrow
boto3
requests
```

Additional packages installed at container start:
- `dataduct[all]` (editable from `/app`)
- `dataduct-examples` (editable from `/examples`, optional)

---

## Dockerfile

```
Base image: python:3.11-slim
JDK:        openjdk-21-jdk-headless
JDBC jars:  /opt/jars/
Workdir:    /app
```

---

## Rebuild the Image

After changing `Dockerfile` or `requirements.txt`:

```bash
docker compose build dataduct-dev
docker compose --profile dev up -d
```

---

## Running Tests (Integration)

```bash
# Open shell
make shell

# Run integration tests against real services
pytest /examples/tests/ -v

# Or run unit tests from the dataduct library
pytest /app/tests/ -v
```

---

## Interactions

| Talks to | How | Purpose |
|----------|-----|---------|
| `postgres` | JDBC (`postgres:5432`) | Read source tables, write JDBC sinks |
| `minio` | boto3 / S3 API (`minio:9000`) | Read raw layer, write curated parquet |
| `unity-catalog` | REST API (`unity-catalog:8080`) | Register curated tables after pipeline runs |
| `trino` | Trino DBAPI (`trino:8080`) | Optional: query federated data |

---

## Troubleshooting

**Container starts but pipelines fail with "No module named dataduct":**
The editable install may have failed. Check container logs:
```bash
docker compose logs dataduct-dev
```
Then reinstall manually:
```bash
docker compose exec dataduct-dev pip install -e '/app[all]'
```

**PySpark fails with "Java not found":**
`JAVA_HOME` is set to `/usr/lib/jvm/java-21-openjdk-arm64` (ARM). On x86 machines, the path differs:
```bash
docker compose exec dataduct-dev java -version
docker compose exec dataduct-dev which java
```
Update `JAVA_HOME` in `docker-compose.yml` to match the actual path.

**S3 / MinIO permission errors from PySpark:**
PySpark needs the S3A jars on its classpath. Pass them via `spark.jars`:
```python
from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .config("spark.jars", "/opt/jars/hadoop-aws-3.3.4.jar,/opt/jars/aws-java-sdk-bundle-1.12.262.jar") \
    .config("spark.hadoop.fs.s3a.endpoint", "http://minio:9000") \
    .config("spark.hadoop.fs.s3a.access.key", "minioadmin") \
    .config("spark.hadoop.fs.s3a.secret.key", "minioadmin123") \
    .config("spark.hadoop.fs.s3a.path.style.access", "true") \
    .getOrCreate()
```

**Changes to source files not picked up:**
Both `/app` and `/examples` are bind mounts — changes on the host are reflected instantly inside the container. If you added a new file to the package, you may need to reinstall:
```bash
docker compose exec dataduct-dev pip install -q -e '/app[all]'
```
