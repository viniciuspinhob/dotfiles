# MinIO

S3-compatible object storage that serves as the **data lake** for all pipeline layers. All parquet and delta files written by pipelines live here.

---

## Quick Access

| Property | Value |
|----------|-------|
| API endpoint (from host) | `http://localhost:19000` |
| API endpoint (from Docker) | `http://minio:9000` |
| Console UI | `http://localhost:19001` |
| Access Key | `minioadmin` |
| Secret Key | `minioadmin123` |
| Image | `minio/minio:latest` |
| Container name | `dataduct-minio` |
| Docker profile | `minio`, `storage`, `query`, `airflow`, `dev`, `all` |

---

## Start Independently

```bash
# Starts MinIO + bucket bootstrap
docker compose --profile minio up -d
```

Wait for health:
```bash
docker compose ps minio
# STATUS should show "(healthy)"
```

---

## Buckets

Created automatically by `minio-init` on first start:

| Bucket | Purpose |
|--------|---------|
| `dataduct-landing` | Raw ingestion zone — files dropped before any processing |
| `dataduct-raw` | Stage 1 output — parquet files written by `jdbc_to_raw` |
| `dataduct-curated` | Stage 2 output — cleaned/enriched parquet written by `raw_to_curated` |
| `dataduct-dags` | Airflow DAG files synced from local `dags/` directory |

---

## Access via Console UI

1. Open `http://localhost:19001`
2. Login: `minioadmin` / `minioadmin123`
3. Navigate **Buckets** to browse files

---

## Access via AWS CLI / boto3

MinIO is fully S3-compatible. Use it with any AWS SDK by pointing to the local endpoint:

```bash
# AWS CLI
aws s3 ls s3://dataduct-raw/ \
  --endpoint-url http://localhost:19000 \
  --no-sign-request \
  --region us-east-1
```

```python
import boto3

s3 = boto3.client(
    "s3",
    endpoint_url="http://localhost:19000",
    aws_access_key_id="minioadmin",
    aws_secret_access_key="minioadmin123",
    region_name="us-east-1",
)

objects = s3.list_objects_v2(Bucket="dataduct-raw")
for obj in objects.get("Contents", []):
    print(obj["Key"])
```

---

## Access via mc (MinIO CLI)

```bash
# Set up alias
mc alias set local http://localhost:19000 minioadmin minioadmin123

# List buckets
mc ls local/

# List files in raw bucket
mc ls local/dataduct-raw/

# Download a file
mc cp local/dataduct-raw/marketplace/orders/part-0.parquet ./orders.parquet

# Upload a file
mc cp ./myfile.parquet local/dataduct-landing/myfile.parquet
```

---

## Environment Variables

Set via `.env` (defaults shown):

```bash
MINIO_ROOT_USER=minioadmin
MINIO_ROOT_PASSWORD=minioadmin123
MINIO_BUCKET_LANDING=dataduct-landing
MINIO_BUCKET_RAW=dataduct-raw
MINIO_BUCKET_CURATED=dataduct-curated
MINIO_BUCKET_DAGS=dataduct-dags
```

Variables consumed by pipeline code (from host or inside Docker):

```bash
# From host machine
AWS_ACCESS_KEY_ID=minioadmin
AWS_SECRET_ACCESS_KEY=minioadmin123
AWS_ENDPOINT_URL=http://localhost:19000
AWS_DEFAULT_REGION=us-east-1

# From inside Docker
AWS_ENDPOINT_URL=http://minio:9000
```

---

## Configuration Files

| File | Purpose |
|------|---------|
| `docker/minio/bootstrap.sh` | Creates the 4 buckets on first start |

---

## Common Operations

```bash
# Check MinIO status from inside the container
docker compose exec minio mc ready local

# List all objects in curated bucket
docker compose exec minio mc ls --recursive local/dataduct-curated/

# Wipe a specific bucket (careful!)
docker compose exec minio mc rm --recursive --force local/dataduct-raw/
```

---

## Interactions

| Consumer | How | Purpose |
|----------|-----|---------|
| `dataduct-dev` | S3 API (`minio:9000`) | Write pipeline output (raw, curated) |
| `trino` | S3 API (`minio:9000`) | Read Delta Lake files (`delta` catalog) and Iceberg files (`unity_catalog` catalog) |
| `airflow-dag-upload` | mc client | Push DAG files from local `dags/` to `dataduct-dags` bucket |
| `airflow-dag-sync` | mc client | Pull DAG files from `dataduct-dags` to Airflow shared volume |
| `airflow-scheduler` | boto3 / Spark S3A | Pipeline I/O during `DataductOperator` runs |

---

## Data Layout Convention

Pipelines write files following this path pattern:

```
s3://<bucket>/<domain>/<entity>/<partitions>/
```

Example:
```
s3://dataduct-raw/marketplace/orders/
s3://dataduct-curated/marketplace/orders_enriched/dt=2024-01-03/
```

---

## Resetting Storage

Data persists in the `minio_data` Docker volume. To wipe:

```bash
make down    # removes all volumes
make up      # re-creates with empty buckets
```

To wipe only a specific bucket's contents without restarting:
```bash
docker compose exec minio mc rm --recursive --force local/dataduct-curated/
```

---

## Troubleshooting

**Buckets missing after restart:**
The `minio-init` container is a one-shot job. If it ran but MinIO was not yet healthy, buckets may not have been created. Re-run it:
```bash
docker compose run --rm minio-init
```

**403 / Access Denied when reading from pipeline:**
Check that `AWS_ENDPOINT_URL` points to `http://minio:9000` (inside Docker) or `http://localhost:19000` (from host). The endpoint URL must NOT have a trailing slash.

**Files visible in console but not in Trino:**
The Delta catalog uses a file-based metastore. Tables must be registered first:
```sql
-- In Trino
CALL delta.system.register_table(schema_name => 'marketplace', table_name => 'orders', table_location => 's3://dataduct-raw/marketplace/orders/')
```
