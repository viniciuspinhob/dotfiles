# CloudBeaver

Browser-based SQL IDE with pre-configured connections to PostgreSQL and Trino. No local client installation required — open your browser and start querying.

---

## Quick Access

| Property | Value |
|----------|-------|
| URL | `http://localhost:8978` |
| Admin user | `cbadmin` |
| Admin password | `admin` |
| Image | `dbeaver/cloudbeaver:latest` |
| Container name | `dataduct-cloudbeaver` |
| Docker profile | `cloudbeaver`, `query`, `all` |

---

## Start

```bash
# CloudBeaver + all dependencies (postgres + minio + unity-catalog + trino)
docker compose --profile query up -d

# CloudBeaver alone (assumes dependencies are already running)
docker compose up -d cloudbeaver
```

CloudBeaver requires both PostgreSQL and Trino to be healthy before it starts.

---

## Pre-configured Connections

The following database connections are configured automatically at startup:

| Connection Name | Type | Target | Database |
|----------------|------|--------|----------|
| `Marketplace DB` | PostgreSQL | `postgres:5432` | `marketplace_dev` |
| `Airflow DB` | PostgreSQL | `postgres:5432` | `airflow` |
| `Trino` | Trino | `trino:8080` | — |

---

## Using CloudBeaver

### First Login

1. Open `http://localhost:8978`
2. Login with `cbadmin` / `admin`
3. In the left sidebar, expand **Connections** to see pre-configured databases
4. Click any connection to open a SQL editor

### Running Queries

1. Select a connection from the sidebar
2. Click **SQL Editor** (or press `Ctrl+Enter` in any editor pane)
3. Write and execute SQL

### Useful shortcuts

| Action | Shortcut |
|--------|----------|
| Execute query | `Ctrl+Enter` |
| Execute selected | `Ctrl+Enter` (with selection) |
| Format SQL | `Shift+Ctrl+F` |
| Auto-complete | `Ctrl+Space` |
| New editor tab | `Ctrl+T` |

---

## Example Queries

### PostgreSQL — marketplace data
```sql
-- Orders by status
SELECT status, COUNT(*) AS total, SUM(total_amount) AS revenue
FROM orders
GROUP BY status
ORDER BY total DESC;

-- Top sellers by revenue
SELECT s.name, SUM(o.total_amount) AS revenue
FROM orders o
JOIN seller s ON o.id_seller = s.id_seller
GROUP BY s.name
ORDER BY revenue DESC;
```

### Trino — federated query
```sql
-- In the Trino connection, switch catalog/schema first:
-- Catalog: postgresql   Schema: public
SELECT COUNT(*) FROM orders;

-- Cross-catalog join (Unity Catalog + PostgreSQL)
SELECT
    p.buyer_email,
    u.total_enriched
FROM postgresql.public.orders p
JOIN unity_catalog.marketplace.orders_enriched u
    ON p.id_order = u.id_order
LIMIT 10;
```

---

## Configuration Files

| File | Purpose |
|------|---------|
| `docker/cloudbeaver/data-sources.json` | Pre-configured database connections |
| `docker/cloudbeaver/entrypoint.sh` | Initialization script (copies configs into workspace) |
| `docker/cloudbeaver/initial-data.conf` | Admin user and anonymous access settings |

### Adding a Connection Permanently

Edit `docker/cloudbeaver/data-sources.json` and add a new entry following the existing pattern, then restart:
```bash
docker compose restart cloudbeaver
```

---

## Environment Variables

Set via `.env` (defaults shown):

```bash
CB_ADMIN_NAME=cbadmin
CB_ADMIN_PASSWORD=admin
POSTGRES_DB=marketplace_dev
POSTGRES_USER=dataduct
POSTGRES_PASSWORD=dataduct123
```

---

## Interactions

| Talks to | How | Purpose |
|----------|-----|---------|
| `postgres` | JDBC (`postgres:5432`) | Direct database queries |
| `trino` | Trino HTTP (`trino:8080`) | Federated queries across all catalogs |

---

## Troubleshooting

**CloudBeaver takes a long time to start:**
First startup pulls the image and initializes the workspace. Subsequent starts are faster. Check logs:
```bash
docker compose logs cloudbeaver
```

**"Connection failed" for pre-configured connections:**
CloudBeaver starts only after PostgreSQL and Trino are healthy. If you started CloudBeaver before those services were ready, restart it:
```bash
docker compose restart cloudbeaver
```

**Lost workspace / connections after `make down`:**
`make down` removes the `cloudbeaver_data` volume. Connections are restored automatically from the config files on next startup.

**Anonymous access (no login required):**
`CLOUDBEAVER_APP_GRANT_CONNECTIONS_ACCESS_TO_ANONYMOUS_TEAM=true` is set by default, so shared connections are visible without logging in. Disable this in `docker-compose.yml` for stricter access control.
