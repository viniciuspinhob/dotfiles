# Trino

Distributed SQL query engine configured as a **single-node coordinator**. Enables federated queries across PostgreSQL, Delta Lake files on MinIO, and Iceberg tables via Unity Catalog — all from a single SQL interface.

---

## Quick Access

| Property | Value |
|----------|-------|
| UI (from host) | `http://localhost:8085` |
| HTTP API (from host) | `http://localhost:8085` |
| HTTP API (from Docker) | `http://trino:8080` |
| Default user | `admin` (no password) |
| Image | `trinodb/trino:latest` |
| Container name | `dataduct-trino` |
| Docker profile | `trino`, `query`, `all` |

> Profile `trino` only starts Trino itself. Profile `query` starts the full query stack (postgres + minio + unity-catalog + trino + cloudbeaver).

---

## Start

```bash
# Trino + all its dependencies (recommended)
docker compose --profile query up -d

# Trino alone (assumes postgres, minio, unity-catalog already running)
docker compose up -d trino
```

---

## Catalogs

| Catalog | Connector | Source |
|---------|-----------|--------|
| `postgresql` | `postgresql` | `postgres:5432/marketplace_dev` |
| `delta` | `delta_lake` | MinIO (`s3://dataduct-raw/`, file-based metastore) |
| `unity_catalog` | `iceberg` (REST) | Unity Catalog + MinIO |
| `memory` | `memory` | In-memory (temporary, session-scoped) |

---

## Querying

### From the Web UI

1. Open `http://localhost:8085`
2. Click **Query Editor** in the sidebar
3. Set catalog and schema, then write SQL

### From CLI (Trino shell)

```bash
docker compose exec trino trino
```

Inside the Trino shell:
```sql
-- List catalogs
SHOW CATALOGS;

-- List schemas in postgresql catalog
SHOW SCHEMAS FROM postgresql;

-- Query a PostgreSQL table directly
SELECT * FROM postgresql.public.orders LIMIT 10;

-- List schemas in delta catalog
SHOW SCHEMAS FROM delta;

-- Query a Delta Lake table (after registering it)
SELECT * FROM delta.marketplace.orders LIMIT 10;

-- Query an Iceberg table via Unity Catalog
SHOW SCHEMAS FROM unity_catalog;
SELECT * FROM unity_catalog.marketplace.orders_enriched LIMIT 10;
```

### Via JDBC (from Python / dataduct)

```python
import trino

conn = trino.dbapi.connect(
    host="localhost",
    port=8085,
    user="admin",
    catalog="postgresql",
    schema="public",
)
cursor = conn.cursor()
cursor.execute("SELECT COUNT(*) FROM orders")
print(cursor.fetchone())
```

---

## Federated Queries

Trino can join tables across catalogs in a single query:

```sql
-- Join PostgreSQL source with curated Delta table
SELECT
    p.id_order,
    p.buyer_email,
    c.total_enriched
FROM postgresql.public.orders p
JOIN delta.marketplace.orders_enriched c
    ON p.id_order = c.id_order
LIMIT 20;
```

---

## Configuration Files

| File | Purpose |
|------|---------|
| `docker/trino/etc/config.properties` | Coordinator config (single-node, 2GB max query memory) |
| `docker/trino/etc/jvm.config` | JVM: 4GB max heap, G1GC, UTF-8 |
| `docker/trino/etc/node.properties` | Node identity |
| `docker/trino/etc/catalog/postgresql.properties` | PostgreSQL connector |
| `docker/trino/etc/catalog/delta.properties` | Delta Lake connector (MinIO + file metastore) |
| `docker/trino/etc/catalog/unity_catalog.properties` | Iceberg REST connector (Unity Catalog) |
| `docker/trino/etc/catalog/memory.properties` | In-memory connector |

---

## Adding a New Catalog

1. Create `docker/trino/etc/catalog/<name>.properties`
2. Restart Trino:
   ```bash
   docker compose restart trino
   ```
3. Verify:
   ```bash
   docker compose exec trino trino --execute "SHOW CATALOGS;"
   ```
4. Document in this file.

> Do not change existing `connector.name` values — they are internal Trino plugin identifiers.

---

## Registering a Delta Table

The `delta` catalog uses a file-based metastore. Tables must be registered manually before they appear in Trino:

```sql
CALL delta.system.register_table(
    schema_name => 'marketplace',
    table_name  => 'orders',
    table_location => 's3://dataduct-raw/marketplace/orders/'
);
```

---

## Interactions

| Talks to | How | Why |
|----------|-----|-----|
| `postgres` | JDBC (`postgres:5432`) | `postgresql` catalog queries |
| `minio` | S3 API (`minio:9000`) | File access for `delta` and `unity_catalog` catalogs |
| `unity-catalog` | Iceberg REST (`unity-catalog:8080/...`) | Table metadata for `unity_catalog` catalog |
| `cloudbeaver` | Trino HTTP (`trino:8080`) | CloudBeaver connects as a Trino client |

---

## Performance Notes

- **Single-node mode** — all memory and CPU on one container
- Default max query memory: **2GB** (set in `config.properties`)
- JVM heap: **4GB** (set in `jvm.config`)
- Increase heap in `docker/trino/etc/jvm.config` if queries run out of memory:
  ```
  -Xmx6G
  ```

---

## Troubleshooting

**Trino takes 60+ seconds to be healthy on first start:**
Normal. Trino has a 60s `start_period` in its healthcheck. Wait for:
```bash
docker compose ps trino
# STATUS: (healthy)
```

**Query fails with "Catalog does not exist":**
Verify the catalog file exists and Trino loaded it:
```bash
docker compose exec trino trino --execute "SHOW CATALOGS;"
```
Check logs for connector errors:
```bash
docker compose logs trino | grep -i "error\|catalog"
```

**S3 / MinIO connection errors from delta or unity_catalog:**
Confirm MinIO is healthy and the credentials in the catalog properties match `.env`:
```bash
curl http://localhost:19000/minio/health/live
```

**Out of memory errors:**
Reduce query parallelism or increase heap in `jvm.config`. Restart after changing JVM settings:
```bash
docker compose restart trino
```
