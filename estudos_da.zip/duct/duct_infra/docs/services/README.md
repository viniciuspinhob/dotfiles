# Services Reference

Quick-reference index for all services in the dataduct local stack.

---

## Service Index

| Service | Profile | Host Port | URL / Connection | Doc |
|---------|---------|-----------|-----------------|-----|
| PostgreSQL | `postgres` | 5432 | `localhost:5432` | [postgres.md](postgres.md) |
| MinIO | `minio` | 19000 / 19001 | `http://localhost:19001` | [minio.md](minio.md) |
| Unity Catalog | `catalog` | 8080 | `http://localhost:8080` | [unity-catalog.md](unity-catalog.md) |
| Unity Catalog UI | `catalog` | 3000 | `http://localhost:3000` | [unity-catalog.md](unity-catalog.md) |
| Trino | `trino` | 8085 | `http://localhost:8085` | [trino.md](trino.md) |
| CloudBeaver | `cloudbeaver` | 8978 | `http://localhost:8978` | [cloudbeaver.md](cloudbeaver.md) |
| Apache Airflow | `airflow` | 8082 | `http://localhost:8082` | [airflow.md](airflow.md) |
| dataduct-dev | `dev` | — | `docker compose exec dataduct-dev bash` | [dataduct-dev.md](dataduct-dev.md) |

---

## Default Credentials

| Service | User | Password |
|---------|------|----------|
| PostgreSQL | `dataduct` | `dataduct123` |
| MinIO | `minioadmin` | `minioadmin123` |
| CloudBeaver | `cbadmin` | `admin` |
| Airflow | `airflow` | `airflow123` |
| Unity Catalog | — | no auth |
| Trino | `admin` | no password |

---

## Start Individual Services

```bash
# PostgreSQL only
docker compose --profile postgres up -d

# MinIO only (+ bucket bootstrap)
docker compose --profile minio up -d

# Unity Catalog + UI
docker compose --profile catalog up -d

# Trino (requires postgres + minio + unity-catalog)
docker compose --profile query up -d

# CloudBeaver (requires postgres + trino)
docker compose --profile query up -d

# Airflow (requires postgres + minio)
docker compose --profile airflow up -d

# Dev container (requires postgres + minio + unity-catalog)
docker compose --profile dev up -d

# Everything
docker compose --profile all up -d
```

---

## Group Profiles

| Profile | Services Started |
|---------|-----------------|
| `all` | Everything (13 containers) |
| `storage` | postgres, minio, minio-init |
| `query` | postgres, minio, unity-catalog, trino, cloudbeaver + inits |
| `catalog` | unity-catalog, unity-catalog-init, unity-catalog-ui |
| `airflow` | postgres, minio, airflow-init, airflow-webserver, airflow-scheduler, dag sidecars |
| `dev` | postgres, minio, unity-catalog, dataduct-dev + inits |

---

## Further Reading

- [Architecture & interactions](../architecture.md)
- [Local dev guide](../local-dev.md)
