# Architecture — dataduct Infrastructure

This document describes how all services interact within the local development stack.

---

## System Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          HOST MACHINE                                    │
│                                                                          │
│  ┌─────────┐  ┌──────────┐  ┌─────────────────┐  ┌──────────────────┐ │
│  │ Browser │  │  psql /  │  │  Python scripts  │  │  Airflow UI      │ │
│  │         │  │  IDE     │  │  (local venv)    │  │  :8082           │ │
│  └────┬────┘  └────┬─────┘  └────────┬────────┘  └────────┬─────────┘ │
│       │             │                 │                     │            │
└───────┼─────────────┼─────────────────┼─────────────────────┼───────────┘
        │             │                 │                     │
        │   ┌─────────▼─────────────────▼──────────────────────▼──────┐
        │   │                  dataduct-net (bridge)                    │
        │   │                                                           │
        │   │  ┌─────────────┐   ┌──────────────┐   ┌──────────────┐  │
        │   │  │  PostgreSQL  │   │    MinIO     │   │   Trino      │  │
        │   │  │  :5432       │   │  :9000/:9001 │   │  :8080→8085  │  │
        │   │  └──────┬──────┘   └──────┬───────┘   └──────┬───────┘  │
        │   │         │                 │                   │           │
        │   │         │    ┌────────────┘                   │           │
        │   │         │    │  ┌─────────────────────────────┘           │
        │   │         │    │  │                                          │
        │   │  ┌───────────▼──▼──────┐   ┌────────────────────────┐    │
        │   │  │   dataduct-dev      │   │   Unity Catalog        │    │
        │   │  │   (compute)         │   │   :8080 (REST API)     │    │
        │   │  │   /app  → dataduct  │   │   :3000 (UI)           │    │
        │   │  │   /examples         │   └────────────────────────┘    │
        │   │  └─────────────────────┘                                  │
        │   │                                                           │
        │   │  ┌──────────────┐   ┌──────────────────────────────────┐ │
        │   │  │  CloudBeaver │   │  Airflow (webserver + scheduler) │ │
        │   │  │  :8978       │   │  :8082                           │ │
        │   │  └──────────────┘   └──────────────────────────────────┘ │
        │   └───────────────────────────────────────────────────────────┘
        │
        └── Browser UIs:
            MinIO Console    → http://localhost:19001
            Unity Catalog UI → http://localhost:3000
            Trino UI         → http://localhost:8085
            CloudBeaver      → http://localhost:8978
            Airflow          → http://localhost:8082
```

---

## Data Flow: Pipeline Execution

The primary data flow follows a medallion lakehouse pattern:

```
PostgreSQL (OLTP)
      │
      │  JDBC read
      ▼
┌──────────────────────────────────────────────────────────────────┐
│  dataduct-dev container  (PySpark or DuckDB as compute engine)   │
│                                                                  │
│  Stage 1: jdbc_to_raw                                            │
│  ┌─────────────┐     ┌──────────────────────────────────────┐   │
│  │ seller      │     │  MinIO: s3://dataduct-raw/            │   │
│  │ product     │────▶│  marketplace/seller/                  │   │
│  │ orders      │     │  marketplace/product/                 │   │
│  └─────────────┘     │  marketplace/orders/                  │   │
│                      └──────────────────────────────────────┘   │
│                                        │                         │
│  Stage 2: raw_to_curated               │                         │
│                      ┌─────────────────▼────────────────────┐   │
│                      │  MinIO: s3://dataduct-curated/        │   │
│                      │  marketplace/orders_enriched/         │   │
│                      └──────────────────┬───────────────────┘   │
│                                         │                        │
│                              Register table in Unity Catalog     │
└──────────────────────────────────────────────────────────────────┘
                                          │
                                          ▼
                               Unity Catalog (REST API)
                               catalog: dataduct_curated
                               schema:  marketplace
                               table:   orders_enriched
                                          │
                                          ▼
                        Trino (unity_catalog connector → Iceberg REST)
                        SELECT * FROM unity_catalog.marketplace.orders_enriched
```

---

## Service Dependency Graph

```
postgres ──────────────────────────────────────────────┐
    │                                                   │
    └──▶ airflow-init ──▶ airflow-webserver             │
                      └──▶ airflow-scheduler            │
                                                        │
minio ──▶ minio-init ──────────────────────────────────┤
              │                                         │
              └──▶ airflow-dag-upload                   │
                        └──▶ airflow-dag-sync           │
                                                        ▼
unity-catalog ──▶ unity-catalog-init          dataduct-dev
      │               │                           (depends on postgres,
      └──▶ unity-catalog-ui                        minio-init,
                                                   unity-catalog-init)
unity-catalog + minio ──▶ trino
                               └──▶ cloudbeaver (+ postgres)
```

---

## Service Interaction Matrix

| Service | Talks to | How | Why |
|---------|----------|-----|-----|
| `dataduct-dev` | `postgres` | JDBC (`postgres:5432`) | Read/write marketplace data |
| `dataduct-dev` | `minio` | S3 API (`minio:9000`) | Read raw, write curated parquet |
| `dataduct-dev` | `unity-catalog` | REST API (`unity-catalog:8080`) | Register curated tables |
| `trino` | `postgres` | JDBC (`postgres:5432`) | `postgresql` catalog connector |
| `trino` | `minio` | S3 API (`minio:9000`) | `delta` and `unity_catalog` file access |
| `trino` | `unity-catalog` | Iceberg REST (`unity-catalog:8080`) | `unity_catalog` catalog metadata |
| `cloudbeaver` | `postgres` | JDBC | Direct SQL access |
| `cloudbeaver` | `trino` | Trino HTTP (`trino:8080`) | Federated queries |
| `airflow-scheduler` | `postgres` | SQLAlchemy | Airflow metadata DB |
| `airflow-scheduler` | `minio` | S3 API | DAG sync, pipeline I/O |
| `airflow-scheduler` | `dataduct` + `examples` (editable) | Runs `DataductOperator` tasks in-process |
| `airflow-dag-sync` | `minio` | mc (MinIO client) | Pull DAGs from bucket |
| `unity-catalog-ui` | `unity-catalog` | REST API | Browse catalogs via browser |

---

## Network

All containers share a single Docker bridge network: `dataduct-net`.

| From | To | Address used |
|------|----|--------------|
| host machine | any service | `localhost:<host-port>` |
| container → postgres | `postgres:5432` | Docker DNS |
| container → minio | `minio:9000` | Docker DNS |
| container → unity-catalog | `unity-catalog:8080` or `server:8080` | Docker DNS (aliased) |
| container → trino | `trino:8080` | Docker DNS |

> Unity Catalog has a network alias `server` in addition to its service name `unity-catalog`.
> This is required because the Iceberg REST client inside Trino resolves catalog URLs using that alias.

---

## Profiles Reference

Use `--profile` flags to start only the services you need:

```bash
# Minimal: just the databases
docker compose --profile storage up -d
# Starts: postgres, minio, minio-init

# Full query stack (no Airflow, no dev container)
docker compose --profile query up -d
# Starts: postgres, minio, minio-init, unity-catalog, unity-catalog-init, trino, cloudbeaver

# Catalog browsing only
docker compose --profile catalog up -d
# Starts: unity-catalog, unity-catalog-init, unity-catalog-ui

# Development (interactive pipeline work)
docker compose --profile dev up -d
# Starts: postgres, minio, minio-init, unity-catalog, unity-catalog-init, dataduct-dev

# Pipeline orchestration
docker compose --profile airflow up -d
# Starts: postgres, minio, minio-init, airflow-init, airflow-webserver, airflow-scheduler, airflow-dag-*

# Everything
docker compose --profile all up -d
```

---

## Ports Summary

| Service | Host Port | Container Port | URL |
|---------|-----------|----------------|-----|
| PostgreSQL | 5432 | 5432 | `localhost:5432` |
| MinIO API | 19000 | 9000 | `http://localhost:19000` |
| MinIO Console | 19001 | 9001 | `http://localhost:19001` |
| Unity Catalog API | 8080 | 8080 | `http://localhost:8080` |
| Unity Catalog UI | 3000 | 3000 | `http://localhost:3000` |
| Trino | 8085 | 8080 | `http://localhost:8085` |
| CloudBeaver | 8978 | 8978 | `http://localhost:8978` |
| Airflow | 8082 | 8080 | `http://localhost:8082` |
