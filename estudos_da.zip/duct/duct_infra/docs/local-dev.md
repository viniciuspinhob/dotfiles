# Local Development Guide

This guide covers how to spin up the local infrastructure, create your own job repositories, and run them against the services provided by Docker Compose.

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Infrastructure Setup](#2-infrastructure-setup)
3. [Service Reference](#3-service-reference)
4. [Local Python Environment](#4-local-python-environment)
5. [Creating Your Own Job Repository](#5-creating-your-own-job-repository)
6. [Running Jobs](#6-running-jobs)
7. [Running Jobs Inside Docker](#7-running-jobs-inside-docker)
8. [Running Tests](#8-running-tests)
9. [Makefile Quick Reference](#9-makefile-quick-reference)

---

## 1. Prerequisites

| Dependency | Version | Required |
|---|---|---|
| Python | 3.11+ | Always |
| Java JDK | 17+ | Spark engine only |
| Docker + Docker Compose | v2+ | For local services |
| Make | any | Optional (convenience) |

---

## 2. Infrastructure Setup

### First-time setup

```bash
# Copy the example env file — do not commit .env
cp .env.example .env

# Start all services in the background
make docker-up
# or: docker compose up -d
```

The first startup takes longer because Docker pulls images and the `minio-init` container bootstraps the bucket structure.

### Checking status

```bash
make docker-ps
# or: docker compose ps
```

All services should show `healthy` or `running` before running jobs.

### Stopping services

```bash
# Stop and remove containers + volumes
make docker-down
# or: docker compose down -v --remove-orphans

# Stop without removing volumes (preserves data)
docker compose stop
```

---

## 3. Service Reference

### PostgreSQL

| Property | Value |
|---|---|
| Host (from host machine) | `localhost:5432` |
| Host (from inside Docker) | `postgres:5432` |
| Database | `marketplace_dev` |
| User | `dataduct` |
| Password | `dataduct123` |
| JDBC URL (local) | `jdbc:postgresql://localhost:5432/marketplace_dev` |
| JDBC URL (Docker) | `jdbc:postgresql://postgres:5432/marketplace_dev` |

Pre-seeded tables: `seller`, `product`, `orders`.

Connect via psql:
```bash
docker compose exec postgres psql -U dataduct -d marketplace_dev
```

### MinIO (S3-compatible)

| Property | Value |
|---|---|
| API endpoint (from host) | `http://localhost:19000` |
| API endpoint (from Docker) | `http://minio:9000` |
| Console UI | `http://localhost:19001` |
| Access Key | `minioadmin` |
| Secret Key | `minioadmin123` |
| Buckets | `dataduct-landing`, `dataduct-raw`, `dataduct-curated`, `dataduct-dags` |

### Unity Catalog

| Property | Value |
|---|---|
| URL (from host) | `http://localhost:8080` |
| URL (from Docker) | `http://unity-catalog:8080` |
| REST API base | `http://localhost:8080/api/2.1/unity-catalog/` |
| Authentication | None (open by default) |

### Trino

| Property | Value |
|---|---|
| URL (from host) | `http://localhost:8085` |
| URL (from Docker) | `http://trino:8080` |
| Default user | `admin` (no password) |

### Apache Airflow

| Property | Value |
|---|---|
| Web UI | `http://localhost:8082` |
| Admin user | `airflow` |
| Admin password | `airflow123` |
| Executor | LocalExecutor |
| DAG source | MinIO bucket `dataduct-dags` |

DAGs are stored in the MinIO bucket `dataduct-dags` and synced to the Airflow containers every 30 seconds via a sidecar (`airflow-dag-sync`).

#### Developing DAGs

1. Edit DAG files in the local `dags/` directory
2. Upload to MinIO: `make dags-upload`
3. The sync sidecar picks up changes within 30 seconds
4. Check the Airflow UI at `http://localhost:8082`

#### Pre-configured connections

| Connection ID | Type | Target |
|---|---|---|
| `postgres_marketplace` | PostgreSQL | `postgres:5432/marketplace_dev` |
| `minio_s3` | AWS (S3) | `http://minio:9000` |

---

## 4. Local Python Environment

```bash
# Create virtualenv with Python 3.11 and install all dependencies
make venv
make install-all

# Activate the virtualenv
source .venv311/bin/activate
```

Set the required environment variables (or load from `.env`):

```bash
# PostgreSQL
export DEV_DB_USER=dataduct
export DEV_DB_PASS=dataduct123

# MinIO / S3
export AWS_ACCESS_KEY_ID=minioadmin
export AWS_SECRET_ACCESS_KEY=minioadmin123
export AWS_ENDPOINT_URL=http://localhost:9000
export AWS_DEFAULT_REGION=us-east-1
```

> Tip: use `direnv` or `dotenv` to auto-load `.env` on shell entry.

---

## 5. Creating Your Own Job Repository

Your job repository is a standard Python package that imports `dataduct` as a library. It can live anywhere on your machine — it does **not** need to be inside the `dataduct` source tree.

### Recommended structure

```
my-jobs/                        # your repo root
├── setup.py                    # or pyproject.toml
├── requirements.txt
├── .env                        # local credentials, never commit
│
└── my_domain/                  # one package per domain / team
    ├── __init__.py
    │
    └── my_job/                 # one sub-package per job
        ├── __init__.py
        ├── config.yaml         # base config
        ├── config-dev.yaml     # dev overlay (optional)
        └── job.py              # business logic
```

### Minimal `config.yaml`

```yaml
type: python
engine: duckdb          # or spark

sources:
  - name: orders
    format: jdbc
    url: "jdbc:postgresql://localhost:5432/marketplace_dev"
    driver: "org.postgresql.Driver"
    table: "orders"
    credentials:
      type: env
      user_var: "DEV_DB_USER"
      password_var: "DEV_DB_PASS"

sinks:
  - name: orders_raw
    format: parquet
    path: "/tmp/my_output/orders.parquet"
    mode: overwrite

custom:
  dt_referencia: "2024-01-01"
```

### Dev overlay `config-dev.yaml`

Override only what changes between environments. Values are deep-merged on top of `config.yaml`:

```yaml
engine: duckdb

engine_config:
  database: ":memory:"

sinks:
  - name: orders_raw
    format: parquet
    path: "/tmp/dev_output/orders.parquet"
    mode: overwrite

custom:
  dt_referencia: "2024-01-01"
```

### `job.py`

```python
from dataduct.core.job.base import Job


class MyJob(Job):
    def run(self):
        dt = self.custom.get("dt_referencia")

        result = self.engine.execute_sql(f"""
            SELECT *
            FROM orders
            WHERE ordered_at >= '{dt}'
        """)

        self.sinks.orders_raw.save(result)
```

Rules:
- The file must be named `job.py`
- The class must extend `Job`
- There must be exactly one `Job` subclass per file
- Business logic goes in `run()` — setup and teardown are handled by the framework

### Installing dataduct as a dependency

**Option A — editable install from source (recommended during development):**

```bash
# In your job repo
pip install -e /path/to/dataduct[all]
```

**Option B — add to `requirements.txt`:**

```
-e /path/to/dataduct[all]
```

Then:
```bash
pip install -r requirements.txt
```

### Making your package importable

The `--job` flag expects a Python importable path (`my_domain.my_job`). Either:

```bash
# Run from your repo root (Python adds cwd to sys.path automatically)
cd my-jobs
python -m dataduct run --job my_domain.my_job

# Or install your package as editable
pip install -e .
python -m dataduct run --job my_domain.my_job
```

---

## 6. Running Jobs

### Base command

```bash
python -m dataduct run --job <package.module>
```

### All flags

| Flag | Description | Example |
|---|---|---|
| `--job` | Importable path to the job package | `my_domain.my_job` |
| `--engine` | Override engine from config | `--engine duckdb` |
| `--env` | Load `config-{env}.yaml` overlay | `--env dev` |
| `--custom` / `-c` | Inject custom params as JSON | `-c '{"dt_referencia":"2024-01-01"}'` |
| `--dry-run` | Validate config without executing | `--dry-run` |
| `--verbose` | Enable debug logging | `--verbose` |

### Examples

```bash
# Quickest start: DuckDB, no extra services needed
python -m dataduct run --job my_domain.my_job --engine duckdb

# With dev overlay
python -m dataduct run --job my_domain.my_job --env dev

# With dynamic parameters
python -m dataduct run --job my_domain.my_job --env dev \
  -c '{"dt_referencia": "2024-06-01"}'

# Validate config without running
python -m dataduct run --job my_domain.my_job --dry-run

# Debug mode
python -m dataduct --verbose run --job my_domain.my_job --env dev
```

### Environment variables per service

Set these before running any job that connects to local services:

```bash
# PostgreSQL (JDBC source/sink)
export DEV_DB_USER=dataduct
export DEV_DB_PASS=dataduct123

# MinIO (object_storage source/sink)
export AWS_ACCESS_KEY_ID=minioadmin
export AWS_SECRET_ACCESS_KEY=minioadmin123
export AWS_ENDPOINT_URL=http://localhost:9000
export AWS_DEFAULT_REGION=us-east-1

# Spark on macOS (required when using spark engine locally)
export PYSPARK_PYTHON=python3
```

### Programmatic API (without CLI)

Use `JobFactory` directly when integrating with orchestrators (Airflow, Prefect, etc):

```python
from dataduct.core.job.factory import JobFactory
from dataduct.engines import load_engine

config = JobFactory.build_config(
    job_package_name="my_domain.my_job",
    env="dev",
    orchestration_config={"dt_referencia": "2024-01-01"},
)

engine = load_engine(config.get("engine", "duckdb"), config.get("engine_config", {}))
try:
    job = JobFactory.get(config, engine=engine)
    job.execute()
finally:
    engine.stop_session()
```

---

## 7. Running Jobs Inside Docker

The `dataduct-dev` container has all environment variables pre-configured to reach the other services by their Docker network hostnames (`postgres`, `minio`, `unity-catalog`). This is the easiest way to run jobs that connect to local services without managing env vars manually.

### Open a shell in the container

```bash
make docker-shell
# or: docker compose exec dataduct-dev bash
```

Inside the container, run your job normally:
```bash
python -m dataduct run --job my_domain.my_job --env dev
```

### Run a single command without opening a shell

```bash
docker compose exec dataduct-dev \
  python -m dataduct run --job my_domain.my_job --env dev
```

### Mounting your own job repository

The `dataduct-dev` container mounts the entire `dataduct` source directory at `/app`. To also mount your external job repo, add a volume to `docker-compose.yml`:

```yaml
services:
  dataduct-dev:
    volumes:
      - .:/app
      - /path/to/my-jobs:/my-jobs     # add this line
      - jars_cache:/opt/jars
```

Then inside the container:
```bash
pip install -e /my-jobs
python -m dataduct run --job my_domain.my_job --env dev
```

### Config differences: local vs. Docker

When writing `config-dev.yaml` you need to choose the right hostnames:

| Connection | From host machine | From inside Docker |
|---|---|---|
| PostgreSQL | `localhost:5432` | `postgres:5432` |
| MinIO API | `http://localhost:9000` | `http://minio:9000` |
| Unity Catalog | `http://localhost:8080` | `http://unity-catalog:8080` |
| Trino | `http://localhost:8085` | `http://trino:8080` |

Use Jinja2 + env vars in your config to handle both cases without duplicating files:

```yaml
sources:
  - name: orders
    format: jdbc
    url: "jdbc:postgresql://{{ env_var('POSTGRES_HOST', 'localhost') }}:5432/marketplace_dev"
    driver: "org.postgresql.Driver"
    table: "orders"
    credentials:
      type: env
      user_var: "DEV_DB_USER"
      password_var: "DEV_DB_PASS"
```

---

## 8. Running Tests

### Unit tests (no Docker required)

Most tests use mocks and run entirely locally:

```bash
# All tests
make test

# With coverage report
make test-cov

# Engine-specific
make test-spark
make test-duckdb
```

### Integration tests (require Docker services)

If your job repo has integration tests that connect to real services, run them through the `dataduct-dev` container:

```bash
# From your host machine
docker compose exec dataduct-dev pytest /my-jobs/tests/ -v

# Or open a shell first
make docker-shell
pytest /my-jobs/tests/ -v
```

The container already has `POSTGRES_HOST`, `AWS_ENDPOINT_URL`, etc. set to point at the internal services.

---

## 9. Makefile Quick Reference

| Target | Description |
|---|---|
| `make venv` | Create `.venv311` with Python 3.11 |
| `make install` | Install core package only |
| `make install-dev` | Install core + dev dependencies |
| `make install-all` | Install everything (Spark, DuckDB, boto3) |
| `make test` | Run all tests |
| `make test-cov` | Run tests with coverage report |
| `make test-spark` | Run Spark engine tests only |
| `make test-duckdb` | Run DuckDB engine tests only |
| `make lint` | Check code with ruff |
| `make format` | Format code with ruff |
| `make clean` | Remove build artifacts and caches |
| `make docker-up` | Start all Docker services |
| `make docker-down` | Stop and remove containers + volumes |
| `make docker-logs` | Follow logs from all services |
| `make docker-ps` | Show status of all containers |
| `make docker-shell` | Open bash shell in `dataduct-dev` container |
| `make airflow-logs` | Follow Airflow webserver + scheduler logs |
| `make airflow-shell` | Open bash shell in Airflow scheduler |
| `make dags-upload` | Upload local `dags/` to MinIO bucket |
