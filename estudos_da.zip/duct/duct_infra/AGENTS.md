# AGENTS.md — dataduct Infrastructure

This file is the entry point for AI agents working in this repository.
Read this before making any changes.

---

## What This Repo Is

`duct_infra` is the **local development infrastructure** for the dataduct ETL ecosystem.
It orchestrates 13 Docker containers that provide the full data stack locally.

This repo contains **no application code** — only infrastructure configuration (Docker Compose, SQL seeds, shell scripts, config files).

---

## Sibling Repositories

This project expects two sibling directories to exist at the same level:

```
duct/
├── duct_infra/          ← you are here
├── dataduct/            ← core Python ETL library (mounted at /app in dev container)
└── dataduct-examples/   ← example pipeline jobs (mounted at /examples in dev container)
```

---

## Services at a Glance

| Service | Profile | Port(s) | Purpose |
|---------|---------|---------|---------|
| PostgreSQL | `postgres` | 5432 | OLTP source/sink + Airflow metadata DB |
| MinIO | `minio` | 19000, 19001 | S3-compatible object storage (data lake) |
| Unity Catalog | `catalog` | 8080 | Data catalog REST API |
| Unity Catalog UI | `catalog` | 3000 | Web UI for the catalog |
| Trino | `trino` | 8085 | Federated SQL query engine |
| CloudBeaver | `cloudbeaver` | 8978 | Web SQL IDE |
| dataduct-dev | `dev` | — | Python/Spark/DuckDB compute container |
| Airflow (all) | `airflow` | 8082 | Pipeline orchestration |

**Group profiles** (start related services together):

| Profile | Starts |
|---------|--------|
| `all` | Everything |
| `storage` | postgres + minio + minio-init |
| `query` | postgres + minio + unity-catalog + trino + cloudbeaver |
| `catalog` | unity-catalog + unity-catalog-init + unity-catalog-ui |
| `airflow` | postgres + minio + airflow-* |
| `dev` | postgres + minio + unity-catalog + dataduct-dev |

---

## How to Start Services

```bash
# All services
docker compose --profile all up -d

# Or use make (starts everything)
make up

# Single service
docker compose --profile postgres up -d

# Query stack (Trino + Postgres + MinIO + UC + CloudBeaver)
docker compose --profile query up -d

# Dev container stack
docker compose --profile dev up -d
```

---

## Directory Map

```
duct_infra/
├── AGENTS.md                        ← you are here
├── README.md                        ← human quick-start
├── docker-compose.yml               ← all 13 services defined here
├── Makefile                         ← convenience commands
├── .env.example                     ← copy to .env before starting
├── .jars/                           ← JDBC drivers (postgres, hadoop-aws, aws-sdk)
├── dags/
│   └── orders_marketplace_pipeline.py  ← example Airflow DAG
├── run_orders_pipeline.sh           ← manual pipeline runner
└── docker/
    ├── airflow/
    │   ├── Dockerfile               ← apache/airflow:2.10.5-python3.11 + providers
    │   └── requirements.txt
    ├── cloudbeaver/
    │   ├── data-sources.json        ← pre-configured DB connections
    │   ├── entrypoint.sh
    │   └── initial-data.conf
    ├── dataduct-dev/
    │   ├── Dockerfile               ← python:3.11-slim + openjdk-21
    │   ├── jars/                    ← JDBC drivers copied into image
    │   └── requirements.txt         ← pyspark, duckdb, pyarrow, boto3, requests
    ├── minio/
    │   └── bootstrap.sh             ← creates 4 buckets on first start
    ├── postgres/
    │   ├── 00-create-airflow-db.sql ← creates 'airflow' database
    │   └── 01-marketplace-seed.sql  ← seeds seller/product/orders tables
    ├── trino/
    │   └── etc/
    │       ├── config.properties    ← coordinator config (2GB query memory)
    │       ├── jvm.config           ← 4GB heap, G1GC
    │       ├── node.properties
    │       └── catalog/
    │           ├── postgresql.properties   ← connector → postgres:5432
    │           ├── delta.properties        ← delta lake → minio
    │           ├── unity_catalog.properties← iceberg REST → unity-catalog
    │           └── memory.properties       ← in-memory scratch
    └── unity-catalog/
        ├── bootstrap.sh             ← creates catalogs + schemas via REST API
        └── etc/conf/                ← server config + auth keys
```

---

## Service Documentation

Full per-service documentation lives in `docs/services/`:

| File | Service |
|------|---------|
| [docs/services/postgres.md](docs/services/postgres.md) | PostgreSQL |
| [docs/services/minio.md](docs/services/minio.md) | MinIO |
| [docs/services/unity-catalog.md](docs/services/unity-catalog.md) | Unity Catalog |
| [docs/services/trino.md](docs/services/trino.md) | Trino |
| [docs/services/cloudbeaver.md](docs/services/cloudbeaver.md) | CloudBeaver |
| [docs/services/airflow.md](docs/services/airflow.md) | Apache Airflow |
| [docs/services/dataduct-dev.md](docs/services/dataduct-dev.md) | dataduct-dev container |

Architecture and interaction diagram: [docs/architecture.md](docs/architecture.md)

Full developer guide: [docs/local-dev.md](docs/local-dev.md)

---

## Key Conventions

### Environment variables
- All credentials come from `.env` (copied from `.env.example`)
- Never commit `.env`
- All services have safe defaults — they work without `.env` for local dev

### Networks
- All containers share `dataduct-net` bridge network
- Inside the network, services are reachable by their **service name** (e.g. `postgres`, `minio`, `unity-catalog`)
- From the host machine, use `localhost:<mapped-port>`

### Volumes
- `postgres_data` — PostgreSQL data (persists between restarts)
- `minio_data` — MinIO object storage
- `unity_catalog_data` — Unity Catalog metadata
- `cloudbeaver_data` — CloudBeaver workspace
- `airflow_logs` — Airflow task logs
- `airflow_dags` — Shared DAG volume (synced from MinIO)

### Init / sidecar containers
Some services have companion one-shot containers:
- `minio-init` — creates S3 buckets (runs once, exits)
- `unity-catalog-init` — creates catalogs and schemas via REST (runs once, exits)
- `airflow-init` — runs `airflow db migrate`, creates admin user and connections (runs once, exits)
- `airflow-dag-upload` — mirrors `dags/` to MinIO (runs once, exits)
- `airflow-dag-sync` — polls MinIO every 30s and syncs DAGs to the shared volume (long-running)

---

## Common Tasks for Agents

### Add a new service
1. Add service definition to `docker-compose.yml` with an appropriate `profiles` list
2. Create a config directory under `docker/<service-name>/` if it needs custom config
3. Add an entry to `docs/services/` with a service doc
4. Update `docs/services/README.md` and `docs/architecture.md`

### Change PostgreSQL schema
1. Edit `docker/postgres/01-marketplace-seed.sql`
2. Run `make down && make up` to re-seed (volumes are wiped on `down -v`)

### Add a new Trino catalog
1. Create `docker/trino/etc/catalog/<name>.properties`
2. Restart Trino: `docker compose restart trino`
3. Document in `docs/services/trino.md`

### Add a new Airflow DAG
1. Add `.py` file to `dags/`
2. Run `make dags-upload`
3. DAG appears in Airflow UI within 30 seconds

### Rebuild a custom image
```bash
docker compose build <service>          # e.g. dataduct-dev, airflow-webserver
docker compose --profile all up -d
```

---

## Do Not

- Do not commit `.env`
- Do not hardcode credentials outside of `.env.example` defaults
- Do not push secrets to any file tracked by git
- Do not modify init SQL files and expect changes to apply without `make down` first
- Do not change `connector.name` values in Trino catalog files — they map to internal Trino plugin names
