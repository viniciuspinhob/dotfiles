#!/usr/bin/env bash
# Downloads Spark/JDBC/Delta JARs into docker/dataduct-dev/jars/.
# Safe to re-run: skips files that already exist.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
JARS_DIR="${JARS_DIR:-${SCRIPT_DIR}/../docker/dataduct-dev/jars}"
MAVEN_BASE="${MAVEN_BASE:-https://repo1.maven.org/maven2}"

DELTA_VERSION="${DELTA_VERSION:-3.2.0}"
SPARK_SCALA="${SPARK_SCALA:-2.12}"
POSTGRES_JDBC_VERSION="${POSTGRES_JDBC_VERSION:-42.7.2}"
HADOOP_AWS_VERSION="${HADOOP_AWS_VERSION:-3.3.4}"
AWS_SDK_BUNDLE_VERSION="${AWS_SDK_BUNDLE_VERSION:-1.12.262}"

mkdir -p "${JARS_DIR}"

download_jar() {
  local group_path="$1"
  local artifact="$2"
  local version="$3"
  local jar_name="${artifact}-${version}.jar"
  local dest="${JARS_DIR}/${jar_name}"

  if [[ -f "${dest}" ]]; then
    echo "skip  ${jar_name}"
    return 0
  fi

  local url="${MAVEN_BASE}/${group_path}/${artifact}/${version}/${jar_name}"
  echo "fetch ${jar_name}"
  curl -fsSL -o "${dest}" "${url}"
}

echo "JAR directory: ${JARS_DIR}"

download_jar "org/postgresql" "postgresql" "${POSTGRES_JDBC_VERSION}"
download_jar "org/apache/hadoop" "hadoop-aws" "${HADOOP_AWS_VERSION}"
download_jar "com/amazonaws" "aws-java-sdk-bundle" "${AWS_SDK_BUNDLE_VERSION}"
download_jar "io/delta" "delta-spark_${SPARK_SCALA}" "${DELTA_VERSION}"
download_jar "io/delta" "delta-storage" "${DELTA_VERSION}"

echo "done — $(ls -1 "${JARS_DIR}"/*.jar 2>/dev/null | wc -l | tr -d ' ') jar(s) in ${JARS_DIR}"
