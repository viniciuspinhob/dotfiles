#!/bin/sh
set -e

MC_ALIAS="local"
MINIO_URL="http://minio:9000"
BUCKET_LANDING="${MINIO_BUCKET_LANDING:-dataduct-landing}"
BUCKET_RAW="${MINIO_BUCKET_RAW:-dataduct-raw}"
BUCKET_CURATED="${MINIO_BUCKET_CURATED:-dataduct-curated}"
BUCKET_DAGS="${MINIO_BUCKET_DAGS:-dataduct-dags}"

echo "Waiting for MinIO to be ready..."
until mc alias set "$MC_ALIAS" "$MINIO_URL" "$MINIO_ROOT_USER" "$MINIO_ROOT_PASSWORD" > /dev/null 2>&1; do
  sleep 2
done

for BUCKET in "$BUCKET_LANDING" "$BUCKET_RAW" "$BUCKET_CURATED" "$BUCKET_DAGS"; do
  echo "Creating bucket: $BUCKET"
  if mc ls "$MC_ALIAS/$BUCKET" > /dev/null 2>&1; then
    echo "Bucket $BUCKET already exists, skipping."
  else
    mc mb "$MC_ALIAS/$BUCKET"
    echo "Bucket $BUCKET created."
  fi
done

echo "MinIO bootstrap complete."
echo "  Buckets:"
echo "    $BUCKET_LANDING"
echo "    $BUCKET_RAW"
echo "    $BUCKET_CURATED"
echo "    $BUCKET_DAGS"
echo "  Console: http://localhost:9001"
