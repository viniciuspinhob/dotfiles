CREATE TABLE seller (
    id_seller   SERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL UNIQUE,
    category    VARCHAR(50)  NOT NULL,
    rating      DECIMAL(3,2) DEFAULT 0.00,
    active      BOOLEAN      DEFAULT TRUE,
    created_at  TIMESTAMP    DEFAULT NOW(),
    updated_at  TIMESTAMP    DEFAULT NOW()
);

CREATE TABLE product (
    id_product  SERIAL PRIMARY KEY,
    id_seller   INTEGER      NOT NULL REFERENCES seller(id_seller),
    name        VARCHAR(200) NOT NULL,
    description TEXT,
    price       DECIMAL(12,2) NOT NULL,
    stock       INTEGER      DEFAULT 0,
    category    VARCHAR(50),
    status      VARCHAR(20)  DEFAULT 'active',
    created_at  TIMESTAMP    DEFAULT NOW(),
    updated_at  TIMESTAMP    DEFAULT NOW()
);

CREATE TABLE orders (
    id_order      SERIAL PRIMARY KEY,
    id_product    INTEGER      NOT NULL REFERENCES product(id_product),
    id_seller     INTEGER      NOT NULL REFERENCES seller(id_seller),
    buyer_email   VARCHAR(150) NOT NULL,
    quantity      INTEGER      NOT NULL,
    unit_price    DECIMAL(12,2) NOT NULL,
    total_amount  DECIMAL(12,2) NOT NULL,
    status        VARCHAR(20)  DEFAULT 'pending',
    ordered_at    TIMESTAMP    DEFAULT NOW(),
    updated_at    TIMESTAMP    DEFAULT NOW()
);

INSERT INTO seller (name, email, category, rating) VALUES
    ('Tech Galaxy',      'contact@techgalaxy.com',    'electronics',  4.80),
    ('Bookworm Store',   'hello@bookworm.com',        'books',        4.60),
    ('Fashion Hub',      'sales@fashionhub.com',      'clothing',     4.30),
    ('Home & Deco',      'info@homedeco.com',         'home',         4.70),
    ('Sport Zone',       'support@sportzone.com',     'sports',       4.50),
    ('Gamer World',      'info@gamerworld.com',        'electronics',  4.90),
    ('Kitchen Masters',  'hello@kitchenmasters.com',  'home',         4.40),
    ('Outdoor Life',     'team@outdoorlife.com',      'sports',       4.20),
    ('Urban Threads',    'contact@urbanthreads.com',  'clothing',     4.10),
    ('Page Turner',      'books@pageturner.com',      'books',        4.75);

INSERT INTO product (id_seller, name, description, price, stock, category) VALUES
    (1, 'Wireless Headphones Pro',  'Noise-cancelling over-ear headphones', 299.99, 150, 'electronics'),
    (1, 'USB-C Hub 7-in-1',         'Multi-port USB-C hub for laptops',      49.99, 320, 'electronics'),
    (2, 'Clean Code',               'A handbook of agile software craftsmanship', 39.90, 80, 'books'),
    (2, 'The Pragmatic Programmer', 'From journeyman to master',             44.90, 60,  'books'),
    (3, 'Slim Fit Chinos',          'Casual slim fit chino trousers',        89.90, 200, 'clothing'),
    (3, 'Merino Wool Sweater',      '100% merino wool crew neck sweater',   129.90, 90,  'clothing'),
    (4, 'Bamboo Desk Organizer',    'Eco-friendly desktop organizer',        34.90, 180, 'home'),
    (4, 'Scented Candle Set',       'Set of 3 soy wax scented candles',      29.90, 250, 'home'),
    (5, 'Yoga Mat Pro',             'Non-slip 6mm thick yoga mat',           59.90, 300, 'sports'),
    (6, 'Mechanical Keyboard TKL',  'Tenkeyless mechanical keyboard, red switches', 179.99, 75, 'electronics'),
    (6, 'Gaming Mouse 16K DPI',     'Optical gaming mouse with RGB',         99.99, 120, 'electronics'),
    (7, 'Cast Iron Skillet 10"',    'Pre-seasoned cast iron skillet',        79.90, 95,  'home'),
    (8, 'Trekking Poles Carbon',    'Lightweight carbon fibre trekking poles', 149.90, 55, 'sports'),
    (9, 'Linen Shirt',              'Relaxed fit pure linen shirt',          99.90, 140, 'clothing'),
    (10, 'Design Patterns',         'Elements of reusable object-oriented software', 49.90, 45, 'books');

INSERT INTO orders (id_product, id_seller, buyer_email, quantity, unit_price, total_amount, status, ordered_at, updated_at) VALUES
    (1,  1,  'alice@example.com',   1, 299.99,  299.99, 'delivered',  '2024-01-03 09:12:00', '2024-01-03 09:12:00'),
    (3,  2,  'bob@example.com',     2,  39.90,   79.80, 'delivered',  '2024-01-05 14:30:00', '2024-01-05 14:30:00'),
    (5,  3,  'carol@example.com',   1,  89.90,   89.90, 'shipped',    '2024-01-07 11:00:00', '2024-01-07 11:00:00'),
    (9,  5,  'dave@example.com',    1,  59.90,   59.90, 'delivered',  '2024-01-08 16:45:00', '2024-01-08 16:45:00'),
    (10, 6,  'eve@example.com',     1, 179.99,  179.99, 'delivered',  '2024-01-10 10:20:00', '2024-01-10 10:20:00'),
    (2,  1,  'frank@example.com',   2,  49.99,   99.98, 'pending',    '2024-01-12 08:55:00', '2024-01-12 08:55:00'),
    (4,  2,  'grace@example.com',   1,  44.90,   44.90, 'shipped',    '2024-01-13 13:15:00', '2024-01-13 13:15:00'),
    (7,  4,  'henry@example.com',   1,  34.90,   34.90, 'delivered',  '2024-01-14 09:40:00', '2024-01-14 09:40:00'),
    (11, 6,  'irene@example.com',   1,  99.99,   99.99, 'delivered',  '2024-01-15 17:00:00', '2024-01-15 17:00:00'),
    (12, 7,  'james@example.com',   1,  79.90,   79.90, 'pending',    '2024-01-16 12:10:00', '2024-01-16 12:10:00'),
    (6,  3,  'kate@example.com',    2, 129.90,  259.80, 'shipped',    '2024-01-17 10:30:00', '2024-01-17 10:30:00'),
    (13, 8,  'liam@example.com',    1, 149.90,  149.90, 'delivered',  '2024-01-18 14:50:00', '2024-01-18 14:50:00'),
    (14, 9,  'mia@example.com',     1,  99.90,   99.90, 'pending',    '2024-01-19 09:05:00', '2024-01-19 09:05:00'),
    (15, 10, 'noah@example.com',    1,  49.90,   49.90, 'delivered',  '2024-01-20 11:25:00', '2024-01-20 11:25:00'),
    (8,  4,  'olivia@example.com',  3,  29.90,   89.70, 'shipped',    '2024-01-21 15:35:00', '2024-01-21 15:35:00'),
    (1,  1,  'paul@example.com',    1, 299.99,  299.99, 'delivered',  '2024-01-22 08:00:00', '2024-01-22 08:00:00'),
    (3,  2,  'quinn@example.com',   1,  39.90,   39.90, 'delivered',  '2024-01-23 10:45:00', '2024-01-23 10:45:00'),
    (10, 6,  'rose@example.com',    1, 179.99,  179.99, 'pending',    '2024-01-24 13:00:00', '2024-01-24 13:00:00'),
    (9,  5,  'sam@example.com',     2,  59.90,  119.80, 'shipped',    '2024-01-25 09:20:00', '2024-01-25 09:20:00'),
    (2,  1,  'tina@example.com',    1,  49.99,   49.99, 'delivered',  '2024-01-26 16:30:00', '2024-01-26 16:30:00'),
    (5,  3,  'uma@example.com',     1,  89.90,   89.90, 'delivered',  '2024-01-27 11:10:00', '2024-01-27 11:10:00'),
    (11, 6,  'victor@example.com',  1,  99.99,   99.99, 'shipped',    '2024-01-28 14:15:00', '2024-01-28 14:15:00'),
    (4,  2,  'wendy@example.com',   2,  44.90,   89.80, 'delivered',  '2024-01-29 10:00:00', '2024-01-29 10:00:00'),
    (7,  4,  'xena@example.com',    1,  34.90,   34.90, 'pending',    '2024-01-30 08:45:00', '2024-01-30 08:45:00'),
    (13, 8,  'yara@example.com',    1, 149.90,  149.90, 'delivered',  '2024-01-31 15:55:00', '2024-01-31 15:55:00'),
    (6,  3,  'zoe@example.com',     1, 129.90,  129.90, 'delivered',  '2024-02-01 09:30:00', '2024-02-01 09:30:00'),
    (12, 7,  'adam@example.com',    1,  79.90,   79.90, 'shipped',    '2024-02-02 13:40:00', '2024-02-02 13:40:00'),
    (15, 10, 'bella@example.com',   2,  49.90,   99.80, 'delivered',  '2024-02-03 11:50:00', '2024-02-03 11:50:00'),
    (8,  4,  'carlos@example.com',  1,  29.90,   29.90, 'pending',    '2024-02-04 16:00:00', '2024-02-04 16:00:00'),
    (14, 9,  'diana@example.com',   2,  99.90,  199.80, 'delivered',  '2024-02-05 10:15:00', '2024-02-05 10:15:00');
