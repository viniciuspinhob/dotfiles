#!/bin/sh
set -e

UC_URL="http://unity-catalog:8080/api/2.1/unity-catalog"

echo "Waiting for Unity Catalog..."
until curl -sf "$UC_URL/catalogs" > /dev/null 2>&1; do
  sleep 2
done

for CATALOG in dataduct_curated dataduct_analytics; do
  if curl -sf "$UC_URL/catalogs/$CATALOG" > /dev/null 2>&1; then
    echo "Catalog $CATALOG already exists, skipping."
  else
    curl -sf -X POST "$UC_URL/catalogs" \
      -H "Content-Type: application/json" \
      -d "{\"name\": \"$CATALOG\", \"comment\": \"$CATALOG catalog\"}" > /dev/null
    echo "Catalog $CATALOG created."
  fi
done

for SCHEMA_DEF in "dataduct_curated:marketplace" "dataduct_curated:default" "dataduct_analytics:default"; do
  CATALOG="${SCHEMA_DEF%%:*}"
  SCHEMA="${SCHEMA_DEF##*:}"
  if curl -sf "$UC_URL/schemas/$CATALOG.$SCHEMA" > /dev/null 2>&1; then
    echo "Schema $CATALOG.$SCHEMA already exists, skipping."
  else
    curl -sf -X POST "$UC_URL/schemas" \
      -H "Content-Type: application/json" \
      -d "{\"name\": \"$SCHEMA\", \"catalog_name\": \"$CATALOG\", \"comment\": \"$SCHEMA schema\"}" > /dev/null
    echo "Schema $CATALOG.$SCHEMA created."
  fi
done

echo "Unity Catalog bootstrap complete."
echo "  Catalogs: dataduct_curated, dataduct_analytics"
