#!/bin/sh
set -e

WORKSPACE="/opt/cloudbeaver/workspace"
DATASOURCES_DIR="$WORKSPACE/GlobalConfiguration/.dbeaver"
DATASOURCES_FILE="$DATASOURCES_DIR/data-sources.json"
DB_DIR="$WORKSPACE/.data"

if [ -d "$DB_DIR" ] && [ ! -f "$DATASOURCES_FILE" ]; then
    rm -rf "$DB_DIR"
fi

mkdir -p "$DATASOURCES_DIR"

if [ ! -f "$DATASOURCES_FILE" ]; then
    cp /opt/cloudbeaver/init/data-sources.json "$DATASOURCES_FILE"
fi

exec /opt/cloudbeaver/run-cloudbeaver-server.sh
