#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV="$SCRIPT_DIR/.venv311"
LOG_DIR="$SCRIPT_DIR/.logs"
LOG_FILE="$LOG_DIR/orders_pipeline_$(date +%Y%m%d_%H%M%S).log"

mkdir -p "$LOG_DIR"

export DB_HOST="${DB_HOST:-localhost}"
export DB_USER="${DB_USER:-dataduct}"
export DB_PASS="${DB_PASS:-dataduct123}"
export AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID:-minioadmin}"
export AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY:-minioadmin123}"
export AWS_ENDPOINT_URL="${AWS_ENDPOINT_URL:-http://localhost:19000}"
export AWS_DEFAULT_REGION="${AWS_DEFAULT_REGION:-us-east-1}"

log() { echo "[$(date '+%H:%M:%S')] $*" | tee -a "$LOG_FILE"; }

log "=== Orders Marketplace Pipeline ==="
log "Log: $LOG_FILE"

log "--- Etapa 1: PostgreSQL -> dataduct-raw ---"
"$VENV/bin/python" -m dataduct run --job examples.orders_marketplace.jdbc_to_raw 2>&1 | tee -a "$LOG_FILE"
log "--- Etapa 1 concluida ---"

log "--- Etapa 2: dataduct-raw -> dataduct-curated + Unity Catalog ---"
"$VENV/bin/python" -m dataduct run --job examples.orders_marketplace.raw_to_curated 2>&1 | tee -a "$LOG_FILE"
log "--- Etapa 2 concluida ---"

log "=== Pipeline concluido. Log: $LOG_FILE ==="
