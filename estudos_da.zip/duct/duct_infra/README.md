# duct_infra

Infraestrutura local de desenvolvimento para o ecossistema **dataduct**.

Sobe todos os serviços necessários para rodar pipelines de dados localmente via Docker Compose.

## Serviços

| Serviço | Porta | Descrição |
|---------|-------|-----------|
| PostgreSQL | 5432 | Banco relacional (source/sink) |
| MinIO | 19000 / 19001 | Object storage S3-compatible |
| Unity Catalog | 8080 | Catálogo de dados |
| Unity Catalog UI | 3000 | Interface web do catálogo |
| Trino | 8085 | Query engine SQL distribuído |
| CloudBeaver | 8978 | IDE SQL web |
| dataduct-dev | - | Container de desenvolvimento |

## Quick Start

```bash
# Copiar variáveis de ambiente
cp .env.example .env

# Baixar JARs Spark/JDBC/Delta (primeira vez ou após limpar jars/)
make download-jars

# Subir todos os serviços
make up

# Verificar status
make ps

# Ver logs
make logs

# Parar e remover tudo
make down
```

## Pré-requisitos

- Docker + Docker Compose v2+
- **Repos irmãos** no mesmo diretório pai (não é monorepo):

```
tools/duct/   # ou qualquer pasta pai
├── dataduct/            # biblioteca ETL + DataductOperator
├── dataduct-examples/   # jobs de referência (pacote examples.*)
└── duct_infra/          # este repo — stack Docker local
```

O `docker-compose.yml` monta `../dataduct` e `../dataduct-examples` nos containers `dataduct-dev` e `airflow-scheduler`.

## Estrutura

```
duct_infra/
├── docker-compose.yml    # Orquestração dos serviços
├── docker/               # Configs por serviço
│   ├── dataduct-dev/     # Container dev + jars/ (JDBC, S3A, Delta)
│   ├── airflow/          # Imagem Airflow + DataductOperator
│   ├── cloudbeaver/
│   ├── minio/
│   ├── postgres/
│   ├── trino/
│   └── unity-catalog/
├── scripts/
│   └── download-jars.sh  # Baixa JARs do Maven Central
├── dags/                 # DAGs locais (sync via MinIO → Airflow)
├── .env.example          # Template de variáveis
├── Makefile              # Comandos de conveniência
└── docs/                 # Guias detalhados
```

## Relação com outros repos

| Repo | Papel |
|------|-------|
| **dataduct** | Framework ETL, conectores, `DataductOperator` (`pip install -e ../dataduct[all]`) |
| **dataduct-examples** | Jobs de referência e DAGs de exemplo (`pip install -e ../dataduct-examples`) |
| **duct_infra** | Postgres, MinIO, Unity Catalog, Airflow, Trino — ambiente local |

### Airflow local

```bash
# Stack com Airflow (profile airflow)
docker compose --profile airflow up -d
make dags-upload
# UI: http://localhost:8082  (airflow / airflow123)
```

O DAG `orders_marketplace_pipeline` usa `DataductOperator` e jobs `examples.orders_marketplace.*`.

### JARs pré-baixados

`make download-jars` popula `docker/dataduct-dev/jars/`:

| JAR | Uso |
|-----|-----|
| `postgresql-*.jar` | JDBC PostgreSQL |
| `hadoop-aws-*.jar` + `aws-java-sdk-bundle-*.jar` | S3A (MinIO) no Spark |
| `delta-spark_2.12-*.jar` + `delta-storage-*.jar` | Delta Lake no Spark |
