import os
from datetime import datetime, timedelta

from airflow import DAG
from dataduct.integrations.airflow import DataductOperator

default_args = {
    "owner": "dataduct",
    "depends_on_past": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    dag_id="orders_marketplace_pipeline",
    default_args=default_args,
    description="Pipeline orders marketplace: PostgreSQL -> raw -> curated",
    schedule="@daily",
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=["dataduct", "marketplace"],
    doc_md="""
    ## Orders Marketplace Pipeline

    Uses :class:`~dataduct.integrations.airflow.DataductOperator` to run
    dataduct jobs in-process on the Airflow worker.

    1. ``jdbc_to_raw`` — PostgreSQL orders → Raw Zone (Parquet on MinIO)
    2. ``raw_to_curated`` — filter, enrich, catalog in Curated Zone
    """,
) as dag:

    jdbc_to_raw = DataductOperator(
        task_id="jdbc_to_raw",
        job_package_name="examples.orders_marketplace.jdbc_to_raw",
        engine="spark",
        env="dev",
        custom={"dt_referencia": "{{ ds }}"},
    )

    raw_to_curated = DataductOperator(
        task_id="raw_to_curated",
        job_package_name="examples.orders_marketplace.raw_to_curated",
        engine="spark",
        env="dev",
        custom={"dt_referencia": "{{ ds }}"},
    )

    jdbc_to_raw >> raw_to_curated
