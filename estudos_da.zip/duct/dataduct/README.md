# dataduct

Framework ETL leve, modular e engine-agnostic. Versão simplificada do [dede](../dede/) com arquitetura de plugins para fácil extensão.

## Filosofia

- **Config-driven**: Jobs definidos por YAML, lógica de negócio isolada em Python
- **Engine-agnostic**: Troque entre Spark e DuckDB sem alterar o código do job
- **Modular por design**: Adicionar engines (dbt, Polars) ou conectores (Delta, Kafka) = criar um diretório
- **Zero cloud no core**: Dependências de cloud (boto3, etc) são opcionais e lazy-loaded
- **Seguro por padrão**: Sem `eval()`, SQL parametrizado, validação de config na inicialização
- **Simplicidade**: Menos código, menos abstrações, mais produtividade

---

## Pré-requisitos

| Dependência | Versão mínima | Obrigatório |
|-------------|--------------|-------------|
| Python | 3.11+ | Sim |
| Java (JDK) | 17+ | Apenas para Spark |
| PySpark | 3.5.x | Apenas para engine Spark |
| DuckDB | 0.10+ | Apenas para engine DuckDB |

> **Recomendado**: Python 3.11 com PySpark 3.5.3 (combinação testada e validada).

---

## Instalação

### Setup rápido (recomendado)

```bash
# Cria venv com Python 3.11 e instala tudo
make venv
make install-all
```

### Manual por extras

```bash
# Core apenas (YAML + CLI)
pip install -e .

# Com DuckDB (processamento local)
pip install -e ".[duckdb]"

# Com Spark
pip install -e ".[spark]"

# Com suporte a S3/MinIO
pip install -e ".[aws]"

# Tudo (todas as engines + cloud)
pip install -e ".[all]"

# Dev (testes + linting)
pip install -e ".[dev]"

# Dev completo
make install-all
```

---

## Quick Start

### 1. Estrutura de um job

```
meu_dominio/
├── __init__.py
├── config.yaml           # config do domínio (compartilhada)
│
└── meu_job/
    ├── __init__.py
    ├── config.yaml       # config específica do job
    ├── config-dev.yaml   # overlay para desenvolvimento
    └── job.py            # lógica de negócio
```

### 2. config.yaml

```yaml
type: python
engine: duckdb          # ou spark

sources:
  - name: vendas
    format: csv
    path: "data/vendas.csv"
    header: true

sinks:
  - name: vendas_filtradas
    format: parquet
    path: "/tmp/output/vendas_filtradas.parquet"
    mode: overwrite

custom:
  ano: "2024"
```

### 3. job.py

```python
from dataduct.core.job.base import Job


class VendasJob(Job):
    def run(self):
        ano = self.custom.get("ano")
        resultado = self.engine.execute_sql(
            f"SELECT * FROM vendas WHERE ano = '{ano}'"
        )
        self.sinks.vendas_filtradas.save(resultado)
```

### 4. Executar

```bash
# DuckDB (local, rápido)
python -m dataduct run --job meu_dominio.meu_job --engine duckdb

# Spark
python -m dataduct run --job meu_dominio.meu_job --engine spark

# Com ambiente (carrega config-dev.yaml)
python -m dataduct run --job meu_dominio.meu_job --env dev --engine duckdb

# Com custom args via CLI
python -m dataduct run --job meu_dominio.meu_job -c '{"ano": "2025"}'

# Dry-run: valida config sem executar
python -m dataduct run --job meu_dominio.meu_job --dry-run

# Debug verboso
python -m dataduct --verbose run --job meu_dominio.meu_job
```

---

## Estrutura do Projeto

```
dataduct/
├── pyproject.toml                    # Definição do pacote, extras, tooling
├── Makefile                          # Targets: venv, install-all, test, lint, format
│
├── dataduct/
│   ├── __init__.py                   # __version__, exports públicos
│   ├── __main__.py                   # CLI: run --job --env --engine --custom --verbose
│   │
│   ├── core/
│   │   ├── config.py                 # YAML parse, merge hierárquico, Jinja2 seguro
│   │   ├── exceptions.py             # Exceções tipadas do framework
│   │   ├── registry.py              # Plugin registry (engines + connectors)
│   │   ├── validators.py            # Validação de config YAML antes de executar
│   │   └── job/
│   │       ├── base.py               # Job ABC, Steps (before/after hooks), try/finally
│   │       └── factory.py            # JobFactory: config → Job instance
│   │
│   ├── engines/
│   │   ├── base.py                   # EngineAdapter ABC
│   │   ├── spark/adapter.py          # SparkEngineAdapter (PySpark 3.5.x)
│   │   └── duckdb/adapter.py         # DuckDBEngineAdapter (mode, partition_by, settings whitelist)
│   │
│   ├── connectors/
│   │   ├── base.py                   # BaseExtractor, BaseLoader ABCs + set_catalog()
│   │   ├── csv/                      # CSV extractor + loader
│   │   ├── parquet/                  # Parquet extractor + loader
│   │   ├── jdbc/                     # JDBC extractor + loader
│   │   └── object_storage/           # S3/MinIO extractor + loader
│   │
│   ├── services/
│   │   ├── credentials.py            # Resolução de credenciais (env vars, direct com warning)
│   │   ├── masking/                  # Anonimização PII declarativa
│   │   │   ├── base.py               # MaskingProvider ABC
│   │   │   └── hash.py               # HashMaskingProvider (SHA256, MD5)
│   │   └── catalog/                  # Catalogação declarativa
│   │       ├── base.py               # CatalogProvider ABC
│   │       ├── glue.py               # AWS Glue Data Catalog
│   │       └── unity.py             # Databricks Unity Catalog
│   │
│   └── utils/
│       └── bunch.py                  # Dict com acesso por atributo
│
├── tests/
│   ├── conftest.py
│   ├── test_cli.py                   # Testes da CLI com CliRunner
│   ├── test_config.py                # Helpers de config
│   ├── test_config_extended.py       # build(), _render_jinja, edge cases
│   ├── test_validators.py            # 16 cenários de validação YAML
│   ├── test_job.py                   # Job ABC, Steps
│   ├── test_job_factory_e2e.py       # JobFactory + 2 testes e2e completos
│   ├── test_bunch.py
│   ├── test_registry.py
│   ├── connectors/                   # Testes por conector
│   ├── engines/                      # Testes por engine (Spark + DuckDB)
│   └── services/                     # Testes de masking e catalog
│
└── docs/
    ├── architecture.md               # Camadas, fluxo, patterns, segurança
    ├── config.md                     # YAML hierárquico, merge, Jinja2, validação
    ├── engines.md                    # EngineAdapter, Spark, DuckDB
    ├── connectors.md                 # CSV, Parquet, JDBC, Object Storage
    ├── services.md                   # Masking PII, Catalog (Glue/Unity)
    ├── extending.md                  # Guia para adicionar engines/connectors/services
    └── TECH_DEBT.md                  # Débitos técnicos pendentes
```

## Repos Relacionados

| Repo | Descrição |
|------|-----------|
| **duct_infra** | Infraestrutura Docker local (Postgres, MinIO, Trino, Unity Catalog) |
| **dataduct-examples** | Exemplos de pipelines usando dataduct |

---

## Engines Disponíveis

| Engine | Versão testada | Instalação | Flag |
|--------|---------------|------------|------|
| **DuckDB** | 1.5.x | `pip install duckdb pyarrow` | `--engine duckdb` |
| **Spark** | 3.5.3 | `pip install pyspark==3.5.3` | `--engine spark` |

---

## Conectores Disponíveis

| Formato | Descrição | Extras necessários |
|---------|-----------|-------------------|
| `csv` | Arquivos CSV locais ou S3 | — |
| `parquet` | Arquivos Parquet locais ou S3 | `pyarrow` |
| `jdbc` | PostgreSQL, MySQL, SQL Server, Oracle | Driver JDBC do banco |
| `object_storage` | S3 / MinIO (boto3 ou s3a://) | `boto3` |

---

## Serviços Integrados

Serviços são ativados **declarativamente no YAML** — sem alterar o `job.py`.

### Masking PII (anonimização)

```yaml
sources:
  - name: clientes
    format: parquet
    path: "s3a://bucket/raw/clientes/"
    masking:
      provider: hash        # único provider na v1
      columns:
        - column: cpf
          algorithm: sha256  # ou md5
        - column: email
          algorithm: sha256
```

- Hash one-way (irreversível), determinístico
- Engine-agnostic: DuckDB usa `sha256()`, Spark usa `sha2()`
- Colunas não listadas passam intactas

### Catalogação de tabelas

```yaml
sinks:
  - name: resultado
    format: parquet
    path: "s3a://bucket/curated/resultado/"
    partition_by: ["dt_referencia"]
    catalog:
      provider: glue       # ou unity
      database: "meu_dominio_curated"
      table_name: "resultado"
      description: "Resultado processado"
      region: "us-east-1"  # para Glue
```

| Provider | Status | Requisito |
|----------|--------|-----------|
| `glue` | Funcional | `boto3` |
| `unity` | Funcional | SparkSession + Databricks |

---

## Configuração Hierárquica

```
CLI --custom  >  config-{env}.yaml  >  config.yaml  >  parent config  >  defaults
```

### Jinja2 + variáveis de ambiente

```yaml
sources:
  - name: dados
    format: parquet
    path: "s3://{{ env_var('BUCKET_NAME') }}/{{ dominio }}/{{ dt_referencia }}/"
```

### Validação automática

O config é validado antes de executar. Erros são reportados todos de uma vez:

```
ConfigError: Config validation failed:
  - sources[0]: missing required field 'name'
  - sinks[1].catalog: missing required field 'table_name'
  - engine: must be one of ['duckdb', 'spark'], got 'polars'
```

---

## Desenvolvimento

```bash
# Ambiente Python 3.11 + todas as deps
make venv && make install-all

# Testes completos
make test

# Apenas Spark
make test-spark

# Apenas DuckDB
make test-duckdb

# Cobertura
make test-cov

# Lint
make lint

# Formatar código
make format
```

### Estado dos testes

```
122 passed, 0 skipped  (Python 3.11 + PySpark 3.5.3 + DuckDB 1.5.4)
```

---

## Segurança

- **Sem `eval()`**: config Jinja2 renderizado via `ast.literal_eval` + `yaml.safe_load`
- **SQL sanitizado**: paths e identificadores escapados no DuckDB adapter
- **Identifiers validados**: Glue e Unity Catalog validam nomes via regex antes de executar SQL
- **Credenciais**: tipo `direct` (plaintext) gera warning em log; use `env` em produção
- **Path traversal bloqueado**: `..` em paths no DuckDB lança `ValueError`
- **Settings whitelist**: configurações DuckDB limitadas a lista de keys permitidas

---

## Documentação Técnica

- [Arquitetura](docs/architecture.md) — Camadas, fluxo de execução, patterns, segurança, logging
- [Configuração](docs/config.md) — YAML hierárquico, merge, Jinja2, validação automática
- [Engines](docs/engines.md) — EngineAdapter ABC, Spark, DuckDB (mode, partition_by)
- [Conectores](docs/connectors.md) — CSV, Parquet, JDBC, Object Storage, opções completas
- [Serviços](docs/services.md) — Masking PII, Catalog Glue/Unity, como criar novo serviço
- [Extensibilidade](docs/extending.md) — Guia para adicionar engines, conectores, serviços
- [Débitos Técnicos](docs/TECH_DEBT.md) — Itens pendentes priorizados
- [Changelog](CHANGELOG.md) — Histórico de versões

---

## Licença

Proprietary — Inter Data Engineer Team
