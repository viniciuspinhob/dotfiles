# Changelog

Todas as mudanças notáveis do projeto são documentadas neste arquivo.

Formato baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.1.0/).

---

## [0.1.0] — 2026-07-08

Versão inicial do dataduct. Framework ETL leve, modular e engine-agnostic, construído como versão simplificada do dede original com foco em extensibilidade e segurança.

### Adicionado

#### Core
- `core/config.py` — Parser YAML com hierarquia de pacotes, deep merge recursivo, Jinja2 seguro (`ast.literal_eval` + `yaml.safe_load`, sem `eval()`)
- `core/validators.py` — Validação de schema do config antes de executar, com erros cumulativos
- `core/registry.py` — Plugin registry global para engines e connectors via decorators
- `core/exceptions.py` — Exceções tipadas do framework (`ConfigError`, `JobNotFound`, `EngineNotFound`, etc.)
- `core/job/base.py` — `Job` ABC com ciclo de vida (`execute()` com `try/finally`), `Steps` (hooks before/after)
- `core/job/factory.py` — `JobFactory`: resolve package → config → Job instance
- `core/jinja_functions.py` — Funções Jinja2 seguras (`env_var`, `get_env_var`)

#### Engines
- `engines/spark/adapter.py` — `SparkEngineAdapter` funcional (PySpark 3.5.x, Python 3.11+)
- `engines/duckdb/adapter.py` — `DuckDBEngineAdapter` funcional com:
  - `mode: append` para Parquet (via merge temporário)
  - `partition_by` via `COPY ... PARTITION_BY`
  - Settings whitelist de segurança
  - Path sanitization e path traversal bloqueado

#### Conectores
- `connectors/csv/` — CSV extractor + loader (header, delimiter, partition_by)
- `connectors/parquet/` — Parquet extractor + loader (schema, partition_by)
- `connectors/jdbc/` — JDBC extractor + loader (table, query, driver, credentials)
- `connectors/object_storage/` — S3/MinIO extractor + loader (s3a:// via engine ou boto3 direto)
- `connectors/base.py` — `BaseExtractor`, `BaseLoader` ABCs com `set_catalog()` público

#### Serviços
- `services/credentials.py` — Resolução de credenciais por env vars; warning em `type: direct`
- `services/masking/hash.py` — `HashMaskingProvider` funcional (SHA256, MD5), engine-agnostic, UUIDs para temp tables
- `services/masking/base.py` — `MaskingProvider` ABC extensível
- `services/catalog/glue.py` — `GlueCatalogProvider` (boto3): cria/atualiza tabelas no AWS Glue, extrai schema de Spark/pandas DataFrames, identifiers validados por regex
- `services/catalog/unity.py` — `UnityCatalogProvider` (Spark SQL): cria tabelas no Databricks Unity Catalog, identifiers escapados, SQL injection mitigado
- `services/catalog/base.py` — `CatalogProvider` ABC extensível

#### CLI
- `__main__.py` — CLI via Click: `run --job --env --engine --custom --dry-run --verbose`
  - Logging configurável (`--verbose` ativa DEBUG, silencia py4j/pyspark)
  - Mensagens de erro claras para JSON inválido, engine não encontrada, job não encontrado
  - `try/finally` garante `engine.stop_session()` mesmo em falha

#### Utils
- `utils/bunch.py` — `Bunch`: dict com acesso por atributo

#### Exemplos
- `examples/csv_to_parquet/` — Job funcional de exemplo (CSV → Parquet com DuckDB)

#### Testes
- 122 testes cobrindo: CLI, config (build, merge, Jinja2), validators, Job/Steps, JobFactory, e2e, engines (Spark + DuckDB), conectores (CSV, Parquet, JDBC, Object Storage), masking (SHA256, MD5, edge cases), catalog (Glue, Unity)
- 0 skips com Python 3.11 + PySpark 3.5.3 + DuckDB 1.5.4

#### Documentação
- `README.md` — Overview, pré-requisitos, instalação, quick start, estrutura completa, serviços, segurança
- `docs/architecture.md` — Camadas, fluxo de execução completo, patterns, segurança, logging, error handling
- `docs/config.md` — YAML hierárquico, merge, Jinja2 seguro, validação automática
- `docs/engines.md` — EngineAdapter ABC, Spark (com notas macOS), DuckDB (mode, partition_by, settings)
- `docs/connectors.md` — CSV, Parquet, JDBC, Object Storage com todas as opções
- `docs/services.md` — Masking PII, Catalog (Glue/Unity), como criar novo serviço
- `docs/extending.md` — Guia prático: nova engine, novo conector, novo serviço, dbt
- `docs/TECH_DEBT.md` — Débitos técnicos pendentes priorizados
- `CHANGELOG.md` — Este arquivo

### Segurança

- Removido `eval()` do pipeline de config — substituído por `ast.literal_eval` + `yaml.safe_load`
- SQL injection mitigado no DuckDB adapter (sanitização de paths e identifiers)
- SQL injection mitigado em Unity e Glue catalog (validação regex de identifiers)
- Credenciais `type: direct` emitem warning explícito
- Path traversal (`..`) bloqueado no DuckDB adapter
- Settings DuckDB limitados a allowlist de chaves seguras

### Ambiente validado

| Componente | Versão |
|-----------|--------|
| Python | 3.11.15 |
| PySpark | 3.5.3 |
| DuckDB | 1.5.4 |
| Java (JDK) | 17.0.2 |
| macOS | darwin (arm64) |
