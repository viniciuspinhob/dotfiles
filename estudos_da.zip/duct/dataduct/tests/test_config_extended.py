import textwrap

import pytest

from dataduct.core.config import (
    build,
    deep_merge_dict,
    _build_package_tree,
    _merge_list_elements,
    _render_jinja,
)


class TestRenderJinja:
    def test_renders_string_variable(self):
        result = _render_jinja("[{'path': '{{ bucket }}'}]", {"bucket": "my-bucket"})
        assert result == [{"path": "my-bucket"}]

    def test_returns_string_when_not_parseable(self):
        result = _render_jinja("hello {{ name }}", {"name": "world"})
        assert result == "hello world"

    def test_renders_nested_dict(self):
        obj = [{"name": "src", "path": "{{ base }}/data"}]
        result = _render_jinja(obj, {"base": "/tmp"})
        assert result[0]["path"] == "/tmp/data"

    def test_does_not_execute_code(self):
        malicious = "__import__('os').system('echo PWNED')"
        result = _render_jinja(malicious, {})
        assert result == malicious

    def test_env_var_function(self, monkeypatch):
        monkeypatch.setenv("TEST_BUCKET", "s3://my-bucket")
        result = _render_jinja("{{ env_var('TEST_BUCKET') }}", {})
        assert result == "s3://my-bucket"

    def test_env_var_default(self):
        result = _render_jinja("{{ env_var('NONEXISTENT_XYZ_VAR', 'default_val') }}", {})
        assert result == "default_val"

    def test_numbers_preserved(self):
        result = _render_jinja("[{'limit': 100}]", {})
        assert result == [{"limit": 100}]

    def test_booleans_preserved(self):
        result = _render_jinja("[{'flag': True}]", {})
        assert result == [{"flag": True}]


class TestBuildPackageTree:
    def test_nested_package(self):
        tree = _build_package_tree("a.b.c.d")
        assert tree == ["a.b.c.d", "a.b.c", "a.b", "a"]

    def test_single_package(self):
        assert _build_package_tree("mypackage") == ["mypackage"]

    def test_invalid_empty_raises(self):
        with pytest.raises(ValueError):
            _build_package_tree("")

    def test_strips_leading_dots(self):
        tree = _build_package_tree(".foo.bar")
        assert "foo.bar" in tree


class TestDeepMergeDictEdgeCases:
    def test_none_parent_returns_child(self):
        result = deep_merge_dict(None, {"a": 1})
        assert result == {"a": 1}

    def test_none_child_returns_parent(self):
        result = deep_merge_dict({"a": 1}, None)
        assert result == {"a": 1}

    def test_empty_dicts(self):
        assert deep_merge_dict({}, {}) == {}

    def test_deeply_nested(self):
        parent = {"a": {"b": {"c": 1, "d": 2}}}
        child = {"a": {"b": {"c": 99}}}
        result = deep_merge_dict(parent, child)
        assert result["a"]["b"]["c"] == 99
        assert result["a"]["b"]["d"] == 2


class TestMergeListElements:
    def test_named_items_merged(self):
        parent = [{"name": "x", "format": "csv", "path": "/old"}]
        child = [{"name": "x", "path": "/new"}]
        result = _merge_list_elements(parent, child)
        assert len(result) == 1
        assert result[0]["path"] == "/new"
        assert result[0]["format"] == "csv"

    def test_unnamed_items_not_merged(self):
        parent = [{"value": 1}]
        child = [{"value": 2}]
        result = _merge_list_elements(parent, child)
        assert len(result) >= 1

    def test_child_adds_new_named_items(self):
        parent = [{"name": "a", "x": 1}]
        child = [{"name": "b", "y": 2}]
        result = _merge_list_elements(parent, child)
        names = [r.get("name") for r in result]
        assert "a" in names
        assert "b" in names

    def test_empty_parent_returns_child(self):
        assert _merge_list_elements([], [{"name": "x"}]) == [{"name": "x"}]

    def test_empty_child_returns_parent(self):
        assert _merge_list_elements([{"name": "x"}], []) == [{"name": "x"}]


class TestConfigBuild:
    def test_build_from_package(self, tmp_path):
        pkg = tmp_path / "myjob_test_pkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        (pkg / "config.yaml").write_text(textwrap.dedent("""
            type: python
            engine: duckdb
            sources:
              - name: src
                format: csv
                path: /tmp/data.csv
            sinks:
              - name: out
                format: parquet
                path: /tmp/out/
        """))

        import sys as _sys
        _sys.path.insert(0, str(tmp_path))
        try:
            config = build("myjob_test_pkg")
        finally:
            _sys.path.pop(0)

        assert config["engine"] == "duckdb"
        assert config["sources"][0]["name"] == "src"
        assert config["sinks"][0]["name"] == "out"
        assert "job_package_name" in config
        assert "dt_execution" in config

    def test_build_applies_custom(self, tmp_path):
        pkg = tmp_path / "customjob_test_pkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        (pkg / "config.yaml").write_text(textwrap.dedent("""
            type: python
            engine: duckdb
            sources:
              - name: src
                format: csv
                path: "{{ base_path }}/data.csv"
            sinks:
              - name: out
                format: parquet
                path: /tmp/out/
            custom:
              base_path: /default
        """))

        import sys as _sys
        _sys.path.insert(0, str(tmp_path))
        try:
            config = build("customjob_test_pkg", orchestration_config={"base_path": "/override"})
        finally:
            _sys.path.pop(0)

        assert "/override/data.csv" in config["sources"][0]["path"]
