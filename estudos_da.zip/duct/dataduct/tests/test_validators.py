
import pytest

from dataduct.core.validators import validate_config
from dataduct.core.exceptions import ConfigError


class TestValidateConfig:
    def test_valid_minimal_config(self):
        validate_config({
            "sources": [{"name": "s", "format": "csv", "path": "/tmp/x.csv"}],
            "sinks": [{"name": "t", "format": "parquet", "path": "/tmp/out/"}],
        })

    def test_missing_sources_and_sinks_raises(self):
        with pytest.raises(ConfigError, match="at least one"):
            validate_config({"engine": "duckdb"})

    def test_source_missing_name_raises(self):
        with pytest.raises(ConfigError, match="name"):
            validate_config({
                "sources": [{"format": "csv", "path": "/tmp/x.csv"}],
                "sinks": [{"name": "t", "format": "parquet", "path": "/tmp/y/"}],
            })

    def test_source_missing_format_raises(self):
        with pytest.raises(ConfigError, match="format"):
            validate_config({
                "sources": [{"name": "s", "path": "/tmp/x.csv"}],
                "sinks": [{"name": "t", "format": "parquet", "path": "/tmp/y/"}],
            })

    def test_sink_missing_name_raises(self):
        with pytest.raises(ConfigError, match="name"):
            validate_config({
                "sources": [{"name": "s", "format": "csv", "path": "/tmp/x.csv"}],
                "sinks": [{"format": "parquet", "path": "/tmp/y/"}],
            })

    def test_invalid_engine_raises(self):
        with pytest.raises(ConfigError, match="engine"):
            validate_config({
                "engine": "polars_xyz",
                "sources": [{"name": "s", "format": "csv", "path": "/tmp/x.csv"}],
                "sinks": [{"name": "t", "format": "parquet", "path": "/tmp/y/"}],
            })

    def test_valid_engine_duckdb(self):
        validate_config({
            "engine": "duckdb",
            "sources": [{"name": "s", "format": "csv", "path": "/tmp/x.csv"}],
            "sinks": [{"name": "t", "format": "parquet", "path": "/tmp/y/"}],
        })

    def test_masking_valid(self):
        validate_config({
            "sources": [{
                "name": "s", "format": "parquet", "path": "/tmp/",
                "masking": {
                    "provider": "hash",
                    "columns": [{"column": "cpf", "algorithm": "sha256"}],
                }
            }],
            "sinks": [{"name": "t", "format": "parquet", "path": "/tmp/out/"}],
        })

    def test_masking_invalid_provider_raises(self):
        with pytest.raises(ConfigError, match="provider"):
            validate_config({
                "sources": [{
                    "name": "s", "format": "parquet", "path": "/tmp/",
                    "masking": {"provider": "xyz_invalid", "columns": []}
                }],
                "sinks": [{"name": "t", "format": "parquet", "path": "/tmp/out/"}],
            })

    def test_catalog_missing_database_raises(self):
        with pytest.raises(ConfigError, match="database"):
            validate_config({
                "sources": [{"name": "s", "format": "csv", "path": "/tmp/x.csv"}],
                "sinks": [{
                    "name": "t", "format": "parquet", "path": "/tmp/y/",
                    "catalog": {"provider": "glue", "table_name": "t"}
                }],
            })

    def test_catalog_missing_table_name_raises(self):
        with pytest.raises(ConfigError, match="table_name"):
            validate_config({
                "sources": [{"name": "s", "format": "csv", "path": "/tmp/x.csv"}],
                "sinks": [{
                    "name": "t", "format": "parquet", "path": "/tmp/y/",
                    "catalog": {"provider": "glue", "database": "mydb"}
                }],
            })

    def test_only_sinks_is_valid(self):
        validate_config({
            "sinks": [{"name": "t", "format": "parquet", "path": "/tmp/y/"}],
        })

    def test_only_sources_is_valid(self):
        validate_config({
            "sources": [{"name": "s", "format": "csv", "path": "/tmp/x.csv"}],
        })

    def test_non_dict_config_raises(self):
        with pytest.raises(ConfigError):
            validate_config("invalid")

    def test_multiple_errors_reported_together(self):
        with pytest.raises(ConfigError) as exc_info:
            validate_config({
                "sources": [{"format": "csv"}],
                "sinks": [{"path": "/tmp/"}],
            })
        msg = str(exc_info.value)
        assert "sources[0]" in msg
        assert "sinks[0]" in msg
