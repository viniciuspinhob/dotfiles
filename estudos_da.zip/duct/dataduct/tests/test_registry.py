from dataduct.core.registry import (
    register_connector,
    get_connector,
    register_engine,
    get_engine,
    _connector_registry,
    _engine_registry,
)
from dataduct.core.exceptions import ConnectorNotFound, EngineNotFound
import pytest


def test_register_and_get_connector():
    @register_connector("test_format", "extractor")
    class TestExtractor:
        pass

    result = get_connector("test_format", "extractor")
    assert result is TestExtractor
    del _connector_registry["extractor"]["test_format"]


def test_get_connector_not_found():
    with pytest.raises(ConnectorNotFound):
        get_connector("nonexistent_xyz", "extractor")


def test_register_and_get_engine():
    @register_engine("test_engine")
    class TestEngine:
        pass

    result = get_engine("test_engine")
    assert result is TestEngine
    del _engine_registry["test_engine"]


def test_get_engine_not_found():
    with pytest.raises(EngineNotFound):
        get_engine("nonexistent_engine_xyz")
