from dataduct.core.config import deep_merge_dict, _build_package_tree, _merge_list_elements


def test_deep_merge_simple():
    parent = {"a": 1, "b": 2}
    child = {"b": 22, "c": 3}
    result = deep_merge_dict(parent, child)
    assert result["a"] == 1
    assert result["b"] == 22
    assert result["c"] == 3


def test_deep_merge_nested():
    parent = {"a": {"x": 1, "y": 2}}
    child = {"a": {"y": 22, "z": 3}}
    result = deep_merge_dict(parent, child)
    assert result["a"]["x"] == 1
    assert result["a"]["y"] == 22
    assert result["a"]["z"] == 3


def test_deep_merge_lists_by_name():
    parent = [{"name": "src1", "format": "csv", "path": "/old"}]
    child = [{"name": "src1", "path": "/new"}]
    result = _merge_list_elements(parent, child)
    assert len(result) == 1
    assert result[0]["path"] == "/new"
    assert result[0]["format"] == "csv"


def test_build_package_tree():
    tree = _build_package_tree("examples.csv_to_parquet")
    assert tree == ["examples.csv_to_parquet", "examples"]


def test_build_package_tree_single():
    tree = _build_package_tree("mypackage")
    assert tree == ["mypackage"]
