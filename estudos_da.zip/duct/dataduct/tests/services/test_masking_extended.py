import pytest

try:
    import duckdb  # noqa: F401
    HAS_DUCKDB = True
except ImportError:
    HAS_DUCKDB = False


class TestHashMaskingEdgeCases:
    @pytest.mark.skipif(not HAS_DUCKDB, reason="duckdb not installed")
    def test_md5_algorithm(self):
        from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter
        from dataduct.services.masking.hash import HashMaskingProvider

        engine = DuckDBEngineAdapter()
        engine.create_session()

        data = engine.execute_sql("SELECT 'test@email.com' as email")
        provider = HashMaskingProvider()
        result = provider.mask(data, [{"column": "email", "algorithm": "md5"}], engine=engine)
        rows = result.fetchall()
        assert len(rows) == 1
        assert rows[0][0] != "test@email.com"
        assert len(rows[0][0]) == 32

        engine.stop_session()

    @pytest.mark.skipif(not HAS_DUCKDB, reason="duckdb not installed")
    def test_unknown_algorithm_raises(self):
        from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter
        from dataduct.services.masking.hash import HashMaskingProvider

        engine = DuckDBEngineAdapter()
        engine.create_session()
        data = engine.execute_sql("SELECT 'test' as col")

        provider = HashMaskingProvider()
        with pytest.raises(ValueError, match="Unsupported masking algorithm"):
            provider.mask(data, [{"column": "col", "algorithm": "rot13"}], engine=engine)

        engine.stop_session()

    @pytest.mark.skipif(not HAS_DUCKDB, reason="duckdb not installed")
    def test_nonexistent_column_skipped_with_warning(self, caplog):
        import logging
        from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter
        from dataduct.services.masking.hash import HashMaskingProvider

        engine = DuckDBEngineAdapter()
        engine.create_session()
        data = engine.execute_sql("SELECT 'value' as real_col")

        provider = HashMaskingProvider()
        with caplog.at_level(logging.WARNING):
            result = provider.mask(
                data, [{"column": "nonexistent_col", "algorithm": "sha256"}], engine=engine
            )

        assert "nonexistent_col" in caplog.text
        rows = result.fetchall()
        assert rows[0][0] == "value"

        engine.stop_session()

    @pytest.mark.skipif(not HAS_DUCKDB, reason="duckdb not installed")
    def test_no_columns_returns_data_unchanged(self):
        from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter
        from dataduct.services.masking import apply_masking

        engine = DuckDBEngineAdapter()
        engine.create_session()
        data = engine.execute_sql("SELECT 'x' as col")

        result = apply_masking(data, {"provider": "hash", "columns": []}, engine=engine)
        assert result is data

        engine.stop_session()

    @pytest.mark.skipif(not HAS_DUCKDB, reason="duckdb not installed")
    def test_temp_tables_use_unique_names(self):
        from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter
        from dataduct.services.masking.hash import HashMaskingProvider

        engine = DuckDBEngineAdapter()
        engine.create_session()

        data1 = engine.execute_sql("SELECT 'a@a.com' as email")
        data2 = engine.execute_sql("SELECT 'b@b.com' as email")

        provider = HashMaskingProvider()
        cols = [{"column": "email", "algorithm": "sha256"}]

        r1 = provider.mask(data1, cols, engine=engine)
        r2 = provider.mask(data2, cols, engine=engine)

        h1 = r1.fetchall()[0][0]
        h2 = r2.fetchall()[0][0]
        assert h1 != h2
        assert len(h1) == 64
        assert len(h2) == 64

        engine.stop_session()


class TestCredentials:
    def test_env_type_reads_from_env(self, monkeypatch):
        monkeypatch.setenv("MY_USER", "testuser")
        monkeypatch.setenv("MY_PASS", "testpass")

        from dataduct.services.credentials import resolve_credentials
        user, pwd = resolve_credentials({
            "type": "env",
            "user_var": "MY_USER",
            "password_var": "MY_PASS",
        })
        assert user == "testuser"
        assert pwd == "testpass"

    def test_direct_type_warns(self, caplog):
        import logging
        from dataduct.services.credentials import resolve_credentials
        with caplog.at_level(logging.WARNING):
            user, pwd = resolve_credentials({
                "type": "direct",
                "user": "admin",
                "password": "secret",
            })
        assert user == "admin"
        assert pwd == "secret"
        assert "plaintext" in caplog.text.lower() or "direct" in caplog.text

    def test_unknown_type_warns_and_returns_empty(self, caplog):
        import logging
        from dataduct.services.credentials import resolve_credentials
        with caplog.at_level(logging.WARNING):
            user, pwd = resolve_credentials({"type": "vault_xyz"})
        assert user == ""
        assert pwd == ""
        assert "Unknown credential type" in caplog.text

    def test_empty_config_returns_empty(self):
        from dataduct.services.credentials import resolve_credentials
        user, pwd = resolve_credentials({})
        assert user == ""
        assert pwd == ""
