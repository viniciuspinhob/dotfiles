import pytest
from unittest.mock import MagicMock, patch

from dataduct.services.catalog.schema_inference import (
    infer_schema_from_parquet,
    resolve_schema,
    schema_from_explicit,
)
from dataduct.services.catalog.table_format import TableFormat


class TestTableFormat:
    def test_from_string_parquet(self):
        assert TableFormat.from_string("parquet") == TableFormat.PARQUET

    def test_from_string_delta(self):
        assert TableFormat.from_string("delta") == TableFormat.DELTA

    def test_from_string_iceberg(self):
        assert TableFormat.from_string("iceberg") == TableFormat.ICEBERG

    def test_from_string_hudi(self):
        assert TableFormat.from_string("hudi") == TableFormat.HUDI

    def test_from_string_case_insensitive(self):
        assert TableFormat.from_string("PARQUET") == TableFormat.PARQUET
        assert TableFormat.from_string("Delta") == TableFormat.DELTA

    def test_from_string_strips_whitespace(self):
        assert TableFormat.from_string("  parquet  ") == TableFormat.PARQUET

    def test_from_string_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown table format"):
            TableFormat.from_string("csv")

    def test_spark_source(self):
        assert TableFormat.PARQUET.spark_source == "PARQUET"
        assert TableFormat.DELTA.spark_source == "DELTA"
        assert TableFormat.ICEBERG.spark_source == "ICEBERG"
        assert TableFormat.HUDI.spark_source == "HUDI"

    def test_unity_rest_format(self):
        assert TableFormat.PARQUET.unity_rest_format == "PARQUET"
        assert TableFormat.DELTA.unity_rest_format == "DELTA"

    def test_glue_classification(self):
        assert TableFormat.PARQUET.glue_classification == "parquet"
        assert TableFormat.DELTA.glue_classification == "delta"


class TestSchemaInference:
    def test_schema_from_explicit(self):
        cols = schema_from_explicit([
            {"name": "id", "type": "long"},
            {"name": "nome", "type": "string"},
        ])
        assert len(cols) == 2
        assert cols[0].name == "id"
        assert cols[0].type_name == "LONG"
        assert cols[1].name == "nome"
        assert cols[1].type_name == "STRING"

    def test_schema_from_explicit_missing_name_raises(self):
        with pytest.raises(ValueError, match="missing 'name'"):
            schema_from_explicit([{"type": "string"}])

    def test_schema_from_explicit_defaults_to_string(self):
        cols = schema_from_explicit([{"name": "col1"}])
        assert cols[0].type_name == "STRING"

    def test_schema_from_explicit_preserves_position(self):
        cols = schema_from_explicit([
            {"name": "a", "type": "int"},
            {"name": "b", "type": "double"},
            {"name": "c", "type": "boolean"},
        ])
        assert cols[0].position == 0
        assert cols[1].position == 1
        assert cols[2].position == 2

    def test_resolve_schema_uses_explicit_over_path(self):
        explicit = [{"name": "id", "type": "long"}]
        result = resolve_schema(path="/some/path.parquet", explicit_schema=explicit)
        assert len(result) == 1
        assert result[0].name == "id"

    def test_resolve_schema_returns_empty_when_no_input(self):
        result = resolve_schema()
        assert result == []

    def test_infer_schema_from_parquet(self):
        import pyarrow as pa

        mock_schema = pa.schema([
            pa.field("id", pa.int64()),
            pa.field("name", pa.string()),
            pa.field("value", pa.float64()),
            pa.field("active", pa.bool_()),
        ])

        with patch("pyarrow.parquet.read_schema", return_value=mock_schema):
            result = infer_schema_from_parquet("/fake/path.parquet")

        assert len(result) == 4
        assert result[0].name == "id"
        assert result[0].type_name == "LONG"
        assert result[1].name == "name"
        assert result[1].type_name == "STRING"
        assert result[2].name == "value"
        assert result[2].type_name == "DOUBLE"
        assert result[3].name == "active"
        assert result[3].type_name == "BOOLEAN"

    def test_infer_schema_without_pyarrow_raises(self):
        import builtins

        original_import = builtins.__import__

        def _fake_import(name, *args, **kwargs):
            if name == "pyarrow.parquet":
                raise ImportError("No module named pyarrow.parquet")
            return original_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=_fake_import):
            with pytest.raises(ImportError, match="pyarrow is required"):
                infer_schema_from_parquet("/fake/path.parquet")


class TestUnityCatalogRestProvider:
    def _make_provider(self, **kwargs):
        from dataduct.services.catalog.unity_rest import UnityCatalogRestProvider

        defaults = {
            "host": "http://localhost:8080",
            "token": "test-token",
            "catalog_name": "main",
            "table_format": "parquet",
            "schema": [
                {"name": "id", "type": "long"},
                {"name": "name", "type": "string"},
            ],
        }
        defaults.update(kwargs)
        return UnityCatalogRestProvider(**defaults)

    def test_instantiation(self):
        provider = self._make_provider()
        assert provider._host == "http://localhost:8080"
        assert provider._catalog_name == "main"
        assert provider._table_format == TableFormat.PARQUET

    def test_base_url(self):
        provider = self._make_provider(host="http://localhost:8080/")
        assert provider._base_url == "http://localhost:8080/api/2.1/unity-catalog"

    def test_headers_with_token(self):
        provider = self._make_provider(token="my-token")
        headers = provider._headers
        assert headers["Authorization"] == "Bearer my-token"
        assert headers["Content-Type"] == "application/json"

    def test_headers_without_token(self):
        provider = self._make_provider(token=None)
        headers = provider._headers
        assert "Authorization" not in headers

    @patch("requests.request")
    def test_table_exists_returns_true(self, mock_req):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.text = '{"name": "my_table"}'
        mock_resp.json.return_value = {"name": "my_table"}
        mock_req.return_value = mock_resp

        provider = self._make_provider()
        assert provider.table_exists("my_db", "my_table") is True

        call_args = mock_req.call_args
        assert "tables/main.my_db.my_table" in call_args[0][1]

    @patch("requests.request")
    def test_table_exists_returns_false_on_404(self, mock_req):
        mock_resp = MagicMock()
        mock_resp.status_code = 404
        mock_req.return_value = mock_resp

        provider = self._make_provider()
        assert provider.table_exists("my_db", "my_table") is False

    @patch("requests.request")
    def test_create_database_posts_schema(self, mock_req):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.text = '{"name": "main"}'
        mock_resp.json.return_value = {"name": "main"}
        mock_req.return_value = mock_resp

        provider = self._make_provider()
        provider.create_database("analytics", description="Analytics DB")

        calls = mock_req.call_args_list
        assert any("catalogs" in str(c) for c in calls)
        assert any("schemas" in str(c) for c in calls)

    @patch("requests.request")
    def test_register_table_creates_table(self, mock_req):
        mock_resp_404 = MagicMock()
        mock_resp_404.status_code = 404
        mock_resp_404.text = ""

        mock_resp_ok = MagicMock()
        mock_resp_ok.status_code = 200
        mock_resp_ok.text = '{"name": "clientes"}'
        mock_resp_ok.json.return_value = {"name": "clientes"}

        mock_req.side_effect = [mock_resp_404, mock_resp_ok]

        provider = self._make_provider()
        provider.register_table(
            path="s3://bucket/curated/clientes/",
            database="crm",
            table_name="clientes",
            description="Tabela de clientes",
            properties={"owner": "data-team"},
        )

        post_call = mock_req.call_args_list[1]
        assert post_call[0][0] == "POST"
        payload = post_call[1]["json"]
        assert payload["name"] == "clientes"
        assert payload["data_source_format"] == "PARQUET"
        assert payload["table_type"] == "EXTERNAL"
        assert payload["storage_location"] == "s3://bucket/curated/clientes/"

    @patch("requests.request")
    def test_register_table_with_delta_format(self, mock_req):
        mock_resp_404 = MagicMock()
        mock_resp_404.status_code = 404
        mock_resp_404.text = ""

        mock_resp_ok = MagicMock()
        mock_resp_ok.status_code = 200
        mock_resp_ok.text = '{"name": "vendas"}'
        mock_resp_ok.json.return_value = {"name": "vendas"}

        mock_req.side_effect = [mock_resp_404, mock_resp_ok]

        provider = self._make_provider(table_format="delta")
        provider.register_table(
            path="s3://bucket/curated/vendas/",
            database="crm",
            table_name="vendas",
        )

        post_call = mock_req.call_args_list[1]
        payload = post_call[1]["json"]
        assert payload["data_source_format"] == "DELTA"

    @patch("requests.request")
    def test_register_table_override_format(self, mock_req):
        mock_resp_404 = MagicMock()
        mock_resp_404.status_code = 404
        mock_resp_404.text = ""

        mock_resp_ok = MagicMock()
        mock_resp_ok.status_code = 200
        mock_resp_ok.text = '{"name": "events"}'
        mock_resp_ok.json.return_value = {"name": "events"}

        mock_req.side_effect = [mock_resp_404, mock_resp_ok]

        provider = self._make_provider(table_format="parquet")
        provider.register_table(
            path="s3://bucket/events/",
            database="analytics",
            table_name="events",
            table_format="iceberg",
        )

        post_call = mock_req.call_args_list[1]
        payload = post_call[1]["json"]
        assert payload["data_source_format"] == "ICEBERG"

    @patch("requests.request")
    def test_drop_table(self, mock_req):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.text = ""
        mock_resp.json.return_value = {}
        mock_req.return_value = mock_resp

        provider = self._make_provider()
        provider.drop_table("crm", "clientes")

        call_args = mock_req.call_args
        assert call_args[0][0] == "DELETE"
        assert "tables/main.crm.clientes" in call_args[0][1]

    @patch("requests.request")
    def test_register_table_with_explicit_schema(self, mock_req):
        mock_resp_404 = MagicMock()
        mock_resp_404.status_code = 404
        mock_resp_404.text = ""

        mock_resp_ok = MagicMock()
        mock_resp_ok.status_code = 200
        mock_resp_ok.text = '{"name": "products"}'
        mock_resp_ok.json.return_value = {"name": "products"}

        mock_req.side_effect = [mock_resp_404, mock_resp_ok]

        provider = self._make_provider(
            schema=[
                {"name": "id", "type": "long"},
                {"name": "name", "type": "string"},
                {"name": "price", "type": "double"},
            ]
        )
        provider.register_table(
            path="s3://bucket/products/",
            database="ecommerce",
            table_name="products",
        )

        post_call = mock_req.call_args_list[1]
        payload = post_call[1]["json"]
        assert len(payload["columns"]) == 3
        assert payload["columns"][0]["name"] == "id"
        assert payload["columns"][0]["type_name"] == "LONG"
        assert payload["columns"][2]["name"] == "price"
        assert payload["columns"][2]["type_name"] == "DOUBLE"

    def test_column_to_dict_type_json_includes_nullable_and_metadata(self):
        import json

        from dataduct.services.catalog.schema_inference import ColumnInfo
        from dataduct.services.catalog.unity_rest import UnityCatalogRestProvider

        payload = UnityCatalogRestProvider._column_to_dict(
            ColumnInfo(name="id_order", type_name="LONG", nullable=False, position=0)
        )

        type_json = json.loads(payload["type_json"])
        assert type_json == {
            "name": "id_order",
            "type": "bigint",
            "nullable": False,
            "metadata": {},
        }
        assert payload["type_text"] == "bigint"
        assert payload["type_name"] == "LONG"
        assert payload["nullable"] is False

    def test_normalize_storage_location_converts_s3a_to_s3(self):
        from dataduct.services.catalog.unity_rest import _normalize_storage_location

        assert _normalize_storage_location("s3a://dataduct-curated/orders/") == "s3://dataduct-curated/orders/"
        assert _normalize_storage_location("s3://bucket/path/") == "s3://bucket/path/"


class TestUnityCatalogSparkWithTableFormat:
    def test_register_table_uses_parquet_format(self):
        from dataduct.services.catalog.unity import UnityCatalogProvider

        provider = UnityCatalogProvider(
            host="https://workspace.databricks.com",
            catalog="main",
            table_format="parquet",
        )

        mock_spark = MagicMock()
        with patch.object(provider, "_get_spark", return_value=mock_spark):
            provider.register_table(
                path="s3://bucket/data/",
                database="raw",
                table_name="events",
            )

        sql_call = mock_spark.sql.call_args_list[0][0][0]
        assert "USING PARQUET" in sql_call

    def test_register_table_defaults_to_delta(self):
        from dataduct.services.catalog.unity import UnityCatalogProvider

        provider = UnityCatalogProvider(
            host="https://workspace.databricks.com",
            catalog="main",
        )

        mock_spark = MagicMock()
        with patch.object(provider, "_get_spark", return_value=mock_spark):
            provider.register_table(
                path="s3://bucket/data/",
                database="raw",
                table_name="events",
            )

        sql_call = mock_spark.sql.call_args_list[0][0][0]
        assert "USING DELTA" in sql_call

    def test_register_table_override_format_at_call(self):
        from dataduct.services.catalog.unity import UnityCatalogProvider

        provider = UnityCatalogProvider(
            host="https://workspace.databricks.com",
            catalog="main",
            table_format="delta",
        )

        mock_spark = MagicMock()
        with patch.object(provider, "_get_spark", return_value=mock_spark):
            provider.register_table(
                path="s3://bucket/data/",
                database="raw",
                table_name="events",
                table_format="iceberg",
            )

        sql_call = mock_spark.sql.call_args_list[0][0][0]
        assert "USING ICEBERG" in sql_call


class TestApplyCatalogWithTableFormat:
    @patch("requests.request")
    def test_apply_catalog_passes_table_format(self, mock_req):
        from dataduct.services.catalog import apply_catalog

        mock_resp_ok = MagicMock()
        mock_resp_ok.status_code = 200
        mock_resp_ok.text = '{"name": "main"}'
        mock_resp_ok.json.return_value = {"name": "main"}

        mock_resp_404 = MagicMock()
        mock_resp_404.status_code = 404
        mock_resp_404.text = ""

        mock_req.side_effect = [mock_resp_ok, mock_resp_ok, mock_resp_404, mock_resp_ok]

        config = {
            "provider": "unity_rest",
            "host": "http://localhost:8080",
            "catalog_name": "main",
            "database": "analytics",
            "table_name": "events",
            "table_format": "parquet",
            "schema": [{"name": "id", "type": "long"}],
        }

        apply_catalog(data=None, catalog_config=config, path="s3://bucket/events/")

        post_calls = [c for c in mock_req.call_args_list if c[0][0] == "POST"]
        table_post = [c for c in post_calls if "tables" in c[0][1]]
        if table_post:
            payload = table_post[0][1]["json"]
            assert payload["data_source_format"] == "PARQUET"
