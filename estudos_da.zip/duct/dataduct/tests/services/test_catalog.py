import pytest
from unittest.mock import MagicMock, patch


class TestCatalogProviderABC:
    def test_glue_provider_instantiates(self):
        from dataduct.services.catalog.glue import GlueCatalogProvider

        provider = GlueCatalogProvider(region="us-east-1")
        assert provider is not None

    def test_unity_provider_instantiates(self):
        from dataduct.services.catalog.unity import UnityCatalogProvider

        provider = UnityCatalogProvider(host="https://my-workspace.azuredatabricks.net", catalog="main")
        assert provider is not None

    def test_get_catalog_provider_glue(self):
        from dataduct.services.catalog import get_catalog_provider
        from dataduct.services.catalog.glue import GlueCatalogProvider

        provider = get_catalog_provider("glue", region="us-east-1")
        assert isinstance(provider, GlueCatalogProvider)

    def test_get_catalog_provider_unity(self):
        from dataduct.services.catalog import get_catalog_provider
        from dataduct.services.catalog.unity import UnityCatalogProvider

        provider = get_catalog_provider("unity", catalog="main")
        assert isinstance(provider, UnityCatalogProvider)

    def test_get_catalog_provider_unknown_raises(self):
        from dataduct.services.catalog import get_catalog_provider

        with pytest.raises(ValueError, match="not found"):
            get_catalog_provider("nonexistent_catalog_xyz")

    def test_register_custom_catalog_provider(self):
        from dataduct.services.catalog import register_catalog_provider, get_catalog_provider
        from dataduct.services.catalog.base import CatalogProvider

        class MockCatalog(CatalogProvider):
            def register_table(self, *a, **kw): pass
            def drop_table(self, *a, **kw): pass
            def table_exists(self, *a, **kw): return False
            def create_database(self, *a, **kw): pass

        register_catalog_provider("mock_catalog", MockCatalog)
        provider = get_catalog_provider("mock_catalog")
        assert isinstance(provider, MockCatalog)


class TestGlueCatalogProvider:
    def test_table_exists_returns_false_on_entity_not_found(self):
        from dataduct.services.catalog.glue import GlueCatalogProvider

        provider = GlueCatalogProvider(region="us-east-1")

        mock_client = MagicMock()
        mock_client.exceptions.EntityNotFoundException = Exception
        mock_client.get_table.side_effect = Exception("not found")

        with patch.object(provider, "_client", return_value=mock_client):
            result = provider.table_exists("my_db", "my_table")
        assert result is False

    def test_table_exists_returns_true_when_found(self):
        from dataduct.services.catalog.glue import GlueCatalogProvider

        provider = GlueCatalogProvider(region="us-east-1")

        mock_client = MagicMock()
        mock_client.get_table.return_value = {"Table": {"Name": "my_table"}}

        with patch.object(provider, "_client", return_value=mock_client):
            result = provider.table_exists("my_db", "my_table")
        assert result is True

    def test_create_database_calls_glue(self):
        from dataduct.services.catalog.glue import GlueCatalogProvider

        provider = GlueCatalogProvider(region="us-east-1")
        mock_client = MagicMock()

        with patch.object(provider, "_client", return_value=mock_client):
            provider.create_database("vendas_curated", description="Curated vendas")

        mock_client.create_database.assert_called_once()
        call_kwargs = mock_client.create_database.call_args[1]
        assert call_kwargs["DatabaseInput"]["Name"] == "vendas_curated"

    def test_create_database_ignores_already_exists(self):
        from dataduct.services.catalog.glue import GlueCatalogProvider

        provider = GlueCatalogProvider()
        mock_client = MagicMock()
        mock_client.exceptions.AlreadyExistsException = Exception
        mock_client.create_database.side_effect = Exception("already exists")

        with patch.object(provider, "_client", return_value=mock_client):
            provider.create_database("existing_db")

    def test_register_table_creates_when_not_exists(self):
        from dataduct.services.catalog.glue import GlueCatalogProvider

        provider = GlueCatalogProvider(region="us-east-1")
        mock_client = MagicMock()
        mock_client.exceptions.EntityNotFoundException = Exception
        mock_client.get_table.side_effect = Exception("not found")

        with patch.object(provider, "_client", return_value=mock_client):
            provider.register_table(
                path="s3://bucket/curated/clientes/",
                database="vendas_curated",
                table_name="clientes",
                partition_by=["dt_referencia"],
                description="Tabela de clientes",
            )

        mock_client.create_table.assert_called_once()

    def test_register_table_updates_when_exists(self):
        from dataduct.services.catalog.glue import GlueCatalogProvider

        provider = GlueCatalogProvider(region="us-east-1")
        mock_client = MagicMock()
        mock_client.get_table.return_value = {"Table": {"Name": "clientes"}}

        with patch.object(provider, "_client", return_value=mock_client):
            provider.register_table(
                path="s3://bucket/curated/clientes/",
                database="vendas_curated",
                table_name="clientes",
            )

        mock_client.update_table.assert_called_once()


class TestCatalogIntegrationWithLoader:
    def test_loader_stores_catalog_config(self):
        from dataduct.connectors.parquet.loader import ParquetLoader

        engine = MagicMock()
        loader = ParquetLoader(engine=engine, path="/tmp/out/")
        loader.set_catalog({"provider": "glue", "database": "mydb", "table_name": "mytable"}, engine=engine)

        assert loader._catalog_config["provider"] == "glue"
        assert loader._engine_ref is engine

    def test_after_save_calls_apply_catalog(self):
        import dataduct.services.catalog as catalog_module
        from dataduct.connectors.parquet.loader import ParquetLoader

        engine = MagicMock()
        loader = ParquetLoader(engine=engine, path="/tmp/out/")
        loader.set_catalog({"provider": "glue", "database": "mydb", "table_name": "mytable"}, engine=engine)
        loader._last_data = MagicMock()

        original = catalog_module.apply_catalog
        calls = []
        catalog_module.apply_catalog = lambda **kw: calls.append(kw)
        try:
            loader.after_save()
        finally:
            catalog_module.apply_catalog = original

        assert len(calls) == 1
        assert calls[0]["catalog_config"]["database"] == "mydb"
        assert calls[0]["path"] == "/tmp/out/"
