import pytest

try:
    import duckdb  # noqa: F401
    HAS_DUCKDB = True
except ImportError:
    HAS_DUCKDB = False


class TestHashMaskingProvider:
    def test_mask_raises_without_engine(self):
        from dataduct.services.masking.hash import HashMaskingProvider

        provider = HashMaskingProvider()
        with pytest.raises(RuntimeError, match="requires an engine"):
            provider.mask("data", [{"column": "email", "algorithm": "sha256"}], engine=None)

    def test_unmask_raises_not_implemented(self):
        from dataduct.services.masking.hash import HashMaskingProvider

        provider = HashMaskingProvider()
        with pytest.raises(NotImplementedError):
            provider.unmask("data", [], engine=None)

    @pytest.mark.skipif(not HAS_DUCKDB, reason="duckdb not installed")
    def test_mask_sha256_duckdb(self):
        from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter
        from dataduct.services.masking.hash import HashMaskingProvider

        engine = DuckDBEngineAdapter()
        engine.create_session()

        data = engine.execute_sql(
            "SELECT 'alice@example.com' as email, 'Alice' as name, 30 as age"
        )

        provider = HashMaskingProvider()
        result = provider.mask(
            data,
            [{"column": "email", "algorithm": "sha256"}],
            engine=engine,
        )

        rows = result.fetchall()
        cols = [desc[0] for desc in result.description]

        row = dict(zip(cols, rows[0]))
        assert row["name"] == "Alice"
        assert row["age"] == 30
        assert row["email"] != "alice@example.com"
        assert len(row["email"]) == 64

        engine.stop_session()

    @pytest.mark.skipif(not HAS_DUCKDB, reason="duckdb not installed")
    def test_mask_multiple_columns(self):
        from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter
        from dataduct.services.masking.hash import HashMaskingProvider

        engine = DuckDBEngineAdapter()
        engine.create_session()

        data = engine.execute_sql(
            "SELECT '123.456.789-00' as cpf, 'bob@email.com' as email, 'Bob' as nome"
        )

        provider = HashMaskingProvider()
        result = provider.mask(
            data,
            [
                {"column": "cpf", "algorithm": "sha256"},
                {"column": "email", "algorithm": "sha256"},
            ],
            engine=engine,
        )

        rows = result.fetchall()
        cols = [desc[0] for desc in result.description]
        row = dict(zip(cols, rows[0]))

        assert row["nome"] == "Bob"
        assert row["cpf"] != "123.456.789-00"
        assert row["email"] != "bob@email.com"
        assert len(row["cpf"]) == 64
        assert len(row["email"]) == 64

        engine.stop_session()

    @pytest.mark.skipif(not HAS_DUCKDB, reason="duckdb not installed")
    def test_mask_deterministic(self):
        from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter
        from dataduct.services.masking.hash import HashMaskingProvider

        engine = DuckDBEngineAdapter()
        engine.create_session()

        provider = HashMaskingProvider()
        columns = [{"column": "cpf", "algorithm": "sha256"}]

        data1 = engine.execute_sql("SELECT '111.222.333-44' as cpf")
        result1 = provider.mask(data1, columns, engine=engine)
        hash1 = result1.fetchall()[0][0]

        data2 = engine.execute_sql("SELECT '111.222.333-44' as cpf")
        result2 = provider.mask(data2, columns, engine=engine)
        hash2 = result2.fetchall()[0][0]

        assert hash1 == hash2

        engine.stop_session()


class TestApplyMasking:
    @pytest.mark.skipif(not HAS_DUCKDB, reason="duckdb not installed")
    def test_apply_masking_via_helper(self):
        from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter
        from dataduct.services.masking import apply_masking

        engine = DuckDBEngineAdapter()
        engine.create_session()

        data = engine.execute_sql("SELECT 'secret@email.com' as email, 'public' as info")

        result = apply_masking(
            data,
            {"provider": "hash", "columns": [{"column": "email", "algorithm": "sha256"}]},
            engine=engine,
        )

        rows = result.fetchall()
        cols = [desc[0] for desc in result.description]
        row = dict(zip(cols, rows[0]))

        assert row["info"] == "public"
        assert row["email"] != "secret@email.com"

        engine.stop_session()

    @pytest.mark.skipif(not HAS_DUCKDB, reason="duckdb not installed")
    def test_apply_masking_empty_columns_returns_unchanged(self):
        from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter
        from dataduct.services.masking import apply_masking

        engine = DuckDBEngineAdapter()
        engine.create_session()

        data = engine.execute_sql("SELECT 'test@email.com' as email")

        result = apply_masking(data, {"provider": "hash", "columns": []}, engine=engine)
        assert result is data

        engine.stop_session()

    def test_unknown_provider_raises(self):
        from dataduct.services.masking import get_masking_provider

        with pytest.raises(ValueError, match="not found"):
            get_masking_provider("nonexistent_xyz")
