from dataduct.utils.bunch import Bunch


def test_bunch_attribute_access():
    b = Bunch(name="test", value=42)
    assert b.name == "test"
    assert b.value == 42


def test_bunch_dict_access():
    b = Bunch(name="test")
    assert b["name"] == "test"


def test_bunch_set_attribute():
    b = Bunch()
    b.new_key = "hello"
    assert b["new_key"] == "hello"


def test_bunch_missing_attribute():
    b = Bunch()
    try:
        _ = b.nonexistent
        assert False
    except AttributeError:
        pass


def test_bunch_repr():
    b = Bunch(a=1, b=2)
    assert "Bunch" in repr(b)
