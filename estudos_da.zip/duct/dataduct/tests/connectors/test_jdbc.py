import os
from unittest.mock import MagicMock, patch

from dataduct.connectors.jdbc.extractor import JdbcExtractor
from dataduct.connectors.jdbc.loader import JdbcLoader


def test_jdbc_extractor_with_table():
    engine = MagicMock()
    engine.read.return_value = "dataframe"

    extractor = JdbcExtractor(
        engine=engine,
        url="jdbc:postgresql://localhost:5432/db",
        driver="org.postgresql.Driver",
        table="users",
        credentials={"type": "direct", "user": "admin", "password": "secret"},
    )
    result = extractor.extract()

    engine.read.assert_called_once()
    call_kwargs = engine.read.call_args[1]
    assert call_kwargs["url"] == "jdbc:postgresql://localhost:5432/db"
    assert call_kwargs["dbtable"] == "users"
    assert call_kwargs["user"] == "admin"
    assert call_kwargs["password"] == "secret"
    assert result == "dataframe"


def test_jdbc_extractor_with_query():
    engine = MagicMock()
    engine.read.return_value = "dataframe"

    extractor = JdbcExtractor(
        engine=engine,
        url="jdbc:postgresql://localhost:5432/db",
        query="SELECT * FROM users WHERE active = true",
        credentials={"type": "direct", "user": "u", "password": "p"},
    )
    extractor.extract()

    call_kwargs = engine.read.call_args[1]
    assert "SELECT * FROM users" in call_kwargs["dbtable"]


def test_jdbc_extractor_env_credentials():
    engine = MagicMock()
    engine.read.return_value = "df"

    with patch.dict(os.environ, {"DB_USER": "envuser", "DB_PASS": "envpass"}):
        extractor = JdbcExtractor(
            engine=engine,
            url="jdbc:postgresql://localhost/db",
            table="t",
            credentials={"type": "env", "user_var": "DB_USER", "password_var": "DB_PASS"},
        )
        extractor.extract()

    call_kwargs = engine.read.call_args[1]
    assert call_kwargs["user"] == "envuser"
    assert call_kwargs["password"] == "envpass"


def test_jdbc_loader_calls_engine():
    engine = MagicMock()

    loader = JdbcLoader(
        engine=engine,
        url="jdbc:postgresql://localhost/db",
        table="output_table",
        mode="append",
        credentials={"type": "direct", "user": "u", "password": "p"},
    )
    loader.save("data")

    engine.write.assert_called_once()
    args = engine.write.call_args
    assert args[0][0] == "data"
    assert args[0][1] == "jdbc"
