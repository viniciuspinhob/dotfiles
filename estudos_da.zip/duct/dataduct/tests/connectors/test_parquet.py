import pytest
from unittest.mock import MagicMock

from dataduct.connectors.parquet.extractor import ParquetExtractor
from dataduct.connectors.parquet.loader import ParquetLoader


def test_parquet_extractor_calls_engine():
    engine = MagicMock()
    engine.read.return_value = "dataframe"

    extractor = ParquetExtractor(engine=engine, path="/tmp/data.parquet")
    result = extractor.extract()

    engine.read.assert_called_once_with("parquet", path="/tmp/data.parquet", schema=None)
    assert result == "dataframe"


def test_parquet_extractor_no_engine_raises():
    extractor = ParquetExtractor(path="/tmp/data.parquet")
    with pytest.raises(RuntimeError):
        extractor.extract()


def test_parquet_loader_calls_engine():
    engine = MagicMock()

    loader = ParquetLoader(engine=engine, path="/tmp/out/", mode="overwrite")
    loader.save("data")

    engine.write.assert_called_once()
    args = engine.write.call_args
    assert args[0][0] == "data"
    assert args[0][1] == "parquet"


def test_parquet_loader_partition_by():
    engine = MagicMock()

    loader = ParquetLoader(engine=engine, path="/tmp/out/", partition_by=["year", "month"])
    loader.save("data")

    call_kwargs = engine.write.call_args[1]
    assert call_kwargs["partition_by"] == ["year", "month"]
