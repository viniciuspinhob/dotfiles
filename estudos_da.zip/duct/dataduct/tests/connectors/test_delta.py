import pytest
from unittest.mock import MagicMock

from dataduct.connectors.delta.extractor import DeltaExtractor
from dataduct.connectors.delta.loader import DeltaLoader


def test_delta_extractor_calls_engine():
    engine = MagicMock()
    engine.read.return_value = "dataframe"

    extractor = DeltaExtractor(engine=engine, path="s3a://bucket/delta/tabela/")
    result = extractor.extract()

    engine.read.assert_called_once_with("delta", path="s3a://bucket/delta/tabela/")
    assert result == "dataframe"


def test_delta_extractor_time_travel_options():
    engine = MagicMock()

    extractor = DeltaExtractor(
        engine=engine,
        path="s3a://bucket/delta/tabela/",
        version=5,
        timestamp="2024-01-15",
    )
    extractor.extract()

    engine.read.assert_called_once_with(
        "delta",
        path="s3a://bucket/delta/tabela/",
        versionAsOf="5",
        timestampAsOf="2024-01-15",
    )


def test_delta_extractor_no_engine_raises():
    extractor = DeltaExtractor(path="s3a://bucket/delta/tabela/")
    with pytest.raises(RuntimeError):
        extractor.extract()


def test_delta_loader_calls_engine():
    engine = MagicMock()

    loader = DeltaLoader(engine=engine, path="s3a://bucket/delta/out/", mode="overwrite")
    loader.save("data")

    engine.write.assert_called_once()
    args, kwargs = engine.write.call_args
    assert args[0] == "data"
    assert args[1] == "delta"
    assert kwargs["path"] == "s3a://bucket/delta/out/"
    assert kwargs["mode"] == "overwrite"


def test_delta_loader_merge_schema_and_partition():
    engine = MagicMock()

    loader = DeltaLoader(
        engine=engine,
        path="s3a://bucket/delta/out/",
        partition_by=["dt_referencia"],
        merge_schema=True,
    )
    loader.save("data")

    kwargs = engine.write.call_args[1]
    assert kwargs["partition_by"] == ["dt_referencia"]
    assert kwargs["mergeSchema"] == "true"


def test_delta_registered_in_factory():
    from dataduct.connectors import ExtractorFactory, LoaderFactory

    engine = MagicMock()
    engine.read.return_value = "df"

    extractor = ExtractorFactory.get({"format": "delta", "path": "/delta/table"}, engine=engine)
    assert isinstance(extractor, DeltaExtractor)

    loader = LoaderFactory.get({"format": "delta", "path": "/delta/out"}, engine=engine)
    assert isinstance(loader, DeltaLoader)
