import pytest
from unittest.mock import MagicMock

from dataduct.connectors.object_storage.extractor import ObjectStorageExtractor
from dataduct.connectors.object_storage.loader import ObjectStorageLoader


def test_object_storage_extractor_with_engine_s3a():
    engine = MagicMock()
    engine.read.return_value = "dataframe"

    extractor = ObjectStorageExtractor(
        engine=engine,
        bucket="my-bucket",
        key="data/file.parquet",
        file_format="parquet",
    )
    result = extractor.extract()

    engine.read.assert_called_once_with("parquet", path="s3a://my-bucket/data/file.parquet")
    assert result == "dataframe"


def test_object_storage_extractor_no_engine_raises_without_boto():
    extractor = ObjectStorageExtractor(
        bucket="my-bucket",
        key="data/file.parquet",
        endpoint_url="http://localhost:9000",
    )
    with pytest.raises(Exception):
        extractor.extract()


def test_object_storage_loader_with_engine_s3a():
    engine = MagicMock()

    loader = ObjectStorageLoader(
        engine=engine,
        bucket="out-bucket",
        key="output/data.parquet",
        file_format="parquet",
        mode="overwrite",
    )
    loader.save("data")

    engine.write.assert_called_once()
    args = engine.write.call_args
    assert args[0][0] == "data"
    assert args[0][1] == "parquet"
    assert args[1]["path"] == "s3a://out-bucket/output/data.parquet"
