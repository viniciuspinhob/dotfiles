import pytest
from unittest.mock import MagicMock

from dataduct.connectors.csv.extractor import CsvExtractor
from dataduct.connectors.csv.loader import CsvLoader


def test_csv_extractor_calls_engine():
    engine = MagicMock()
    engine.read.return_value = "dataframe"

    extractor = CsvExtractor(engine=engine, path="/tmp/test.csv", header=True, delimiter=",")
    result = extractor.extract()

    engine.read.assert_called_once()
    assert result == "dataframe"
    call_kwargs = engine.read.call_args
    assert call_kwargs[0][0] == "csv"


def test_csv_extractor_no_engine_raises():
    extractor = CsvExtractor(path="/tmp/test.csv")
    with pytest.raises(RuntimeError, match="No engine"):
        extractor.extract()


def test_csv_loader_calls_engine():
    engine = MagicMock()

    loader = CsvLoader(engine=engine, path="/tmp/out.csv", mode="overwrite")
    loader.save("some_data")

    engine.write.assert_called_once()
    call_args = engine.write.call_args
    assert call_args[0][0] == "some_data"
    assert call_args[0][1] == "csv"


def test_csv_loader_no_engine_raises():
    loader = CsvLoader(path="/tmp/out.csv")
    with pytest.raises(RuntimeError, match="No engine"):
        loader.save("data")
