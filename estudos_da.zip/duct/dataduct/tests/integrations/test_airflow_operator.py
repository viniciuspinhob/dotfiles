"""Tests for the Airflow DataductOperator integration."""

import sys
from types import ModuleType
from unittest.mock import MagicMock, patch


def _install_airflow_stubs():
    """Install minimal Airflow stubs so the operator can be imported without airflow."""
    if "airflow.models" in sys.modules:
        return

    airflow = ModuleType("airflow")
    models = ModuleType("airflow.models")
    utils = ModuleType("airflow.utils")
    context_mod = ModuleType("airflow.utils.context")

    class BaseOperator:
        template_fields = ()

        def __init__(self, **kwargs):
            self.task_id = kwargs.get("task_id")

    models.BaseOperator = BaseOperator
    context_mod.Context = dict

    airflow.models = models
    utils.context = context_mod
    airflow.utils = utils

    sys.modules["airflow"] = airflow
    sys.modules["airflow.models"] = models
    sys.modules["airflow.utils"] = utils
    sys.modules["airflow.utils.context"] = context_mod


_install_airflow_stubs()

from dataduct.integrations.airflow.operator import DataductOperator  # noqa: E402


def test_template_fields():
    assert "job_package_name" in DataductOperator.template_fields
    assert "custom" in DataductOperator.template_fields


def test_execute_runs_job_and_stops_engine():
    mock_engine = MagicMock()
    mock_job = MagicMock()
    mock_config = {"engine": "duckdb", "engine_config": {}}

    with (
        patch("dataduct.core.job.factory.JobFactory.build_config", return_value=mock_config) as build_config,
        patch("dataduct.engines.load_engine", return_value=mock_engine) as load_engine,
        patch("dataduct.core.job.factory.JobFactory.get", return_value=mock_job) as get_job,
    ):
        operator = DataductOperator(
            task_id="test_task",
            job_package_name="examples.csv_to_parquet",
            engine="duckdb",
            env="dev",
            custom={"filter_value": "true"},
        )
        operator.execute(context={})

    build_config.assert_called_once_with(
        job_package_name="examples.csv_to_parquet",
        custom={"filter_value": "true"},
        env="dev",
    )
    load_engine.assert_called_once_with("duckdb", {})
    get_job.assert_called_once_with(mock_config, engine=mock_engine)
    mock_job.execute.assert_called_once()
    mock_engine.stop_session.assert_called_once()


def test_execute_uses_config_engine_when_operator_engine_is_none():
    mock_engine = MagicMock()
    mock_config = {"engine": "spark", "engine_config": {"master": "local[1]"}}

    with (
        patch("dataduct.core.job.factory.JobFactory.build_config", return_value=mock_config),
        patch("dataduct.engines.load_engine", return_value=mock_engine) as load_engine,
        patch("dataduct.core.job.factory.JobFactory.get", return_value=MagicMock()),
    ):
        operator = DataductOperator(
            task_id="test_task",
            job_package_name="examples.orders_marketplace.jdbc_to_raw",
            env="dev",
        )
        operator.execute(context={})

    load_engine.assert_called_once_with("spark", {"master": "local[1]"})


def test_execute_stops_engine_on_job_failure():
    mock_engine = MagicMock()
    mock_config = {"engine": "duckdb"}

    with (
        patch("dataduct.core.job.factory.JobFactory.build_config", return_value=mock_config),
        patch("dataduct.engines.load_engine", return_value=mock_engine),
        patch("dataduct.core.job.factory.JobFactory.get", side_effect=RuntimeError("boom")),
    ):
        operator = DataductOperator(
            task_id="test_task",
            job_package_name="examples.csv_to_parquet",
        )
        try:
            operator.execute(context={})
        except RuntimeError:
            pass

    mock_engine.stop_session.assert_called_once()
