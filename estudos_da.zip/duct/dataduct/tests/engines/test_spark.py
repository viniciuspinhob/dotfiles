import sys

import pytest

try:
    from pyspark.sql import SparkSession  # noqa: F401
    HAS_SPARK = True
except ImportError:
    HAS_SPARK = False

SPARK_TEST_CONFIG = {
    "app_name": "dataduct-test",
    "master": "local[1]",
    "conf": {
        "spark.driver.bindAddress": "localhost",
        "spark.driver.host": "localhost",
        "spark.ui.enabled": "false",
    },
}

SKIP_SPARK_SERIALIZATION = sys.version_info >= (3, 14)


@pytest.mark.skipif(not HAS_SPARK, reason="pyspark not installed")
class TestSparkEngine:
    def test_create_and_stop_session(self):
        from dataduct.engines.spark.adapter import SparkEngineAdapter

        engine = SparkEngineAdapter()
        session = engine.create_session(SPARK_TEST_CONFIG)
        assert session is not None
        engine.stop_session()

    def test_read_write_csv(self, tmp_path):
        from dataduct.engines.spark.adapter import SparkEngineAdapter

        csv_file = tmp_path / "input.csv"
        csv_file.write_text("id,name\n1,Alice\n2,Bob\n")

        engine = SparkEngineAdapter()
        engine.create_session(SPARK_TEST_CONFIG)

        df = engine.read("csv", path=str(csv_file), header="true", inferSchema="true")
        assert df.count() == 2

        out_path = str(tmp_path / "output_csv")
        engine.write(df, "csv", path=out_path, mode="overwrite", header="true")

        engine.stop_session()

    @pytest.mark.skipif(SKIP_SPARK_SERIALIZATION, reason="PySpark serialization incompatible with Python 3.14+")
    def test_read_write_parquet(self, tmp_path):
        from dataduct.engines.spark.adapter import SparkEngineAdapter

        engine = SparkEngineAdapter()
        engine.create_session(SPARK_TEST_CONFIG)

        data = engine.session.createDataFrame([(1, "hello"), (2, "world")], ["id", "msg"])
        out_path = str(tmp_path / "output.parquet")
        engine.write(data, "parquet", path=out_path, mode="overwrite")

        read_back = engine.read("parquet", path=out_path)
        assert read_back.count() == 2

        engine.stop_session()

    def test_execute_sql(self):
        from dataduct.engines.spark.adapter import SparkEngineAdapter

        engine = SparkEngineAdapter()
        engine.create_session(SPARK_TEST_CONFIG)

        result = engine.execute_sql("SELECT 1 as value")
        assert result.collect()[0]["value"] == 1

        engine.stop_session()

    @pytest.mark.skipif(SKIP_SPARK_SERIALIZATION, reason="PySpark serialization incompatible with Python 3.14+")
    def test_register_view_and_query(self):
        from dataduct.engines.spark.adapter import SparkEngineAdapter

        engine = SparkEngineAdapter()
        engine.create_session(SPARK_TEST_CONFIG)

        df = engine.session.createDataFrame(
            [(1, "Alice", True), (2, "Bob", False)],
            ["id", "name", "active"],
        )
        df.createOrReplaceTempView("people")

        result = engine.execute_sql("SELECT * FROM people WHERE active = true")
        assert result.count() == 1
        assert result.collect()[0]["name"] == "Alice"

        engine.stop_session()
