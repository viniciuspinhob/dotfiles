import pytest

try:
    import duckdb  # noqa: F401
    HAS_DUCKDB = True
except ImportError:
    HAS_DUCKDB = False


@pytest.mark.skipif(not HAS_DUCKDB, reason="duckdb not installed")
class TestDuckDBEngine:
    def test_create_and_stop_session(self):
        from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter

        engine = DuckDBEngineAdapter()
        session = engine.create_session({"database": ":memory:"})
        assert session is not None
        assert engine.session is not None
        engine.stop_session()
        assert engine.session is None

    def test_execute_sql(self):
        from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter

        engine = DuckDBEngineAdapter()
        engine.create_session()
        result = engine.execute_sql("SELECT 1 as value")
        rows = result.fetchall()
        assert rows[0][0] == 1
        engine.stop_session()

    def test_read_write_csv(self, tmp_path):
        from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter

        csv_file = tmp_path / "input.csv"
        csv_file.write_text("id,name\n1,Alice\n2,Bob\n")

        engine = DuckDBEngineAdapter()
        engine.create_session()

        data = engine.read("csv", path=str(csv_file), header=True, delimiter=",")
        rows = data.fetchall()
        assert len(rows) == 2

        out_path = str(tmp_path / "output.csv")
        data2 = engine.read("csv", path=str(csv_file))
        engine.write(data2, "csv", path=out_path)
        assert (tmp_path / "output.csv").exists()

        engine.stop_session()

    def test_read_write_parquet(self, tmp_path):
        from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter

        engine = DuckDBEngineAdapter()
        engine.create_session()

        engine.execute_sql("CREATE TABLE test AS SELECT 1 as id, 'hello' as msg")
        data = engine.execute_sql("SELECT * FROM test")

        out_path = str(tmp_path / "output.parquet")
        engine.write(data, "parquet", path=out_path)
        assert (tmp_path / "output.parquet").exists()

        read_back = engine.read("parquet", path=out_path)
        rows = read_back.fetchall()
        assert len(rows) == 1
        assert rows[0][1] == "hello"

        engine.stop_session()
