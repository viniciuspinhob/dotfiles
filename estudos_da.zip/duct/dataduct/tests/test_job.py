from dataduct.core.job.base import Job, Steps


class DummyJob(Job):
    def run(self):
        self._ran = True


def test_job_init():
    config = {"sources": [], "sinks": [], "custom": {"x": 1}}
    job = DummyJob(config=config)
    assert job.custom.x == 1
    assert job.dry_run is False


def test_steps_before_after():
    steps = Steps()
    called = []

    @steps.before
    def before_hook(job):
        called.append("before")

    @steps.after
    def after_hook(job):
        called.append("after")

    steps.run_before(None)
    steps.run_after(None)
    assert called == ["before", "after"]


def test_steps_isolation():
    s1 = Steps()
    s2 = Steps()

    @s1.before
    def hook1(job):
        pass

    assert len(s1._before_functions) == 1
    assert len(s2._before_functions) == 0
