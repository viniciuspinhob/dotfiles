import json

import pytest
from click.testing import CliRunner

from dataduct.__main__ import cli


@pytest.fixture
def runner():
    return CliRunner()


class TestCLIDryRun:
    def test_dry_run_outputs_config(self, runner, tmp_path):
        (tmp_path / "__init__.py").write_text("")
        (tmp_path / "config.yaml").write_text(
            "type: python\nengine: duckdb\n"
            "sources:\n  - name: s\n    format: csv\n    path: /tmp/x.csv\n"
            "sinks:\n  - name: t\n    format: parquet\n    path: /tmp/y/\n"
        )

        import sys as _sys
        _sys.path.insert(0, str(tmp_path.parent))
        pkg = tmp_path.name
        result = runner.invoke(cli, ["run", "--job", pkg, "--dry-run"])
        _sys.path.pop(0)

        assert result.exit_code == 0
        assert "DRY RUN" in result.output
        assert pkg in result.output

    def test_dry_run_shows_custom_args(self, runner, tmp_path):
        (tmp_path / "__init__.py").write_text("")
        (tmp_path / "config.yaml").write_text(
            "type: python\nengine: duckdb\n"
            "sources:\n  - name: s\n    format: csv\n    path: /tmp/x.csv\n"
            "sinks:\n  - name: t\n    format: parquet\n    path: /tmp/y/\n"
            "custom:\n  env: prod\n"
        )

        import sys as _sys
        _sys.path.insert(0, str(tmp_path.parent))
        pkg = tmp_path.name
        result = runner.invoke(cli, [
            "run", "--job", pkg, "--dry-run",
            "--custom", '{"env": "staging"}'
        ])
        _sys.path.pop(0)

        assert result.exit_code == 0
        data = json.loads(result.output.split("--- DRY RUN ---\n")[1])
        assert data["custom"]["env"] == "staging"

    def test_invalid_json_custom_exits_with_error(self, runner):
        result = runner.invoke(cli, [
            "run", "--job", "doesnt.matter", "--custom", "not-json"
        ])
        assert result.exit_code == 1
        assert "valid JSON" in result.output

    def test_unknown_job_exits_with_error(self, runner):
        result = runner.invoke(cli, [
            "run", "--job", "totally_nonexistent_xyz_package", "--dry-run"
        ])
        assert result.exit_code != 0

    def test_unknown_engine_exits_with_error(self, runner, tmp_path):
        (tmp_path / "__init__.py").write_text("")
        (tmp_path / "config.yaml").write_text(
            "type: python\nengine: polars\n"
            "sources:\n  - name: s\n    format: csv\n    path: /tmp/x.csv\n"
            "sinks:\n  - name: t\n    format: parquet\n    path: /tmp/y/\n"
        )

        import sys as _sys
        _sys.path.insert(0, str(tmp_path.parent))
        pkg = tmp_path.name
        result = runner.invoke(cli, ["run", "--job", pkg, "--engine", "polars_xyz"])
        _sys.path.pop(0)

        assert result.exit_code == 1
