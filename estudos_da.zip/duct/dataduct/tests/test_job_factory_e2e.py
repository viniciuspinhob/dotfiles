import textwrap

import pytest

from dataduct.core.job.factory import JobFactory
from dataduct.core.exceptions import JobNotFound


class TestJobFactory:
    def test_build_config_returns_dict(self, tmp_path):
        pkg = tmp_path / "factory_test_pkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        (pkg / "config.yaml").write_text(textwrap.dedent("""
            type: python
            engine: duckdb
            sources:
              - name: s
                format: csv
                path: /tmp/x.csv
            sinks:
              - name: t
                format: parquet
                path: /tmp/y/
        """))

        import sys as _sys
        _sys.path.insert(0, str(tmp_path))
        try:
            config = JobFactory.build_config("factory_test_pkg")
        finally:
            _sys.path.pop(0)

        assert isinstance(config, dict)
        assert config["engine"] == "duckdb"
        assert config["job_package_name"] == "factory_test_pkg"

    def test_get_finds_job_class(self, tmp_path):
        pkg = tmp_path / "getjob_test_pkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        (pkg / "config.yaml").write_text(textwrap.dedent("""
            type: python
            engine: duckdb
            sources:
              - name: s
                format: csv
                path: /tmp/x.csv
            sinks:
              - name: t
                format: parquet
                path: /tmp/y/
        """))
        (pkg / "job.py").write_text(textwrap.dedent("""
            from dataduct.core.job.base import Job
            class MyTestJob(Job):
                def run(self):
                    pass
        """))

        import sys as _sys
        _sys.path.insert(0, str(tmp_path))
        try:
            config = JobFactory.build_config("getjob_test_pkg")
            job = JobFactory.get(config)
        finally:
            _sys.path.pop(0)

        from dataduct.core.job.base import Job
        assert isinstance(job, Job)

    def test_get_missing_job_module_raises(self):
        config = {"job_package_name": "totally_nonexistent_xyz_package_abc"}
        with pytest.raises(JobNotFound):
            JobFactory.get(config)

    def test_get_missing_package_name_raises(self):
        with pytest.raises(JobNotFound):
            JobFactory.get({})

    def test_get_no_job_class_raises(self, tmp_path):
        pkg = tmp_path / "nojob_test_pkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        (pkg / "job.py").write_text("x = 1")

        import sys as _sys
        _sys.path.insert(0, str(tmp_path))
        try:
            with pytest.raises(JobNotFound):
                JobFactory.get({"job_package_name": "nojob_test_pkg"})
        finally:
            _sys.path.pop(0)


try:
    import duckdb  # noqa: F401
    HAS_DUCKDB = True
except ImportError:
    HAS_DUCKDB = False


@pytest.mark.skipif(not HAS_DUCKDB, reason="duckdb not installed")
class TestEndToEndJob:
    def test_full_pipeline_csv_to_parquet(self, tmp_path):
        input_csv = tmp_path / "input.csv"
        input_csv.write_text("id,name,active\n1,Alice,true\n2,Bob,false\n3,Charlie,true\n")

        output_dir = tmp_path / "output"
        output_dir.mkdir()
        output_path = str(output_dir / "result.parquet")

        pkg = tmp_path / "e2e_test_pkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        (pkg / "config.yaml").write_text(f"""
type: python
engine: duckdb
sources:
  - name: data
    format: csv
    path: {str(input_csv)}
    header: true
sinks:
  - name: result
    format: parquet
    path: {output_path}
    mode: overwrite
custom:
  filter: "true"
""")
        (pkg / "job.py").write_text("""
from dataduct.core.job.base import Job
class E2EJob(Job):
    def run(self):
        f = self.custom.get("filter", "true")
        result = self.engine.execute_sql(f"SELECT * FROM data WHERE active = '{f}'")
        self.sinks.result.save(result)
""")

        import sys as _sys
        _sys.path.insert(0, str(tmp_path))
        try:
            from dataduct.core.job.factory import JobFactory
            from dataduct.engines import load_engine

            config = JobFactory.build_config("e2e_test_pkg")
            engine = load_engine("duckdb", {})
            try:
                job = JobFactory.get(config, engine=engine)
                job.execute()
            finally:
                engine.stop_session()
        finally:
            _sys.path.pop(0)

        import duckdb
        con = duckdb.connect()
        rows = con.execute(f"SELECT * FROM read_parquet('{output_path}')").fetchall()
        assert len(rows) == 2
        names = [r[1] for r in rows]
        assert "Alice" in names
        assert "Charlie" in names
        assert "Bob" not in names

    def test_full_pipeline_with_masking(self, tmp_path):
        input_csv = tmp_path / "users.csv"
        input_csv.write_text("id,email,name\n1,alice@test.com,Alice\n2,bob@test.com,Bob\n")
        output_path = str(tmp_path / "masked.parquet")

        pkg = tmp_path / "masking_e2e_pkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")
        (pkg / "config.yaml").write_text(f"""
type: python
engine: duckdb
sources:
  - name: users
    format: csv
    path: {str(input_csv)}
    header: true
    masking:
      provider: hash
      columns:
        - column: email
          algorithm: sha256
sinks:
  - name: masked_users
    format: parquet
    path: {output_path}
    mode: overwrite
""")
        (pkg / "job.py").write_text("""
from dataduct.core.job.base import Job
class MaskingE2EJob(Job):
    def run(self):
        self.sinks.masked_users.save(self.sources.users)
""")

        import sys as _sys
        _sys.path.insert(0, str(tmp_path))
        try:
            from dataduct.core.job.factory import JobFactory
            from dataduct.engines import load_engine

            config = JobFactory.build_config("masking_e2e_pkg")
            engine = load_engine("duckdb", {})
            try:
                job = JobFactory.get(config, engine=engine)
                job.execute()
            finally:
                engine.stop_session()
        finally:
            _sys.path.pop(0)

        import duckdb
        con = duckdb.connect()
        rows = con.execute(f"SELECT * FROM read_parquet('{output_path}')").fetchall()
        assert len(rows) == 2
        emails = [r[1] for r in rows]
        assert "alice@test.com" not in emails
        assert all(len(e) == 64 for e in emails)
