"""CLI entry point for dataduct.

Usage::

    # Run a job
    python -m dataduct run --job my_domain.my_job --engine duckdb

    # With environment overlay and custom args
    python -m dataduct run --job my_domain.my_job --env dev -c '{"year": "2025"}'

    # Validate config without executing
    python -m dataduct run --job my_domain.my_job --dry-run

    # Verbose debug logging
    python -m dataduct --verbose run --job my_domain.my_job

The ``dataduct`` console script (defined in ``pyproject.toml``) also
points here.
"""

import json
import logging
import sys

import click


def _configure_logging(verbose: bool) -> None:
    """Configure root logging level and suppress noisy third-party loggers.

    Args:
        verbose: When ``True``, sets the root level to ``DEBUG`` and
            leaves PySpark/py4j loggers at their default.  When
            ``False``, sets root level to ``INFO`` and suppresses
            ``py4j`` and ``pyspark`` loggers to ``WARNING``.
    """
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    if not verbose:
        logging.getLogger("py4j").setLevel(logging.WARNING)
        logging.getLogger("pyspark").setLevel(logging.WARNING)


@click.group()
@click.option("--verbose", "-v", is_flag=True, default=False, help="Enable debug logging")
@click.pass_context
def cli(ctx, verbose):
    """dataduct — engine-agnostic ETL framework."""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    _configure_logging(verbose)


@cli.command()
@click.option("--job", "-j", required=True, help="Job package name (e.g. examples.csv_to_parquet)")
@click.option("--env", "-e", default=None, help="Environment (dev, uat, prod)")
@click.option("--custom", "-c", default=None, help="Custom args as JSON string")
@click.option("--engine", default=None, help="Engine to use (spark, duckdb). Overrides config.")
@click.option("--dry-run", is_flag=True, default=False, help="Validate config without executing")
@click.pass_context
def run(ctx, job, env, custom, engine, dry_run):
    """Build config, load engine, and execute a job.

    Steps:

    1. Parse ``--custom`` JSON string.
    2. Build and validate config via :class:`~dataduct.core.job.factory.JobFactory`.
    3. If ``--dry-run``: print the config as JSON and exit.
    4. Instantiate and start the engine.
    5. Instantiate the job via
       :meth:`~dataduct.core.job.factory.JobFactory.get`.
    6. Call ``job.execute()``.
    7. Call ``engine.stop_session()`` in a ``finally`` block.
    """
    from dataduct.core.job.factory import JobFactory
    from dataduct.engines import load_engine

    logger = logging.getLogger("dataduct.cli")

    custom_args = {}
    if custom:
        try:
            custom_args = json.loads(custom)
        except json.JSONDecodeError as exc:
            click.echo(f"Error: --custom must be valid JSON. Got: {custom!r}\n{exc}", err=True)
            sys.exit(1)

    try:
        config = JobFactory.build_config(job_package_name=job, custom=custom_args, env=env)
    except Exception as exc:
        click.echo(f"Error building config for job {job!r}: {exc}", err=True)
        logger.debug("Config build error", exc_info=True)
        sys.exit(1)

    if dry_run:
        click.echo("--- DRY RUN ---")
        click.echo(json.dumps(config, indent=2, default=str))
        return

    engine_name = engine or config.get("engine", "spark")
    engine_config = config.get("engine_config", config.get("spark", {}))

    try:
        engine_instance = load_engine(engine_name, engine_config)
    except (ImportError, ValueError) as exc:
        click.echo(f"Error loading engine {engine_name!r}: {exc}", err=True)
        sys.exit(1)

    try:
        job_instance = JobFactory.get(config, engine=engine_instance, dry_run=dry_run)
        job_instance.execute()
        click.echo(f"Job '{job}' completed successfully.")
    except Exception as exc:
        click.echo(f"Error executing job {job!r}: {exc}", err=True)
        logger.debug("Job execution error", exc_info=True)
        sys.exit(1)
    finally:
        engine_instance.stop_session()


if __name__ == "__main__":
    cli()
