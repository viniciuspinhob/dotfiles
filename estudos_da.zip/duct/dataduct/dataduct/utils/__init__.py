from dataduct.utils.bunch import Bunch

__all__ = ["Bunch"]
