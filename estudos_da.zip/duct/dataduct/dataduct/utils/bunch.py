"""Bunch — a dict with attribute-style access.

:class:`Bunch` is used throughout the framework wherever configs or
collections of named datasets need to be accessed ergonomically by
attribute name (e.g. ``self.sources.orders``, ``self.custom.ano``).

Example::

    from dataduct.utils.bunch import Bunch

    b = Bunch({"name": "Alice", "age": 30})
    print(b.name)   # "Alice"
    b.score = 99
    print(b["score"])  # 99
    del b.age
"""


class Bunch(dict):
    """A :class:`dict` subclass that exposes keys as attributes.

    All standard dict operations remain available.  Attribute access is
    simply forwarded to the underlying dict.

    Raises:
        AttributeError: On ``getattr`` or ``delattr`` when the key does
            not exist (consistent with object attribute semantics).
    """

    def __getattr__(self, key):
        """Return the value for *key* as if it were an attribute.

        Args:
            key: Dict key to retrieve.

        Raises:
            AttributeError: If *key* is not present in the dict.
        """
        try:
            return self[key]
        except KeyError:
            raise AttributeError(f"'Bunch' has no attribute '{key}'")

    def __setattr__(self, key, value):
        """Set *key* to *value* in the underlying dict.

        Args:
            key: Dict key to set.
            value: Value to store.
        """
        self[key] = value

    def __delattr__(self, key):
        """Delete *key* from the underlying dict.

        Args:
            key: Dict key to delete.

        Raises:
            AttributeError: If *key* is not present in the dict.
        """
        try:
            del self[key]
        except KeyError:
            raise AttributeError(f"'Bunch' has no attribute '{key}'")

    def __repr__(self):
        """Return a concise representation showing the available keys."""
        keys = ", ".join(self.keys())
        return f"Bunch({keys})"
