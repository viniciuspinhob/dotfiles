"""Credential resolution service.

Abstracts secret management behind a thin interface so that job code never
references credentials directly.  Two built-in types are supported:

- ``env`` (recommended for production): reads from OS environment variables.
- ``direct`` (development only): reads from the config dict and emits a
  ``WARNING`` so that plain-text credentials are never silently accepted.

Example YAML config::

    credentials:
      type: env
      user_var: DB_USER
      password_var: DB_PASSWORD

    # or for quick local testing:
    credentials:
      type: direct
      user: postgres
      password: secret
"""

import logging
import os
from typing import Tuple

logger = logging.getLogger(__name__)


def resolve_credentials(config: dict) -> Tuple[str, str]:
    """Resolve a credential config dict to a (username, password) tuple.

    Args:
        config: Credential config dict.  Expected keys depend on ``type``:

            - ``type: "env"`` — ``user_var`` (or ``username_var``),
              ``password_var``.  Falls back to ``user`` / ``username`` /
              ``password`` if the env vars are unset.
            - ``type: "direct"`` — ``user`` (or ``username``),
              ``password``.  Emits a ``WARNING``.
            - Any other type — emits a ``WARNING`` and returns empty
              strings.

        Pass an empty dict or ``None`` to get ``("", "")``.

    Returns:
        Tuple of ``(username, password)`` strings.  Both are empty strings
        when credentials cannot be resolved.
    """
    if not config:
        return "", ""

    cred_type = config.get("type", "env")

    if cred_type == "env":
        user_var = config.get("user_var", config.get("username_var", ""))
        pass_var = config.get("password_var", "")
        user = os.environ.get(user_var, config.get("user", config.get("username", "")))
        password = os.environ.get(pass_var, config.get("password", ""))
        return user, password

    if cred_type == "direct":
        logger.warning(
            "Credential type 'direct' stores passwords in plaintext config. "
            "Use type 'env' with environment variables for production workloads."
        )
        return config.get("user", config.get("username", "")), config.get("password", "")

    logger.warning(
        "Unknown credential type %r. Supported types: 'env', 'direct'. "
        "Returning empty credentials.",
        cred_type,
    )
    return "", ""
