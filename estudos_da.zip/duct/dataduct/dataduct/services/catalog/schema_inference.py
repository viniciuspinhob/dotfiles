"""Schema inference utilities for catalog providers.

Provides helpers to convert data type information from various sources
(PyArrow, Spark, pandas, DuckDB) into a normalised
:class:`ColumnInfo` format used by catalog providers.

Inference priority (used by :class:`~dataduct.services.catalog.unity_rest.UnityCatalogRestProvider`):

1. Explicit schema from config (``schema:`` key in YAML).
2. Schema read from a Parquet file header via PyArrow.
3. Schema introspected from a live dataset.
4. Empty list (table registered without columns).
"""

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class ColumnInfo:
    """Normalised column descriptor used by catalog providers.

    Attributes:
        name: Column name.
        type_name: Normalised type string compatible with Unity Catalog
            REST API (e.g. ``"STRING"``, ``"LONG"``, ``"DOUBLE"``).
        comment: Optional column description.
        nullable: Whether the column accepts NULL values. Default: ``True``.
        position: Zero-based column position in the schema.
    """

    name: str
    type_name: str
    comment: Optional[str] = None
    nullable: bool = True
    position: int = 0


_PYARROW_TYPE_MAP: Dict[str, str] = {
    "int8": "BYTE",
    "int16": "SHORT",
    "int32": "INT",
    "int64": "LONG",
    "uint8": "SHORT",
    "uint16": "INT",
    "uint32": "LONG",
    "uint64": "LONG",
    "float16": "FLOAT",
    "float": "FLOAT",
    "float32": "FLOAT",
    "double": "DOUBLE",
    "float64": "DOUBLE",
    "bool": "BOOLEAN",
    "boolean": "BOOLEAN",
    "string": "STRING",
    "large_string": "STRING",
    "utf8": "STRING",
    "large_utf8": "STRING",
    "binary": "BINARY",
    "large_binary": "BINARY",
    "date32": "DATE",
    "date32[day]": "DATE",
    "date64": "DATE",
    "timestamp[ns]": "TIMESTAMP",
    "timestamp[us]": "TIMESTAMP",
    "timestamp[ms]": "TIMESTAMP",
    "timestamp[s]": "TIMESTAMP",
    "timestamp[ns, tz=UTC]": "TIMESTAMP",
    "timestamp[us, tz=UTC]": "TIMESTAMP",
    "timestamp[ms, tz=UTC]": "TIMESTAMP",
    "timestamp[s, tz=UTC]": "TIMESTAMP",
    "decimal128": "DECIMAL",
}


def _map_pyarrow_type(pa_type: Any) -> str:
    """Map a PyArrow type to a Unity Catalog-compatible type name.

    Args:
        pa_type: A PyArrow data type object.

    Returns:
        Normalised type name string (e.g. ``"LONG"``, ``"STRING"``).
        Defaults to ``"STRING"`` for unknown types (with a warning).
    """
    type_str = str(pa_type)

    if type_str in _PYARROW_TYPE_MAP:
        return _PYARROW_TYPE_MAP[type_str]

    if type_str.startswith("timestamp"):
        return "TIMESTAMP"
    if type_str.startswith("decimal"):
        return f"DECIMAL({pa_type.precision},{pa_type.scale})"
    if type_str.startswith("list") or type_str.startswith("large_list"):
        return "ARRAY"
    if type_str.startswith("struct"):
        return "STRUCT"
    if type_str.startswith("map"):
        return "MAP"

    logger.warning("Unknown pyarrow type '%s', defaulting to STRING", type_str)
    return "STRING"


def infer_schema_from_parquet(path: str) -> List[ColumnInfo]:
    """Read the schema of a Parquet file without loading the data.

    Args:
        path: Local file path to a Parquet file or directory.  S3/ADLS
            paths (``s3://``, ``s3a://``) are skipped (returns ``[]``).

    Returns:
        List of :class:`ColumnInfo` instances, one per column.

    Raises:
        ImportError: If PyArrow is not installed.
        RuntimeError: If the Parquet schema cannot be read.
    """
    try:
        import pyarrow.parquet as pq
    except ImportError:
        raise ImportError(
            "pyarrow is required for schema inference. "
            "Install it with: pip install dataduct[duckdb] or: pip install pyarrow"
        )

    if path.startswith("s3://") or path.startswith("s3a://"):
        return []

    try:
        schema = pq.read_schema(path)
    except Exception as e:
        raise RuntimeError(
            f"Failed to read Parquet schema from '{path}': {e}"
        ) from e

    columns = []
    for i, field in enumerate(schema):
        col = ColumnInfo(
            name=field.name,
            type_name=_map_pyarrow_type(field.type),
            nullable=field.nullable,
            position=i,
        )
        if field.metadata and b"comment" in field.metadata:
            col.comment = field.metadata[b"comment"].decode("utf-8")
        columns.append(col)

    return columns


def schema_from_explicit(columns: List[Dict[str, str]]) -> List[ColumnInfo]:
    """Build a schema from an explicit list of column definitions.

    Args:
        columns: List of dicts with the following keys:

            - ``name`` (str, required): Column name.
            - ``type`` (str, optional): Type name. Default: ``"STRING"``.
            - ``comment`` (str, optional): Column description.
            - ``nullable`` (bool, optional): Default: ``True``.

    Returns:
        Ordered list of :class:`ColumnInfo` instances.

    Raises:
        ValueError: If a column dict is missing the ``"name"`` key.
    """
    result = []
    for i, col_def in enumerate(columns):
        name = col_def.get("name")
        type_name = col_def.get("type", "STRING")
        if not name:
            raise ValueError(f"Schema column at position {i} missing 'name' field")
        result.append(
            ColumnInfo(
                name=name,
                type_name=type_name.upper(),
                comment=col_def.get("comment"),
                nullable=col_def.get("nullable", True),
                position=i,
            )
        )
    return result


def resolve_schema(
    path: Optional[str] = None,
    explicit_schema: Optional[List[Dict[str, str]]] = None,
) -> List[ColumnInfo]:
    """Resolve the final column schema, preferring explicit definitions.

    Args:
        path: File path for Parquet schema inference (used only when
            *explicit_schema* is ``None``).
        explicit_schema: Explicit column definitions (highest priority).

    Returns:
        List of :class:`ColumnInfo`, or empty list when neither source
        provides schema information.
    """
    if explicit_schema:
        return schema_from_explicit(explicit_schema)

    if path:
        return infer_schema_from_parquet(path)

    return []
