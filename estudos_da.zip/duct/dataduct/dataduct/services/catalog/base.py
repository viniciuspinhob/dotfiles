"""Abstract base class for catalog providers.

A catalog provider registers external tables in a data catalog (AWS Glue,
Databricks Unity Catalog, …) so that the table is discoverable and
queryable by other tools without copying the data.

All implementations must be registered via
:func:`~dataduct.services.catalog.register_catalog_provider`.

Implementing a custom provider::

    from dataduct.services.catalog.base import CatalogProvider
    from dataduct.services.catalog import register_catalog_provider

    class MyHiveCatalogProvider(CatalogProvider):
        def register_table(self, path, database, table_name, ...): ...
        def drop_table(self, database, table_name): ...
        def table_exists(self, database, table_name): ...
        def create_database(self, database, description=None): ...

    register_catalog_provider("hive", MyHiveCatalogProvider)
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class CatalogProvider(ABC):
    """Protocol for data catalog registration providers.

    Called by :meth:`~dataduct.connectors.base.BaseLoader.after_save`
    after a successful write to register the output table in the catalog.
    """

    @abstractmethod
    def register_table(
        self,
        path: str,
        database: str,
        table_name: str,
        data: Any = None,
        engine: Any = None,
        partition_by: Optional[List[str]] = None,
        description: Optional[str] = None,
        properties: Optional[Dict] = None,
        table_format: Optional[str] = None,
    ) -> None:
        """Register (or update) an external table in the catalog.

        Args:
            path: Storage location (S3 URI, local path, …).
            database: Target database / schema name.
            table_name: Table name to register.
            data: Optional dataset used for automatic schema inference.
            engine: Active :class:`~dataduct.engines.base.EngineAdapter`
                (required by some providers for SparkSession access).
            partition_by: List of partition column names.
            description: Human-readable table description.
            properties: Extra table properties (key/value strings).
            table_format: Override the provider's default table format
                (e.g. ``"delta"``, ``"parquet"``).
        """
        raise NotImplementedError

    @abstractmethod
    def drop_table(self, database: str, table_name: str) -> None:
        """Remove a table from the catalog.

        Args:
            database: Database / schema containing the table.
            table_name: Name of the table to drop.
        """
        raise NotImplementedError

    @abstractmethod
    def table_exists(self, database: str, table_name: str) -> bool:
        """Check whether a table is registered in the catalog.

        Args:
            database: Database / schema to check.
            table_name: Table name to look up.

        Returns:
            ``True`` if the table exists, ``False`` otherwise.
        """
        raise NotImplementedError

    @abstractmethod
    def create_database(self, database: str, description: Optional[str] = None) -> None:
        """Create a database / schema in the catalog if it does not exist.

        Implementations should be idempotent (no error if the database
        already exists).

        Args:
            database: Database name to create.
            description: Optional description for the new database.
        """
        raise NotImplementedError
