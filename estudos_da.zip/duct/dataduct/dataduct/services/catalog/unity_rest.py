"""Unity Catalog REST API provider.

Registers tables in an open-source Unity Catalog server (or any
HTTP-based catalog that implements the Unity Catalog REST protocol) using
the ``/api/2.1/unity-catalog`` endpoints.

Requirements
------------
- ``requests`` must be installed (``pip install dataduct[unity]``).
- The Unity Catalog server must be reachable from the execution
  environment.

Schema resolution order
-----------------------
1. Explicit schema passed via the ``schema`` config key.
2. Parquet schema inferred from the output file (via PyArrow).
3. Schema introspected from the dataset at write time.
4. Empty schema (table registered without columns).
"""

import json
import logging
import re
from typing import Any, Dict, List, Optional

from dataduct.services.catalog.base import CatalogProvider
from dataduct.services.catalog.schema_inference import ColumnInfo, resolve_schema
from dataduct.services.catalog.table_format import TableFormat

logger = logging.getLogger(__name__)

_TYPE_NAME_TO_TEXT: Dict[str, str] = {
    "BYTE": "tinyint",
    "SHORT": "smallint",
    "INT": "int",
    "LONG": "bigint",
    "FLOAT": "float",
    "DOUBLE": "double",
    "BOOLEAN": "boolean",
    "STRING": "string",
    "BINARY": "binary",
    "DATE": "date",
    "TIMESTAMP": "timestamp",
    "ARRAY": "array<string>",
    "STRUCT": "struct<>",
    "MAP": "map<string,string>",
}


def _spark_type_text(type_name: str) -> str:
    """Map Unity ``type_name`` to Spark SQL ``type_text`` / ``type_json.type``."""
    if "(" in type_name:
        base, params = type_name.split("(", 1)
        params = params.rstrip(")")
        base_upper = base.upper()
        if base_upper == "DECIMAL":
            return f"decimal({params})"
        return f"{base.lower()}({params})"

    return _TYPE_NAME_TO_TEXT.get(type_name.upper(), type_name.lower())


def _unity_type_name(type_name: str) -> str:
    """Return the Unity Catalog enum name (without precision/scale suffix)."""
    return type_name.split("(")[0].upper()


_DECIMAL_RE = re.compile(r"^DECIMAL\((\d+),(\d+)\)$", re.IGNORECASE)


def _normalize_storage_location(path: str) -> str:
    """Normalize storage URIs for Unity Catalog REST (expects ``s3://``, not ``s3a://``)."""
    if path.startswith("s3a://"):
        return "s3://" + path[len("s3a://") :]
    return path


class UnityCatalogRestProvider(CatalogProvider):
    """Registers tables via the Unity Catalog REST API.

    Args:
        host: Base URL of the Unity Catalog server
            (e.g. ``"http://localhost:8080"``).  Trailing slashes are
            stripped.
        token: Bearer token for authentication.  ``None`` disables the
            ``Authorization`` header.
        catalog_name: Catalog to register tables in.  Default: ``"main"``.
        table_format: Default table format.  Default: ``"parquet"``.
        schema: Explicit column schema as a list of
            ``{"name": str, "type": str}`` dicts.  When provided, schema
            inference from the file/data is skipped.
        **kwargs: Additional kwargs (ignored; for forward compatibility).
    """

    def __init__(
        self,
        host: str,
        token: Optional[str] = None,
        catalog_name: str = "main",
        table_format: str = "parquet",
        schema: Optional[List[Dict[str, str]]] = None,
        **kwargs,
    ):
        self._host = host.rstrip("/")
        self._token = token
        self._catalog_name = catalog_name
        self._table_format = TableFormat.from_string(table_format)
        self._explicit_schema = schema
        self._kwargs = kwargs

    @property
    def _base_url(self) -> str:
        """Base URL for all Unity Catalog API endpoints."""
        return f"{self._host}/api/2.1/unity-catalog"

    @property
    def _headers(self) -> Dict[str, str]:
        """HTTP headers for all requests, including optional Authorization."""
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        return headers

    def _request(self, method: str, endpoint: str, **kwargs) -> Any:
        """Send an HTTP request to the Unity Catalog REST API.

        Args:
            method: HTTP method (``"GET"``, ``"POST"``, ``"DELETE"``, …).
            endpoint: API endpoint path, relative to :attr:`_base_url`
                (leading slash is optional).
            **kwargs: Extra kwargs forwarded to ``requests.request``
                (e.g. ``json=payload``).

        Returns:
            Parsed JSON response body, or ``{}`` when the response has no
            body.  Returns ``None`` on 404.

        Raises:
            ImportError: If ``requests`` is not installed.
            requests.HTTPError: On non-2xx responses (except 404 and 409).
        """
        try:
            import requests
        except ImportError:
            raise ImportError(
                "requests is required for UnityCatalogRestProvider. "
                "Install it with: pip install dataduct[unity] or: pip install requests"
            )

        url = f"{self._base_url}/{endpoint.lstrip('/')}"
        response = requests.request(
            method, url, headers=self._headers, timeout=30, **kwargs
        )

        if response.status_code == 404:
            return None
        if response.status_code == 409:
            logger.debug("Resource already exists at %s", endpoint)
            return response.json() if response.text else {}

        if not response.ok:
            logger.error("Unity REST %s %s → %s: %s", method, url, response.status_code, response.text)

        response.raise_for_status()
        return response.json() if response.text else {}

    def register_table(
        self,
        path: str,
        database: str,
        table_name: str,
        data: Any = None,
        engine: Any = None,
        partition_by: Optional[List[str]] = None,
        description: Optional[str] = None,
        properties: Optional[Dict] = None,
        table_format: Optional[str] = None,
    ) -> None:
        """Register an external table via the Unity Catalog REST API.

        If the table already exists it is deleted and re-created.  Column
        schema is resolved via :meth:`_resolve_columns`.

        Args:
            path: Storage location URI.
            database: Schema (database) name.
            table_name: Table name to register.
            data: Optional dataset for schema introspection.
            engine: Unused by this provider.
            partition_by: Unused (REST API does not support partition
                registration in this implementation).
            description: Table comment.
            properties: Extra table properties.
            table_format: Override the default format.
        """
        fmt = (
            TableFormat.from_string(table_format)
            if table_format
            else self._table_format
        )

        full_name = f"{self._catalog_name}.{database}.{table_name}"
        columns = self._resolve_columns(path, data)

        table_payload: Dict[str, Any] = {
            "name": table_name,
            "catalog_name": self._catalog_name,
            "schema_name": database,
            "table_type": "EXTERNAL",
            "data_source_format": fmt.unity_rest_format,
            "storage_location": _normalize_storage_location(str(path)),
            "columns": [self._column_to_dict(col) for col in columns],
        }

        if description:
            table_payload["comment"] = description

        if properties:
            table_payload["properties"] = {
                str(k): str(v) for k, v in properties.items()
            }

        logger.debug(
            "Unity REST: registering table %s (format=%s) at %s",
            full_name,
            fmt.value,
            path,
        )

        existing = self._request("GET", f"tables/{full_name}")
        if existing:
            self._request("DELETE", f"tables/{full_name}")

        self._request("POST", "tables", json=table_payload)

    def drop_table(self, database: str, table_name: str) -> None:
        """Delete a table via the Unity Catalog REST API.

        Args:
            database: Schema name.
            table_name: Table name to delete.
        """
        full_name = f"{self._catalog_name}.{database}.{table_name}"
        logger.debug("Unity REST: dropping table %s", full_name)
        self._request("DELETE", f"tables/{full_name}")

    def table_exists(self, database: str, table_name: str) -> bool:
        """Check whether a table exists via the Unity Catalog REST API.

        Args:
            database: Schema name.
            table_name: Table name to check.

        Returns:
            ``True`` if the table exists (GET returns non-null).
        """
        full_name = f"{self._catalog_name}.{database}.{table_name}"
        result = self._request("GET", f"tables/{full_name}")
        return result is not None

    def create_database(self, database: str, description: Optional[str] = None) -> None:
        """Create a schema in the catalog (idempotent).

        Also ensures the catalog itself exists by calling
        :meth:`_ensure_catalog`.

        Args:
            database: Schema name to create.
            description: Optional schema comment.
        """
        self._ensure_catalog()

        full_name = f"{self._catalog_name}.{database}"
        existing = self._request("GET", f"schemas/{full_name}")
        if existing is not None:
            logger.debug("Unity REST: schema %s already exists, skipping", full_name)
            return

        schema_payload: Dict[str, Any] = {
            "name": database,
            "catalog_name": self._catalog_name,
        }
        if description:
            schema_payload["comment"] = description

        logger.debug(
            "Unity REST: creating schema %s.%s", self._catalog_name, database
        )
        self._request("POST", "schemas", json=schema_payload)

    def _ensure_catalog(self) -> None:
        """Create the catalog if it does not already exist."""
        existing = self._request("GET", f"catalogs/{self._catalog_name}")
        if existing is None:
            logger.debug("Unity REST: creating catalog %s", self._catalog_name)
            self._request(
                "POST", "catalogs", json={"name": self._catalog_name}
            )

    def _resolve_columns(self, path: str, data: Any) -> List[ColumnInfo]:
        """Determine the column schema for table registration.

        Tries in order:

        1. Explicit schema (from ``schema`` config key).
        2. Parquet schema inferred from *path*.
        3. Schema introspected from *data*.
        4. Empty list.

        Args:
            path: Output file path for Parquet schema inference.
            data: Dataset for runtime schema introspection.

        Returns:
            List of :class:`~dataduct.services.catalog.schema_inference.ColumnInfo`.
        """
        columns = resolve_schema(path=path, explicit_schema=self._explicit_schema)
        if columns:
            return columns

        if data is not None:
            return self._columns_from_data(data)

        return []

    def _columns_from_data(self, data: Any) -> List[ColumnInfo]:
        """Introspect column schema from a dataset at runtime.

        Supports Spark DataFrames, pandas DataFrames, and DuckDB relations.

        Args:
            data: Dataset to introspect.

        Returns:
            List of :class:`~dataduct.services.catalog.schema_inference.ColumnInfo`,
            or empty list if the type is not recognised.
        """
        if hasattr(data, "schema") and hasattr(data.schema, "fields"):
            spark_map = {
                "LongType": "LONG",
                "IntegerType": "INT",
                "DoubleType": "DOUBLE",
                "FloatType": "FLOAT",
                "StringType": "STRING",
                "BooleanType": "BOOLEAN",
                "DateType": "DATE",
                "TimestampType": "TIMESTAMP",
                "BinaryType": "BINARY",
                "ShortType": "SHORT",
                "ByteType": "BYTE",
            }
            return [
                ColumnInfo(
                    name=f.name,
                    type_name=spark_map.get(type(f.dataType).__name__, "STRING"),
                    nullable=f.nullable,
                    position=i,
                )
                for i, f in enumerate(data.schema.fields)
            ]

        if hasattr(data, "dtypes") and hasattr(data.dtypes, "items"):
            pandas_map = {
                "int64": "LONG",
                "int32": "INT",
                "float64": "DOUBLE",
                "float32": "FLOAT",
                "bool": "BOOLEAN",
                "object": "STRING",
                "datetime64[ns]": "TIMESTAMP",
                "datetime64[ns, UTC]": "TIMESTAMP",
            }
            return [
                ColumnInfo(
                    name=str(name),
                    type_name=pandas_map.get(str(dtype), "STRING"),
                    position=i,
                )
                for i, (name, dtype) in enumerate(data.dtypes.items())
            ]

        if hasattr(data, "columns") and hasattr(data, "types"):
            duckdb_map = {
                "BIGINT": "LONG",
                "INTEGER": "INT",
                "DOUBLE": "DOUBLE",
                "FLOAT": "FLOAT",
                "VARCHAR": "STRING",
                "BOOLEAN": "BOOLEAN",
                "DATE": "DATE",
                "TIMESTAMP": "TIMESTAMP",
            }
            return [
                ColumnInfo(
                    name=col,
                    type_name=duckdb_map.get(str(t).upper(), "STRING"),
                    position=i,
                )
                for i, (col, t) in enumerate(zip(data.columns, data.types))
            ]

        return []

    @staticmethod
    def _column_to_dict(col: ColumnInfo) -> Dict[str, Any]:
        """Serialise a :class:`~dataduct.services.catalog.schema_inference.ColumnInfo`
        to the Unity Catalog REST API column payload format.

        Unity validates ``type_json`` as a JSON object that must include
        ``name``, ``type``, ``nullable``, and ``metadata``.
        """
        type_name = _unity_type_name(col.type_name)
        type_text = _spark_type_text(col.type_name)
        type_json_obj = {
            "name": col.name,
            "type": type_text,
            "nullable": col.nullable,
            "metadata": {},
        }

        result: Dict[str, Any] = {
            "name": col.name,
            "type_name": type_name,
            "type_text": type_text,
            "type_json": json.dumps(type_json_obj),
            "position": col.position,
            "nullable": col.nullable,
        }

        decimal_match = _DECIMAL_RE.match(col.type_name.strip())
        if decimal_match:
            result["type_precision"] = int(decimal_match.group(1))
            result["type_scale"] = int(decimal_match.group(2))

        if col.comment:
            result["comment"] = col.comment
        return result
