"""AWS Glue Data Catalog provider.

Registers external tables in the AWS Glue Data Catalog using Hive SerDe
metadata so that the tables are queryable by Athena, EMR, Redshift
Spectrum, and other Hive-compatible tools.

Requirements
------------
- ``boto3`` must be installed (``pip install dataduct[aws]``).
- The execution role must have ``glue:CreateTable``, ``glue:UpdateTable``,
  ``glue:CreateDatabase``, and ``glue:GetTable`` permissions.

Security
--------
- Table and database names are validated against
  ``^[a-zA-Z_][a-zA-Z0-9_]*$`` before any API call to prevent injection.
"""

import logging
import re
from typing import Any, Dict, List, Optional

from dataduct.services.catalog.base import CatalogProvider
from dataduct.services.catalog.table_format import TableFormat

logger = logging.getLogger(__name__)

_IDENTIFIER_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")

_HIVE_INPUT_FORMAT = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat"
_HIVE_OUTPUT_FORMAT = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat"
_HIVE_SERDE = "org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe"


def _validate_identifier(value: str, field: str) -> str:
    """Validate that *value* is a safe Glue identifier.

    Args:
        value: Identifier string to validate.
        field: Field name used in error messages.

    Returns:
        The original *value* if valid.

    Raises:
        ValueError: If *value* is empty or contains invalid characters.
    """
    if not value or not isinstance(value, str):
        raise ValueError(f"Glue {field} must be a non-empty string, got {value!r}")
    if not _IDENTIFIER_RE.match(value):
        raise ValueError(
            f"Glue {field} {value!r} contains invalid characters. "
            "Only alphanumeric characters and underscores are allowed."
        )
    return value


class GlueCatalogProvider(CatalogProvider):
    """Registers tables in the AWS Glue Data Catalog.

    Args:
        region: AWS region name (e.g. ``"us-east-1"``).  Uses the default
            region from the environment if ``None``.
        table_format: Default table format.  Default: ``"parquet"``.
        **kwargs: Additional kwargs (ignored; for forward compatibility).
    """

    def __init__(self, region: str = None, table_format: str = "parquet", **kwargs):
        self._region = region
        self._default_format = TableFormat.from_string(table_format)
        self._kwargs = kwargs

    def _client(self):
        """Create and return a boto3 Glue client.

        Returns:
            A ``boto3.client("glue", ...)`` instance.

        Raises:
            ImportError: If boto3 is not installed.
        """
        try:
            import boto3
        except ImportError:
            raise ImportError(
                "boto3 is not installed. Install it with: pip install dataduct[aws] "
                "or: pip install boto3"
            )
        kwargs = {}
        if self._region:
            kwargs["region_name"] = self._region
        return boto3.client("glue", **kwargs)

    def register_table(
        self,
        path: str,
        database: str,
        table_name: str,
        data: Any = None,
        engine: Any = None,
        partition_by: Optional[List[str]] = None,
        description: Optional[str] = None,
        properties: Optional[Dict] = None,
        table_format: Optional[str] = None,
    ) -> None:
        """Create or update an external table in the Glue Data Catalog.

        If the table already exists it is updated via ``update_table``;
        otherwise it is created via ``create_table``.  Schema is inferred
        from *data* when provided.

        Args:
            path: S3 location of the data (e.g. ``"s3://my-bucket/path/"``).
            database: Glue database name.
            table_name: Table name to register.
            data: Optional dataset for automatic schema inference (Spark
                DataFrame or pandas DataFrame).
            engine: Unused by this provider.
            partition_by: Partition column names.
            description: Table description stored in Glue metadata.
            properties: Extra Glue table parameters.
            table_format: Override the default table format.
        """
        fmt = (
            TableFormat.from_string(table_format)
            if table_format
            else self._default_format
        )

        safe_db = _validate_identifier(database, "database")
        safe_table = _validate_identifier(table_name, "table_name")

        client = self._client()
        schema_list = self._extract_schema(data, engine, partition_by)

        storage_descriptor = {
            "Location": str(path),
            "InputFormat": _HIVE_INPUT_FORMAT,
            "OutputFormat": _HIVE_OUTPUT_FORMAT,
            "SerdeInfo": {"SerializationLibrary": _HIVE_SERDE},
            "Columns": [c for c in schema_list if c["Name"] not in (partition_by or [])],
        }

        table_input: Dict[str, Any] = {
            "Name": safe_table,
            "StorageDescriptor": storage_descriptor,
            "PartitionKeys": [
                {"Name": _validate_identifier(p, "partition_by"), "Type": "string"}
                for p in (partition_by or [])
            ],
            "TableType": "EXTERNAL_TABLE",
            "Parameters": {"classification": fmt.glue_classification, **(properties or {})},
        }
        if description:
            table_input["Description"] = str(description)

        logger.debug("Glue: registering table %s.%s (format=%s) at %s", safe_db, safe_table, fmt.value, path)
        if self.table_exists(safe_db, safe_table):
            client.update_table(DatabaseName=safe_db, TableInput=table_input)
        else:
            client.create_table(DatabaseName=safe_db, TableInput=table_input)

    def drop_table(self, database: str, table_name: str) -> None:
        """Delete a table from the Glue Data Catalog.

        Args:
            database: Glue database name.
            table_name: Table name to delete.
        """
        safe_db = _validate_identifier(database, "database")
        safe_table = _validate_identifier(table_name, "table_name")
        client = self._client()
        logger.debug("Glue: dropping table %s.%s", safe_db, safe_table)
        client.delete_table(DatabaseName=safe_db, Name=safe_table)

    def table_exists(self, database: str, table_name: str) -> bool:
        """Check whether a table exists in the Glue Data Catalog.

        Args:
            database: Glue database name.
            table_name: Table name to check.

        Returns:
            ``True`` if the table exists.
        """
        safe_db = _validate_identifier(database, "database")
        safe_table = _validate_identifier(table_name, "table_name")
        client = self._client()
        try:
            client.get_table(DatabaseName=safe_db, Name=safe_table)
            return True
        except client.exceptions.EntityNotFoundException:
            return False

    def create_database(self, database: str, description: Optional[str] = None) -> None:
        """Create a Glue database (idempotent).

        Args:
            database: Database name to create.
            description: Optional description.
        """
        safe_db = _validate_identifier(database, "database")
        client = self._client()
        db_input: Dict[str, Any] = {"Name": safe_db}
        if description:
            db_input["Description"] = str(description)
        try:
            logger.debug("Glue: creating database %s", safe_db)
            client.create_database(DatabaseInput=db_input)
        except client.exceptions.AlreadyExistsException:
            logger.debug("Glue: database %s already exists, skipping", safe_db)

    def _extract_schema(
        self, data: Any, engine: Any, partition_by: Optional[List[str]]
    ) -> List[Dict]:
        """Infer a Glue-compatible column schema from *data*.

        Supports Spark DataFrames (``data.schema``) and pandas DataFrames
        (``data.dtypes``).

        Args:
            data: Dataset to inspect.
            engine: Unused.
            partition_by: Partition columns (excluded from the column
                list when present).

        Returns:
            List of ``{"Name": str, "Type": str}`` dicts for the Glue
            ``StorageDescriptor.Columns`` field.  Returns ``[]`` if the
            schema cannot be determined.
        """
        if data is None:
            return []

        spark_type_map = {
            "LongType": "bigint", "IntegerType": "int", "DoubleType": "double",
            "FloatType": "float", "StringType": "string", "BooleanType": "boolean",
            "DateType": "date", "TimestampType": "timestamp",
        }

        if hasattr(data, "schema"):
            return [
                {"Name": f.name, "Type": spark_type_map.get(type(f.dataType).__name__, "string")}
                for f in data.schema.fields
            ]

        if hasattr(data, "dtypes") and hasattr(data.dtypes, "items"):
            dtype_map = {
                "int64": "bigint", "int32": "int", "float64": "double",
                "float32": "float", "bool": "boolean", "object": "string",
            }
            return [
                {"Name": name, "Type": dtype_map.get(str(dtype), "string")}
                for name, dtype in data.dtypes.items()
            ]

        logger.debug("Glue: could not extract schema from data type %s", type(data).__name__)
        return []
