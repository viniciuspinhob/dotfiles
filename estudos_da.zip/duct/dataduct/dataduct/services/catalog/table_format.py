"""Table format enum and engine-specific format mappings.

:class:`TableFormat` is used by catalog providers to translate a generic
format name (e.g. ``"parquet"``) into the engine-specific identifier
required by each catalog API.

Supported formats
-----------------
- ``parquet`` — Apache Parquet (columnar, no ACID).
- ``delta`` — Delta Lake (ACID transactions, time travel).
- ``iceberg`` — Apache Iceberg (open table format).
- ``hudi`` — Apache Hudi (upserts, incremental processing).
"""

from enum import Enum
from typing import Dict


class TableFormat(Enum):
    """Enumeration of supported open table formats.

    Use :meth:`from_string` to parse a config string into a member.
    """

    PARQUET = "parquet"
    DELTA = "delta"
    ICEBERG = "iceberg"
    HUDI = "hudi"

    @property
    def spark_source(self) -> str:
        """Spark ``USING`` clause value for ``CREATE TABLE … USING {source}``."""
        return _SPARK_SOURCE_MAP[self]

    @property
    def unity_rest_format(self) -> str:
        """``data_source_format`` value for the Unity Catalog REST API."""
        return _UNITY_REST_FORMAT_MAP[self]

    @property
    def glue_classification(self) -> str:
        """Glue table ``classification`` parameter value."""
        return _GLUE_CLASSIFICATION_MAP[self]

    @classmethod
    def from_string(cls, value: str) -> "TableFormat":
        """Parse a case-insensitive format string to a :class:`TableFormat` member.

        Args:
            value: Format string (e.g. ``"Parquet"``, ``"delta"``).

        Returns:
            Matching :class:`TableFormat` member.

        Raises:
            ValueError: If *value* does not match any member.
        """
        normalized = value.strip().lower()
        for member in cls:
            if member.value == normalized:
                return member
        available = [m.value for m in cls]
        raise ValueError(
            f"Unknown table format '{value}'. Available: {available}"
        )


_SPARK_SOURCE_MAP: Dict[TableFormat, str] = {
    TableFormat.PARQUET: "PARQUET",
    TableFormat.DELTA: "DELTA",
    TableFormat.ICEBERG: "ICEBERG",
    TableFormat.HUDI: "HUDI",
}

_UNITY_REST_FORMAT_MAP: Dict[TableFormat, str] = {
    TableFormat.PARQUET: "PARQUET",
    TableFormat.DELTA: "DELTA",
    TableFormat.ICEBERG: "ICEBERG",
    TableFormat.HUDI: "HUDI",
}

_GLUE_CLASSIFICATION_MAP: Dict[TableFormat, str] = {
    TableFormat.PARQUET: "parquet",
    TableFormat.DELTA: "delta",
    TableFormat.ICEBERG: "iceberg",
    TableFormat.HUDI: "hudi",
}
