"""Catalog service public API.

Provides a registry of :class:`~dataduct.services.catalog.base.CatalogProvider`
implementations and the :func:`apply_catalog` entry point called by
:meth:`~dataduct.connectors.base.BaseLoader.after_save`.

Built-in providers
------------------
- ``glue`` — :class:`~dataduct.services.catalog.glue.GlueCatalogProvider`
  (AWS Glue Data Catalog, requires ``boto3``).
- ``unity`` — :class:`~dataduct.services.catalog.unity.UnityCatalogProvider`
  (Databricks Unity Catalog via Spark SQL).
- ``unity_rest`` — :class:`~dataduct.services.catalog.unity_rest.UnityCatalogRestProvider`
  (Unity Catalog OSS REST API, requires ``requests``).

Registering a custom provider::

    from dataduct.services.catalog import register_catalog_provider
    from dataduct.services.catalog.base import CatalogProvider

    class HiveCatalogProvider(CatalogProvider):
        ...

    register_catalog_provider("hive", HiveCatalogProvider)
"""

from typing import Any, Dict, Type

from dataduct.services.catalog.base import CatalogProvider
from dataduct.services.catalog.glue import GlueCatalogProvider
from dataduct.services.catalog.schema_inference import ColumnInfo, resolve_schema
from dataduct.services.catalog.table_format import TableFormat
from dataduct.services.catalog.unity import UnityCatalogProvider
from dataduct.services.catalog.unity_rest import UnityCatalogRestProvider

_catalog_registry: Dict[str, Type[CatalogProvider]] = {
    "glue": GlueCatalogProvider,
    "unity": UnityCatalogProvider,
    "unity_rest": UnityCatalogRestProvider,
}


def get_catalog_provider(name: str, **kwargs) -> CatalogProvider:
    """Instantiate and return a catalog provider by name.

    Args:
        name: Registered provider key (``"glue"``, ``"unity"``, or
            ``"unity_rest"``).
        **kwargs: Provider-specific constructor arguments extracted from
            the sink ``catalog`` config block.

    Returns:
        A new instance of the requested :class:`CatalogProvider`.

    Raises:
        ValueError: If *name* is not registered.
    """
    if name not in _catalog_registry:
        available = list(_catalog_registry.keys())
        raise ValueError(f"Catalog provider '{name}' not found. Available: {available}")
    return _catalog_registry[name](**kwargs)


def register_catalog_provider(name: str, cls: Type[CatalogProvider]):
    """Register a custom catalog provider class under *name*.

    Args:
        name: Key used in YAML config (e.g. ``provider: hive``).
        cls: A :class:`CatalogProvider` subclass (*not* an instance).
    """
    _catalog_registry[name] = cls


def apply_catalog(
    data: Any,
    catalog_config: Dict,
    path: str,
    engine: Any = None,
    partition_by=None,
) -> None:
    """Register a dataset in the configured catalog after a write.

    Entry point called by
    :meth:`~dataduct.connectors.base.BaseLoader.after_save`.

    Steps performed:

    1. Extract ``provider``, ``database``, ``table_name``, and optional
       fields from *catalog_config*.
    2. Build extra provider kwargs from the remaining config keys.
    3. Instantiate the provider via :func:`get_catalog_provider`.
    4. Call ``provider.create_database(database)`` (idempotent).
    5. Call ``provider.register_table(…)``.

    Args:
        data: The dataset that was just written.  Used for schema
            inference by some providers.
        catalog_config: Catalog configuration dict from the sink config.
        path: Physical storage location of the written data.
        engine: Active :class:`~dataduct.engines.base.EngineAdapter`.
        partition_by: Partition column names.
    """
    provider_name = catalog_config.get("provider")
    if not provider_name:
        return

    database = catalog_config.get("database")
    table_name = catalog_config.get("table_name")
    description = catalog_config.get("description")
    properties = catalog_config.get("properties", {})
    table_format = catalog_config.get("table_format")

    provider_kwargs = {k: v for k, v in catalog_config.items()
                      if k not in ("provider", "database", "table_name", "description",
                                   "properties", "table_format")}

    provider = get_catalog_provider(provider_name, **provider_kwargs)
    provider.create_database(database)
    provider.register_table(
        path=path,
        database=database,
        table_name=table_name,
        data=data,
        engine=engine,
        partition_by=partition_by,
        description=description,
        properties=properties,
        table_format=table_format,
    )


__all__ = [
    "CatalogProvider",
    "ColumnInfo",
    "GlueCatalogProvider",
    "TableFormat",
    "UnityCatalogProvider",
    "UnityCatalogRestProvider",
    "apply_catalog",
    "get_catalog_provider",
    "register_catalog_provider",
    "resolve_schema",
]
