"""Databricks Unity Catalog provider (Spark SQL).

Registers external tables in Databricks Unity Catalog by executing Spark
SQL DDL statements (``CREATE TABLE IF NOT EXISTS … USING … LOCATION …``).

This provider requires:

- An active :class:`pyspark.sql.SparkSession` with access to a Databricks
  cluster or a local Unity Catalog-compatible Spark deployment.
- ``pip install dataduct[spark]``

Security
--------
- Table, database, catalog, and partition column names are validated
  against ``^[a-zA-Z_][a-zA-Z0-9_]*$`` before constructing SQL.
- Description and property values are escaped via :func:`_escape_string`.
"""

import logging
import re
from typing import Any, Dict, List, Optional

from dataduct.services.catalog.base import CatalogProvider
from dataduct.services.catalog.table_format import TableFormat

logger = logging.getLogger(__name__)

_IDENTIFIER_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


def _validate_identifier(value: str, field: str) -> str:
    """Validate that *value* is a safe SQL identifier.

    Args:
        value: Identifier to validate.
        field: Field name used in error messages.

    Returns:
        The original *value* if valid.

    Raises:
        ValueError: If *value* is empty or contains invalid characters.
    """
    if not value or not isinstance(value, str):
        raise ValueError(f"Catalog {field} must be a non-empty string, got {value!r}")
    if not _IDENTIFIER_RE.match(value):
        raise ValueError(
            f"Catalog {field} {value!r} contains invalid characters. "
            "Only alphanumeric characters and underscores are allowed."
        )
    return value


def _escape_string(value: str) -> str:
    """Escape backslashes and single quotes in SQL string literals.

    Args:
        value: Raw string to escape.

    Returns:
        Escaped string safe for use inside single-quoted SQL literals.
    """
    return value.replace("\\", "\\\\").replace("'", "\\'")


class UnityCatalogProvider(CatalogProvider):
    """Registers tables in Databricks Unity Catalog via Spark SQL DDL.

    Args:
        host: Databricks workspace URL (informational; not used for API
            calls — Spark handles the connection).
        token: Databricks personal access token (informational).
        catalog: Unity Catalog catalog name.  Default: ``"main"``.
        table_format: Default table format.  Default: ``"delta"``.
        **kwargs: Additional kwargs (ignored; for forward compatibility).
    """

    def __init__(
        self,
        host: str = None,
        token: str = None,
        catalog: str = "main",
        table_format: str = "delta",
        **kwargs,
    ):
        self._host = host
        self._token = token
        self._catalog = _validate_identifier(catalog, "catalog")
        self._default_format = TableFormat.from_string(table_format)
        self._kwargs = kwargs

    def register_table(
        self,
        path: str,
        database: str,
        table_name: str,
        data: Any = None,
        engine: Any = None,
        partition_by: Optional[List[str]] = None,
        description: Optional[str] = None,
        properties: Optional[Dict] = None,
        table_format: Optional[str] = None,
    ) -> None:
        """Register an external table in Unity Catalog using Spark SQL.

        Executes ``CREATE TABLE IF NOT EXISTS … USING {format} LOCATION …``.

        Args:
            path: Storage location (S3, ADLS, GCS URI, …).
            database: Unity Catalog schema (database) name.
            table_name: Table name to register.
            data: Unused by this provider.
            engine: Used to obtain the SparkSession.
            partition_by: Partition column names.
            description: Added as ``COMMENT ON TABLE``.
            properties: Added as ``TBLPROPERTIES``.
            table_format: Override the default format.
        """
        fmt = (
            TableFormat.from_string(table_format)
            if table_format
            else self._default_format
        )

        safe_db = _validate_identifier(database, "database")
        safe_table = _validate_identifier(table_name, "table_name")
        full_name = f"`{self._catalog}`.`{safe_db}`.`{safe_table}`"
        safe_path = _escape_string(str(path))

        spark = self._get_spark(engine)

        partition_clause = ""
        if partition_by:
            safe_cols = [_validate_identifier(c, "partition_by column") for c in partition_by]
            partition_clause = f"PARTITIONED BY ({', '.join(safe_cols)})"

        tbl_props = ""
        if properties:
            props_str = ", ".join(
                f"'{_escape_string(k)}' = '{_escape_string(str(v))}'"
                for k, v in properties.items()
            )
            tbl_props = f"TBLPROPERTIES ({props_str})"

        source = fmt.spark_source
        logger.debug("Unity: registering table %s (format=%s) at %s", full_name, source, safe_path)
        spark.sql(f"""
            CREATE TABLE IF NOT EXISTS {full_name}
            USING {source}
            LOCATION '{safe_path}'
            {partition_clause}
            {tbl_props}
        """)

        if description:
            safe_desc = _escape_string(description)
            spark.sql(f"COMMENT ON TABLE {full_name} IS '{safe_desc}'")

    def drop_table(self, database: str, table_name: str) -> None:
        """Drop a table from Unity Catalog.

        Args:
            database: Schema name.
            table_name: Table name to drop.
        """
        safe_db = _validate_identifier(database, "database")
        safe_table = _validate_identifier(table_name, "table_name")
        full_name = f"`{self._catalog}`.`{safe_db}`.`{safe_table}`"
        spark = self._get_spark()
        logger.debug("Unity: dropping table %s", full_name)
        spark.sql(f"DROP TABLE IF EXISTS {full_name}")

    def table_exists(self, database: str, table_name: str) -> bool:
        """Check whether a table exists in Unity Catalog.

        Uses ``DESCRIBE TABLE`` and returns ``False`` on any exception
        (including ``AnalysisException`` when the table is missing).

        Args:
            database: Schema name.
            table_name: Table name to check.

        Returns:
            ``True`` if the table exists.
        """
        safe_db = _validate_identifier(database, "database")
        safe_table = _validate_identifier(table_name, "table_name")
        full_name = f"`{self._catalog}`.`{safe_db}`.`{safe_table}`"
        spark = self._get_spark()
        try:
            spark.sql(f"DESCRIBE TABLE {full_name}")
            return True
        except Exception:
            return False

    def create_database(self, database: str, description: Optional[str] = None) -> None:
        """Create a schema in Unity Catalog (idempotent).

        Args:
            database: Schema name to create.
            description: Optional description added as ``COMMENT ON DATABASE``.
        """
        safe_db = _validate_identifier(database, "database")
        full_name = f"`{self._catalog}`.`{safe_db}`"
        spark = self._get_spark()
        logger.debug("Unity: creating database %s", full_name)
        spark.sql(f"CREATE DATABASE IF NOT EXISTS {full_name}")
        if description:
            safe_desc = _escape_string(description)
            spark.sql(f"COMMENT ON DATABASE {full_name} IS '{safe_desc}'")

    def _get_spark(self, engine: Any = None):
        """Obtain a SparkSession from *engine* or the active session.

        Args:
            engine: Optional :class:`~dataduct.engines.base.EngineAdapter`
                that exposes a ``session`` attribute.

        Returns:
            A :class:`pyspark.sql.SparkSession`.

        Raises:
            RuntimeError: If PySpark is not installed or no active session
                exists.
        """
        if engine and hasattr(engine, "session"):
            return engine.session
        try:
            from pyspark.sql import SparkSession
            session = SparkSession.getActiveSession()
            if session is None:
                raise RuntimeError("No active SparkSession")
            return session
        except ImportError:
            raise RuntimeError(
                "UnityCatalogProvider requires PySpark. "
                "Install it with: pip install dataduct[spark] or: pip install pyspark"
            )
        except RuntimeError:
            raise RuntimeError(
                "UnityCatalogProvider requires an active SparkSession. "
                "Pass an engine or ensure a SparkSession is active."
            )
