"""Masking service public API.

Provides a registry of :class:`~dataduct.services.masking.base.MaskingProvider`
implementations and the :func:`apply_masking` entry point used by
:meth:`~dataduct.core.job.base.Job.register_sources`.

Built-in providers
------------------
- ``hash`` — :class:`~dataduct.services.masking.hash.HashMaskingProvider`

Adding a custom provider::

    from dataduct.services.masking import register_masking_provider
    from dataduct.services.masking.base import MaskingProvider

    class MyProvider(MaskingProvider):
        def mask(self, data, columns_config, engine=None): ...
        def unmask(self, data, columns_config, engine=None): ...

    register_masking_provider("my_algo", MyProvider)
"""

from typing import Dict, Type

from dataduct.services.masking.base import MaskingProvider
from dataduct.services.masking.hash import HashMaskingProvider

_masking_registry: Dict[str, Type[MaskingProvider]] = {
    "hash": HashMaskingProvider,
}


def get_masking_provider(name: str) -> MaskingProvider:
    """Instantiate and return a masking provider by name.

    Args:
        name: Registered provider key (e.g. ``"hash"``).

    Returns:
        A new instance of the requested :class:`MaskingProvider`.

    Raises:
        ValueError: If *name* is not registered.
    """
    if name not in _masking_registry:
        available = list(_masking_registry.keys())
        raise ValueError(f"Masking provider '{name}' not found. Available: {available}")
    return _masking_registry[name]()


def register_masking_provider(name: str, cls: Type[MaskingProvider]):
    """Register a custom masking provider class under *name*.

    Args:
        name: Key used in YAML config (e.g. ``provider: fpe``).
        cls: A :class:`MaskingProvider` subclass (*not* an instance).
    """
    _masking_registry[name] = cls


def apply_masking(data, masking_config: Dict, engine) -> any:
    """Apply masking to *data* according to *masking_config*.

    Entry point called by
    :meth:`~dataduct.core.job.base.Job.register_sources` when a ``masking``
    block is present in the source config.

    Args:
        data: Input dataset.
        masking_config: Dict with ``"provider"`` (default ``"hash"``) and
            ``"columns"`` keys.
        engine: Active :class:`~dataduct.engines.base.EngineAdapter`.

    Returns:
        Masked dataset.  If ``columns`` is empty, *data* is returned
        unchanged.
    """
    provider_name = masking_config.get("provider", "hash")
    columns_config = masking_config.get("columns", [])

    if not columns_config:
        return data

    provider = get_masking_provider(provider_name)
    return provider.mask(data, columns_config, engine=engine)


__all__ = [
    "MaskingProvider",
    "HashMaskingProvider",
    "get_masking_provider",
    "register_masking_provider",
    "apply_masking",
]
