"""Abstract base class for masking providers.

A masking provider transforms sensitive columns in a dataset according to
a columns config list.  All implementations must be registered via
:func:`~dataduct.services.masking.register_masking_provider` so that jobs
can reference them by name in YAML.

Implementing a custom provider::

    from dataduct.services.masking.base import MaskingProvider
    from dataduct.services.masking import register_masking_provider

    class FpeMaskingProvider(MaskingProvider):
        def mask(self, data, columns_config, engine=None):
            ...  # format-preserving encryption logic

        def unmask(self, data, columns_config, engine=None):
            ...  # decryption logic

    register_masking_provider("fpe", FpeMaskingProvider)
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List


class MaskingProvider(ABC):
    """Protocol for data masking/anonymisation providers.

    Implementations operate on engine-native datasets (Spark DataFrames,
    DuckDB relations) and must return a dataset of the same type.
    """

    @abstractmethod
    def mask(self, data: Any, columns_config: List[Dict], engine=None) -> Any:
        """Apply masking to the specified columns of *data*.

        Args:
            data: Input dataset (engine-native type).
            columns_config: List of column masking specs.  Each dict must
                contain at least a ``"column"`` key and optionally an
                ``"algorithm"`` key.
            engine: Active :class:`~dataduct.engines.base.EngineAdapter`.
                Required by most providers for SQL-based masking.

        Returns:
            Masked dataset of the same type as *data*.

        Raises:
            RuntimeError: If an engine is required but not provided.
        """
        raise NotImplementedError

    @abstractmethod
    def unmask(self, data: Any, columns_config: List[Dict], engine=None) -> Any:
        """Reverse the masking operation (if supported).

        Args:
            data: Masked dataset to unmask.
            columns_config: Column specs used during masking.
            engine: Active :class:`~dataduct.engines.base.EngineAdapter`.

        Returns:
            Unmasked dataset.

        Raises:
            NotImplementedError: For irreversible masking schemes (e.g.
                hash).
        """
        raise NotImplementedError
