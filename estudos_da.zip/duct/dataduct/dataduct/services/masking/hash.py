"""Hash-based masking provider.

Applies one-way cryptographic hash functions (SHA-256 or MD5) to
designated columns.  The implementation is engine-agnostic: it generates
the appropriate SQL expression for either Spark or DuckDB and executes it
via temp tables/views to avoid mutating the original dataset.

Properties
----------
- **Deterministic**: the same input always produces the same hash.
- **Irreversible**: hash masking cannot be reversed (``unmask`` raises
  :class:`NotImplementedError`).
- **Engine-agnostic**: uses ``sha2(col, 256)`` for Spark and
  ``sha256(col)`` for DuckDB.
- **Safe temp names**: UUID-based table names prevent collisions when
  multiple masking operations run concurrently.
"""

import logging
import uuid
from typing import Any, Dict, List

from dataduct.services.masking.base import MaskingProvider

logger = logging.getLogger(__name__)

_SUPPORTED_ALGORITHMS = {"sha256", "md5"}


class HashMaskingProvider(MaskingProvider):
    """Masks columns by replacing values with their cryptographic hash.

    SQL templates per engine
    ------------------------
    +----------+---------+----------------------------------+
    | algo     | engine  | SQL expression                   |
    +==========+=========+==================================+
    | sha256   | spark   | sha2(cast(col as string), 256)   |
    | sha256   | duckdb  | sha256(cast(col as varchar))     |
    | md5      | spark   | md5(cast(col as string))         |
    | md5      | duckdb  | md5(cast(col as varchar))        |
    +----------+---------+----------------------------------+
    """

    ALGORITHM_SQL = {
        "sha256": {"spark": "sha2(cast({col} as string), 256)", "duckdb": "sha256(cast({col} as varchar))"},
        "md5": {"spark": "md5(cast({col} as string))", "duckdb": "md5(cast({col} as varchar))"},
    }

    def mask(self, data: Any, columns_config: List[Dict], engine=None) -> Any:
        """Apply hash masking to the columns specified in *columns_config*.

        Columns not listed in *columns_config* are passed through unchanged.
        Columns listed but absent from the dataset are skipped with a
        warning.

        Args:
            data: Input dataset (Spark DataFrame or DuckDB relation).
            columns_config: List of dicts with ``"column"`` (required) and
                ``"algorithm"`` (optional, default ``"sha256"``) keys.
            engine: Active :class:`~dataduct.engines.base.EngineAdapter`.
                Required.

        Returns:
            Masked dataset of the same type as *data*.

        Raises:
            RuntimeError: If *engine* is ``None``.
            ValueError: If an unsupported algorithm is specified.
        """
        if engine is None:
            raise RuntimeError("HashMaskingProvider requires an engine to apply masking")

        engine_type = self._detect_engine_type(engine)
        col_names = self._get_columns(data, engine)

        if not col_names:
            logger.warning("HashMaskingProvider: could not determine columns from data, skipping masking")
            return data

        masked_cols = {c["column"] for c in columns_config}
        unknown_cols = masked_cols - set(col_names)
        if unknown_cols:
            logger.warning(
                "HashMaskingProvider: columns %s not found in data (available: %s), they will be skipped",
                unknown_cols, col_names,
            )

        select_parts = []
        for col in col_names:
            if col in masked_cols:
                algo = next(
                    (c.get("algorithm", "sha256") for c in columns_config if c["column"] == col),
                    "sha256",
                )
                if algo not in _SUPPORTED_ALGORITHMS:
                    raise ValueError(
                        f"Unsupported masking algorithm: {algo!r}. "
                        f"Supported: {sorted(_SUPPORTED_ALGORITHMS)}"
                    )
                sql_template = self.ALGORITHM_SQL[algo]
                expr = sql_template[engine_type].format(col=f'"{col}"')
                select_parts.append(f"{expr} as {col}")
                logger.debug("Masking column '%s' with %s", col, algo)
            else:
                select_parts.append(f'"{col}"')

        return self._apply_select(data, select_parts, engine, engine_type)

    def unmask(self, data: Any, columns_config: List[Dict], engine=None) -> Any:
        """Not supported — hash masking is irreversible.

        Raises:
            NotImplementedError: Always.
        """
        raise NotImplementedError("Hash masking is irreversible")

    def _detect_engine_type(self, engine) -> str:
        """Infer engine type from the adapter class name.

        Args:
            engine: An :class:`~dataduct.engines.base.EngineAdapter`.

        Returns:
            ``"duckdb"`` or ``"spark"``.
        """
        class_name = type(engine).__name__.lower()
        if "duckdb" in class_name:
            return "duckdb"
        return "spark"

    def _get_columns(self, data: Any, engine) -> List[str]:
        """Extract column names from *data*.

        Supports Spark DataFrames (``data.columns``) and Spark schemas
        (``data.schema.fields``).

        Args:
            data: Dataset to introspect.
            engine: Unused; kept for API symmetry.

        Returns:
            Ordered list of column name strings, or empty list if columns
            cannot be determined.
        """
        if hasattr(data, "columns"):
            return list(data.columns)
        if hasattr(data, "schema"):
            return [f.name for f in data.schema.fields]
        return []

    def _apply_select(self, data: Any, select_parts: List[str], engine, engine_type: str) -> Any:
        """Execute a SELECT with the masking expressions.

        Uses UUID-based temp table names to avoid collisions.

        - **DuckDB**: registers data as a TEMP TABLE, builds a new TEMP
          TABLE with the masked SELECT, then returns a relation.
        - **Spark**: registers a temp view, then queries it via
          ``engine.execute_sql``.

        Args:
            data: Source dataset.
            select_parts: List of SQL SELECT expressions (one per column).
            engine: Active engine.
            engine_type: ``"duckdb"`` or ``"spark"``.

        Returns:
            Masked dataset.

        Raises:
            RuntimeError: If the engine type is not supported.
        """
        select_sql = ", ".join(select_parts)
        tmp_id = uuid.uuid4().hex[:12]
        src_table = f"__masking_src_{tmp_id}"
        res_table = f"__masking_res_{tmp_id}"

        if engine_type == "duckdb":
            session = engine.session
            try:
                session.execute(f"CREATE OR REPLACE TEMP TABLE {src_table} AS SELECT * FROM data")
                session.execute(
                    f"CREATE OR REPLACE TEMP TABLE {res_table} AS "
                    f"SELECT {select_sql} FROM {src_table}"
                )
            finally:
                session.execute(f"DROP TABLE IF EXISTS {src_table}")
            return session.sql(f"SELECT * FROM {res_table}")

        if hasattr(data, "createOrReplaceTempView"):
            tmp_view = f"__masking_tmp_{tmp_id}"
            data.createOrReplaceTempView(tmp_view)
            return engine.execute_sql(f"SELECT {select_sql} FROM {tmp_view}")

        raise RuntimeError(f"Cannot apply masking for engine type: {engine_type}")
