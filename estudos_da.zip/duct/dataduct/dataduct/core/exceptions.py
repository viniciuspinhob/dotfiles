"""Typed exceptions for the dataduct framework.

Hierarchy:
    DataductError
    ├── ConfigError
    │   ├── SourceMissingFormat
    │   ├── SourceInvalidFormat
    │   ├── SinkMissingFormat
    │   └── SinkInvalidFormat
    ├── EngineNotFound
    ├── ConnectorNotFound
    ├── JobNotFound
    └── CredentialError
"""


class DataductError(Exception):
    """Base exception for all dataduct errors."""


class ConfigError(DataductError):
    """Raised when a job configuration is invalid or cannot be parsed."""


class SourceMissingFormat(ConfigError):
    """Raised when a source entry in config is missing the required 'format' field."""


class SourceInvalidFormat(ConfigError):
    """Raised when a source format is not registered or unknown."""


class SinkMissingFormat(ConfigError):
    """Raised when a sink entry in config is missing the required 'format' field."""


class SinkInvalidFormat(ConfigError):
    """Raised when a sink format is not registered or unknown."""


class EngineNotFound(DataductError):
    """Raised when the requested compute engine is not registered.

    Usually means the optional extra is not installed
    (e.g. ``pip install dataduct[spark]``).
    """


class ConnectorNotFound(DataductError):
    """Raised when no connector is registered for the given format and kind."""


class JobNotFound(DataductError):
    """Raised when the job module cannot be imported or contains no Job subclass."""


class CredentialError(DataductError):
    """Raised when credential resolution fails (e.g. missing env var)."""
