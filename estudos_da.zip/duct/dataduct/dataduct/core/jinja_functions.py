"""Safe Jinja2 template functions available inside YAML config files.

These functions are injected into every Jinja2 template rendered by
:func:`dataduct.core.config._render_jinja`.  They are intentionally
minimal: only environment-variable access is exposed so that configs
remain declarative and auditable.

Usage in config.yaml::

    sources:
      - name: raw
        format: parquet
        path: "s3://{{ env_var('BUCKET') }}/raw/"

Available functions
-------------------
- ``env_var(name, default="")`` — read an OS environment variable.
- ``get_env_var(name, default="")`` — alias for ``env_var``.
"""

import os


def pkg_resource(package: str, *parts: str) -> str:
    """Resolve a path inside an installed Python package to a filesystem string.

    Args:
        package: Dotted package name (e.g. ``"examples.data"``).
        *parts: Path segments relative to the package root.

    Returns:
        Filesystem path string suitable for connector ``path`` options.
    """
    from importlib.resources import files

    resource = files(package)
    for part in parts:
        resource = resource.joinpath(part)
    return str(resource)


def get_env_var(name: str, default: str = "") -> str:
    """Return the value of environment variable *name*.

    Args:
        name: Name of the environment variable to read.
        default: Value returned when the variable is not set. Defaults to
            an empty string.

    Returns:
        The environment variable value or *default*.
    """
    return os.environ.get(name, default)


functions = {
    "env_var": get_env_var,
    "get_env_var": get_env_var,
    "pkg_resource": pkg_resource,
}
