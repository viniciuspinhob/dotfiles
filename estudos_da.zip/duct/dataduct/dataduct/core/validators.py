"""Config validation for dataduct jobs.

Validates a fully-merged config dict **before** any engine or connector is
instantiated.  All errors are collected and raised together in a single
:class:`~dataduct.core.exceptions.ConfigError` so that operators can fix
every issue in one pass.

Usage::

    from dataduct.core.validators import validate_config
    validate_config(config)   # raises ConfigError on failure
"""

import logging
from typing import Any, Dict, List

from dataduct.core.exceptions import ConfigError

logger = logging.getLogger(__name__)

_VALID_ENGINES = {"spark", "duckdb"}
_VALID_SOURCE_FORMATS = {"csv", "parquet", "jdbc", "object_storage", "json", "delta"}
_VALID_SINK_FORMATS = {"csv", "parquet", "jdbc", "object_storage", "json", "delta"}
_VALID_MASKING_PROVIDERS = {"hash"}
_VALID_CATALOG_PROVIDERS = {"glue", "unity", "unity_rest"}
_VALID_CREDENTIAL_TYPES = {"env", "direct"}


def validate_config(config: Dict[str, Any]) -> None:
    """Validate *config* and raise a :class:`~dataduct.core.exceptions.ConfigError`
    that lists **all** validation issues at once.

    Checks performed:

    - Top-level type must be a dict.
    - At least one of ``sources`` or ``sinks`` must be present.
    - Each source must be a dict with ``name`` and ``format`` fields.
    - Each sink must be a dict with ``name`` and ``format`` fields.
    - ``engine`` (if present) must be one of :data:`_VALID_ENGINES`.
    - Masking config (if present on a source) is validated by
      :func:`_validate_masking`.
    - Catalog config (if present on a sink) is validated by
      :func:`_validate_catalog`.

    Args:
        config: The fully-merged job config dict.

    Raises:
        ConfigError: When one or more validation errors are found.
    """
    errors: List[str] = []

    if not isinstance(config, dict):
        raise ConfigError(f"Config must be a dict, got {type(config).__name__}")

    sources = config.get("sources")
    sinks = config.get("sinks")

    if sources is None and sinks is None:
        errors.append("Config must have at least one of 'sources' or 'sinks'")

    if sources is not None:
        if not isinstance(sources, list):
            errors.append(f"'sources' must be a list, got {type(sources).__name__}")
        else:
            for i, source in enumerate(sources):
                errors.extend(_validate_source(source, i))

    if sinks is not None:
        if not isinstance(sinks, list):
            errors.append(f"'sinks' must be a list, got {type(sinks).__name__}")
        else:
            for i, sink in enumerate(sinks):
                errors.extend(_validate_sink(sink, i))

    engine = config.get("engine")
    if engine and engine not in _VALID_ENGINES:
        errors.append(
            f"'engine' must be one of {sorted(_VALID_ENGINES)}, got {engine!r}"
        )

    if errors:
        formatted = "\n  - ".join(errors)
        raise ConfigError(f"Config validation failed:\n  - {formatted}")

    logger.debug("Config validation passed (%d sources, %d sinks)",
                 len(sources or []), len(sinks or []))


def _validate_source(source: Any, index: int) -> List[str]:
    """Validate a single source entry.

    Args:
        source: The source item (expected to be a dict).
        index: Zero-based position in the ``sources`` list, used for
            error messages.

    Returns:
        List of error strings (empty if the source is valid).
    """
    errors = []
    prefix = f"sources[{index}]"

    if not isinstance(source, dict):
        return [f"{prefix}: must be a dict, got {type(source).__name__}"]

    if not source.get("name"):
        errors.append(f"{prefix}: missing required field 'name'")

    fmt = source.get("format")
    if not fmt:
        errors.append(f"{prefix}: missing required field 'format'")

    masking = source.get("masking")
    if masking:
        errors.extend(_validate_masking(masking, prefix))

    return errors


def _validate_sink(sink: Any, index: int) -> List[str]:
    """Validate a single sink entry.

    Args:
        sink: The sink item (expected to be a dict).
        index: Zero-based position in the ``sinks`` list, used for
            error messages.

    Returns:
        List of error strings (empty if the sink is valid).
    """
    errors = []
    prefix = f"sinks[{index}]"

    if not isinstance(sink, dict):
        return [f"{prefix}: must be a dict, got {type(sink).__name__}"]

    if not sink.get("name"):
        errors.append(f"{prefix}: missing required field 'name'")

    fmt = sink.get("format")
    if not fmt:
        errors.append(f"{prefix}: missing required field 'format'")

    catalog = sink.get("catalog")
    if catalog:
        errors.extend(_validate_catalog(catalog, prefix))

    return errors


def _validate_masking(masking: Any, prefix: str) -> List[str]:
    """Validate a ``masking`` sub-config block.

    Args:
        masking: The masking config dict.
        prefix: Dot-path prefix used in error messages (e.g.
            ``"sources[0]"``).

    Returns:
        List of error strings.
    """
    errors = []
    if not isinstance(masking, dict):
        return [f"{prefix}.masking: must be a dict"]

    provider = masking.get("provider", "hash")
    if provider not in _VALID_MASKING_PROVIDERS:
        errors.append(
            f"{prefix}.masking.provider: must be one of {sorted(_VALID_MASKING_PROVIDERS)}, "
            f"got {provider!r}"
        )

    columns = masking.get("columns", [])
    if not isinstance(columns, list):
        errors.append(f"{prefix}.masking.columns: must be a list")
    else:
        for i, col in enumerate(columns):
            if not isinstance(col, dict) or not col.get("column"):
                errors.append(f"{prefix}.masking.columns[{i}]: must have a 'column' field")

    return errors


def _validate_catalog(catalog: Any, prefix: str) -> List[str]:
    """Validate a ``catalog`` sub-config block.

    Args:
        catalog: The catalog config dict.
        prefix: Dot-path prefix used in error messages (e.g.
            ``"sinks[1]"``).

    Returns:
        List of error strings.
    """
    errors = []
    if not isinstance(catalog, dict):
        return [f"{prefix}.catalog: must be a dict"]

    provider = catalog.get("provider")
    if not provider:
        errors.append(f"{prefix}.catalog: missing required field 'provider'")
    elif provider not in _VALID_CATALOG_PROVIDERS:
        errors.append(
            f"{prefix}.catalog.provider: must be one of {sorted(_VALID_CATALOG_PROVIDERS)}, "
            f"got {provider!r}"
        )

    if not catalog.get("database"):
        errors.append(f"{prefix}.catalog: missing required field 'database'")
    if not catalog.get("table_name"):
        errors.append(f"{prefix}.catalog: missing required field 'table_name'")

    return errors
