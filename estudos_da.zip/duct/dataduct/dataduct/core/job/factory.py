"""JobFactory — resolves a job package name to a runnable :class:`Job` instance.

Typical usage (via CLI)::

    config = JobFactory.build_config("sales.monthly_report", custom={"ano": "2025"}, env="dev")
    engine = load_engine(config.get("engine", "duckdb"), config.get("engine_config", {}))
    job = JobFactory.get(config, engine=engine)
    job.execute()
"""

import importlib
import inspect
from typing import Dict, Optional, Type

from dataduct.core.exceptions import JobNotFound
from dataduct.core.job.base import Job


class JobFactory:
    """Static factory that builds config dicts and instantiates Job subclasses."""

    @staticmethod
    def build_config(
        job_package_name: str,
        custom: Optional[Dict] = None,
        env: Optional[str] = None,
    ) -> Dict:
        """Build and validate the merged config dict for a job.

        Delegates to :func:`dataduct.core.config.build`.

        Args:
            job_package_name: Dotted package name of the job
                (e.g. ``"sales.monthly_report"``).
            custom: Dict of custom key/value overrides (from CLI
                ``--custom`` JSON).
            env: Optional environment suffix (e.g. ``"dev"``).

        Returns:
            Fully-merged, Jinja2-rendered, validated config dict.

        Raises:
            ConfigError: If config validation fails.
        """
        from dataduct.core.config import build
        return build(job_package_name, orchestration_config=custom, env=env)

    @staticmethod
    def get(config: Dict, engine=None, dry_run: bool = False) -> Job:
        """Import the job module and return an initialised :class:`Job` instance.

        The factory looks for a subclass of :class:`Job` inside the module
        ``{job_package_name}.job``.  The first subclass found (via
        :func:`inspect.getmembers`) is used.

        Args:
            config: Fully-merged config dict that must contain
                ``"job_package_name"``.
            engine: An already-started
                :class:`~dataduct.engines.base.EngineAdapter` instance.
            dry_run: Passed through to the :class:`Job` constructor.

        Returns:
            An initialised (but not yet executed) :class:`Job` instance.

        Raises:
            JobNotFound: If ``config`` is missing ``"job_package_name"``,
                the job module cannot be imported, or no :class:`Job`
                subclass is found in the module.
        """
        job_package_name = config.get("job_package_name")
        if not job_package_name:
            raise JobNotFound("Config missing 'job_package_name'")

        job_module_name = f"{job_package_name}.job"
        try:
            module = importlib.import_module(job_module_name)
        except ModuleNotFoundError:
            raise JobNotFound(f"Could not import job module: {job_module_name}")

        job_class = _find_job_class(module)
        if not job_class:
            raise JobNotFound(f"No Job subclass found in {job_module_name}")

        return job_class(config=config, engine=engine, dry_run=dry_run)


def _find_job_class(module) -> Optional[Type[Job]]:
    """Scan *module* for a concrete :class:`Job` subclass.

    Args:
        module: An imported Python module object.

    Returns:
        The first :class:`Job` subclass found, or ``None``.
    """
    for name, obj in inspect.getmembers(module, inspect.isclass):
        if issubclass(obj, Job) and obj is not Job:
            return obj
    return None
