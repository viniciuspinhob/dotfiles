"""Job base classes: :class:`Job` (ABC) and :class:`Steps` (hook registry).

A concrete job is created by subclassing :class:`Job` and implementing
:meth:`Job.run`.  Everything else — extracting sources, applying masking,
creating loaders, running before/after hooks, and triggering catalog
registration — is handled by :meth:`Job.execute`.

Minimal example::

    from dataduct.core.job.base import Job

    class MyJob(Job):
        def run(self):
            data = self.engine.execute_sql("SELECT * FROM my_source")
            self.sinks.output.save(data)

Lifecycle order inside :meth:`Job.execute`::

    register_sources()   ← extract + masking + register as temp view
    register_sinks()     ← create loaders + attach catalog config
    steps.run_before()   ← user-defined before-hooks
    job.run()            ← user business logic
    steps.run_after()    ← user-defined after-hooks
    ── finally ──
    loader.after_save()  ← catalog registration for every sink
"""

import logging
from abc import ABC, abstractmethod
from typing import Any, Callable, List, Optional

from dataduct.engines.base import EngineAdapter
from dataduct.utils.bunch import Bunch

logger = logging.getLogger(__name__)


class Steps:
    """Simple registry for before/after execution hooks.

    Hooks are callables that receive the :class:`Job` instance as their
    only argument.  They are executed in the order they were registered.

    Example::

        class MyJob(Job):
            def run(self):
                ...

        job = MyJob(config, engine)

        @job.steps.before
        def log_start(j):
            print("Starting", type(j).__name__)

        @job.steps.after
        def log_end(j):
            print("Done")

        job.execute()
    """

    def __init__(self):
        self._before_functions: List[Callable] = []
        self._after_functions: List[Callable] = []

    def before(self, func: Callable) -> Callable:
        """Register *func* as a before-hook.

        Args:
            func: A callable that accepts a single ``job`` argument.

        Returns:
            The original function (decorator-friendly).
        """
        self._before_functions.append(func)
        return func

    def after(self, func: Callable) -> Callable:
        """Register *func* as an after-hook.

        Args:
            func: A callable that accepts a single ``job`` argument.

        Returns:
            The original function (decorator-friendly).
        """
        self._after_functions.append(func)
        return func

    def run_before(self, job: Any) -> None:
        """Execute all registered before-hooks in registration order.

        Args:
            job: The :class:`Job` instance to pass to each hook.
        """
        for func in self._before_functions:
            logger.debug("Running before-hook: %s", func.__name__)
            func(job)

    def run_after(self, job: Any) -> None:
        """Execute all registered after-hooks in registration order.

        Args:
            job: The :class:`Job` instance to pass to each hook.
        """
        for func in self._after_functions:
            logger.debug("Running after-hook: %s", func.__name__)
            func(job)


class Job(ABC):
    """Abstract base class for all dataduct jobs.

    Subclasses must implement :meth:`run`.  All orchestration (source
    registration, sink wiring, hook execution, catalog post-processing) is
    handled by :meth:`execute`.

    Attributes:
        sources: :class:`~dataduct.utils.bunch.Bunch` of extracted datasets,
            keyed by source ``name``.  Populated before :meth:`run` is called.
        sinks: :class:`~dataduct.utils.bunch.Bunch` of
            :class:`~dataduct.connectors.base.BaseLoader` instances, keyed by
            sink ``name``.  Call ``self.sinks.my_sink.save(data)`` inside
            :meth:`run`.
        custom: :class:`~dataduct.utils.bunch.Bunch` wrapping the ``custom``
            section of the config dict. Access values as attributes:
            ``self.custom.ano``.
        config: The full raw config dict.
        engine: The active :class:`~dataduct.engines.base.EngineAdapter`, or
            ``None`` in dry-run mode.
        dry_run: ``True`` when the job was invoked with ``--dry-run``.
        steps: The :class:`Steps` instance for registering hooks.
    """

    def __init__(self, config: dict, engine: Optional[EngineAdapter] = None, dry_run: bool = False):
        """Initialise a Job instance.

        Args:
            config: Fully-merged and validated config dict produced by
                :class:`~dataduct.core.job.factory.JobFactory`.
            engine: Active compute engine.  ``None`` is allowed for dry-run
                or unit-test scenarios.
            dry_run: When ``True``, the job is initialised but
                :meth:`execute` exits before calling :meth:`run`.
        """
        self._config = config
        self._engine = engine
        self._dry_run = dry_run
        self._sources: Bunch = Bunch()
        self._sinks: Bunch = Bunch()
        self._custom: Bunch = Bunch(config.get("custom", {}))
        self._steps = Steps()

    @property
    def sources(self) -> Bunch:
        """Extracted source datasets, keyed by name."""
        return self._sources

    @property
    def sinks(self) -> Bunch:
        """Loader instances for each configured sink, keyed by name."""
        return self._sinks

    @property
    def custom(self) -> Bunch:
        """Custom key/value pairs from the config ``custom`` section."""
        return self._custom

    @property
    def config(self) -> dict:
        """The full raw config dict as built by :func:`~dataduct.core.config.build`."""
        return self._config

    @property
    def engine(self) -> Optional[EngineAdapter]:
        """The active compute engine adapter, or ``None``."""
        return self._engine

    @property
    def dry_run(self) -> bool:
        """Whether this job is running in dry-run (validation-only) mode."""
        return self._dry_run

    @property
    def steps(self) -> Steps:
        """Hook registry for before/after callbacks."""
        return self._steps

    def register_sources(self, sources_config: List[dict]) -> None:
        """Extract data for each source and register it as a temp view.

        For each entry in *sources_config*:

        1. Pop the ``name`` field (used as the view and attribute key).
        2. Create an extractor via
           :class:`~dataduct.connectors.ExtractorFactory`.
        3. Call :meth:`~dataduct.connectors.base.BaseExtractor.extract`.
        4. Apply masking if a ``masking`` block is present.
        5. Store the result in :attr:`sources` and register it as a
           temp view in the engine.

        Args:
            sources_config: List of source config dicts from the job config.

        Raises:
            ValueError: If a source is missing the ``name`` field.
        """
        from dataduct.connectors import ExtractorFactory
        for source_cfg in sources_config:
            cfg = dict(source_cfg)
            name = cfg.pop("name", None)
            if not name:
                raise ValueError(
                    f"Source config is missing required 'name' field: {source_cfg}"
                )
            masking_config = cfg.pop("masking", None)
            logger.debug("Registering source '%s' (format=%s)", name, cfg.get("format"))
            extractor = ExtractorFactory.get(cfg, engine=self._engine)
            data = extractor.extract()
            if masking_config:
                from dataduct.services.masking import apply_masking
                logger.debug("Applying masking on source '%s'", name)
                data = apply_masking(data, masking_config, engine=self._engine)
            self._sources[name] = data
            self._register_as_view(name, data)

    def register_sinks(self, sinks_config: List[dict]) -> None:
        """Create loader instances for each sink and attach catalog config.

        For each entry in *sinks_config*:

        1. Pop the ``name`` and (optional) ``catalog`` fields.
        2. Create a loader via
           :class:`~dataduct.connectors.LoaderFactory`.
        3. Attach catalog config via
           :meth:`~dataduct.connectors.base.BaseLoader.set_catalog`.
        4. Store the loader in :attr:`sinks`.

        Args:
            sinks_config: List of sink config dicts from the job config.

        Raises:
            ValueError: If a sink is missing the ``name`` field.
        """
        from dataduct.connectors import LoaderFactory
        for sink_cfg in sinks_config:
            cfg = dict(sink_cfg)
            name = cfg.pop("name", None)
            if not name:
                raise ValueError(
                    f"Sink config is missing required 'name' field: {sink_cfg}"
                )
            catalog_config = cfg.pop("catalog", None)
            logger.debug("Registering sink '%s' (format=%s)", name, cfg.get("format"))
            loader = LoaderFactory.get(cfg, engine=self._engine)
            if catalog_config:
                loader.set_catalog(catalog_config, engine=self._engine)
            self._sinks[name] = loader

    def execute(self) -> None:
        """Run the complete job lifecycle.

        Execution order::

            register_sources()
            register_sinks()
            steps.run_before(self)
            self.run()
            steps.run_after(self)
            ── finally (always runs) ──
            loader.after_save()   for each sink

        Any exception raised inside :meth:`run` propagates after being
        logged.  ``after_save`` is called in the ``finally`` block so
        catalog registration happens even on partial failures.

        Raises:
            Exception: Re-raises any exception from :meth:`run`.
        """
        job_name = type(self).__name__
        logger.info("Starting job: %s (dry_run=%s)", job_name, self._dry_run)
        try:
            self.register_sources(self._config.get("sources", []))
            self.register_sinks(self._config.get("sinks", []))
            self._steps.run_before(self)
            self.run()
            self._steps.run_after(self)
        except Exception:
            logger.exception("Job '%s' failed during execution", job_name)
            raise
        finally:
            logger.debug("Running after_save hooks for all sinks")
            for name, loader in self._sinks.items():
                if hasattr(loader, "after_save"):
                    try:
                        loader.after_save()
                    except Exception:
                        logger.exception("after_save failed for sink '%s'", name)
        logger.info("Job '%s' completed successfully", job_name)

    @abstractmethod
    def run(self) -> None:
        """User-defined business logic.

        Implement this method in your job subclass.  By the time this is
        called, all sources have been extracted (and optionally masked)
        and are available via :attr:`sources`.  Sink loaders are available
        via :attr:`sinks`.

        Example::

            def run(self):
                result = self.engine.execute_sql(
                    "SELECT * FROM orders WHERE status = 'PAID'"
                )
                self.sinks.output.save(result)
        """
        raise NotImplementedError

    def _register_as_view(self, name: str, data: Any) -> None:
        """Register *data* as a temporary view/table in the engine.

        - For Spark DataFrames: calls ``createOrReplaceTempView``.
        - For DuckDB relations: calls ``engine.session.register``.
        - When there is no engine: no-op.

        Args:
            name: View name (must be a valid SQL identifier).
            data: The dataset to register.
        """
        if self._engine is None:
            return
        if hasattr(data, "createOrReplaceTempView"):
            data.createOrReplaceTempView(name)
        elif hasattr(self._engine, "session") and hasattr(self._engine.session, "register"):
            self._engine.session.register(name, data)
