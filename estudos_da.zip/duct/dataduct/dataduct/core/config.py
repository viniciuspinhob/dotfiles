"""Hierarchical YAML configuration builder with Jinja2 templating.

Config resolution order (highest priority wins)::

    CLI --custom  >  config-{env}.yaml  >  config.yaml  >  parent config  >  defaults

Given a job package ``"sales.monthly_report"``, the framework walks the
package tree ``["sales.monthly_report", "sales"]`` from root to leaf,
merging every ``config.yaml`` (and optional ``config-{env}.yaml``) it
finds. Jinja2 templates inside ``sources``, ``sinks``, and
``engine_config`` sections are then rendered using the merged ``custom``
dict.

Public API
----------
- :func:`build` — entry point used by :class:`~dataduct.core.job.factory.JobFactory`.
- :func:`deep_merge_dict` — recursive dict merge (child wins).
"""

import ast
import logging
from datetime import datetime, timezone
from importlib.resources import files
from typing import Any, Dict, List, Optional

import yaml
from jinja2 import Template

from dataduct.core.jinja_functions import functions

logger = logging.getLogger(__name__)

CONFIG_FILE_NAME: str = "config.yaml"
DEFAULT_CONFIG: Dict = {}


def build(
    job_package_name: str,
    orchestration_config: Optional[Dict] = None,
    env: Optional[str] = None,
) -> Dict:
    """Build the fully-merged and validated config dict for a job.

    Steps performed:

    1. Walk the package tree and merge all ``config.yaml`` /
       ``config-{env}.yaml`` files (root → leaf).
    2. Deep-merge the *orchestration_config* (CLI ``--custom`` args) on top.
    3. Render Jinja2 templates in ``sources``, ``sinks``, and
       ``engine_config`` using the final ``custom`` dict.
    4. Inject ``job_package_name`` and ``dt_execution`` defaults.
    5. Validate the result via :func:`~dataduct.core.validators.validate_config`.

    Args:
        job_package_name: Dotted Python package name of the job
            (e.g. ``"sales.monthly_report"``).
        orchestration_config: Key/value pairs that override the ``custom``
            section of the YAML config.  Passed as ``--custom`` JSON from
            the CLI.
        env: Environment suffix used to load ``config-{env}.yaml`` overlays
            (e.g. ``"dev"``, ``"prod"``).

    Returns:
        The final config dict, validated and ready for use.

    Raises:
        ConfigError: If validation fails.
    """
    if orchestration_config is None:
        orchestration_config = {}

    logger.debug("Building config for job '%s' (env=%s)", job_package_name, env)
    config = _parse_config_tree(job_package_name, env)
    orchestration_config = {"custom": orchestration_config}
    partial_config = deep_merge_dict(config, orchestration_config)
    final_config = _apply_args_to_configs(partial_config)
    final_config.setdefault("job_package_name", job_package_name)
    final_config.setdefault("dt_execution", datetime.now(timezone.utc).isoformat(timespec="minutes"))

    from dataduct.core.validators import validate_config
    validate_config(final_config)

    logger.debug("Final config assembled: %s", final_config)
    return final_config


def _resource_exists(package: str, resource_name: str) -> bool:
    """Return True if *resource_name* exists inside the *package*.

    Uses :mod:`importlib.resources` so it works both from the filesystem
    and from inside installed wheels.

    Args:
        package: Dotted package name (e.g. ``"sales.monthly_report"``).
        resource_name: File name relative to the package root.

    Returns:
        ``True`` if the resource file exists and is readable.
    """
    try:
        package_files = files(package)
        resource = package_files.joinpath(resource_name)
        if resource.is_file():
            try:
                resource.read_bytes()
                return True
            except (KeyError, FileNotFoundError):
                return False
        return False
    except (TypeError, AttributeError, FileNotFoundError, NotADirectoryError, ModuleNotFoundError):
        return False


def _read_resource(package: str, resource_name: str) -> bytes:
    """Read and return the raw bytes of a package resource file.

    Args:
        package: Dotted package name.
        resource_name: File name relative to the package root.

    Returns:
        Raw bytes of the resource file.
    """
    package_files = files(package)
    resource = package_files.joinpath(resource_name)
    return resource.read_bytes()


def _parse_config_tree(job_package_name: str, env: Optional[str]) -> Dict:
    """Walk the package tree from root to leaf, merging config files.

    For ``"a.b.c"`` the walk order is ``["a", "a.b", "a.b.c"]``.
    Within each package both ``config.yaml`` and (if *env* is set)
    ``config-{env}.yaml`` are loaded and merged, with the env overlay
    taking priority.

    Args:
        job_package_name: Dotted job package name.
        env: Optional environment suffix (e.g. ``"dev"``).

    Returns:
        Merged config dict from the full package hierarchy.
    """
    config = dict(DEFAULT_CONFIG)
    tree = _build_package_tree(job_package_name)
    config_files = [CONFIG_FILE_NAME] + ([f"config-{env}.yaml"] if env else [])

    for package in reversed(tree):
        new_config: Dict = {}
        has_config = False
        for config_file in config_files:
            if _resource_exists(package, config_file):
                child_config = _parse_config(package, config_file)
                if child_config:
                    has_config = True
                    new_config = deep_merge_dict(new_config, child_config)
                    logger.debug("Loaded config from '%s/%s'", package, config_file)
        if has_config:
            config = deep_merge_dict(config, new_config)

    return config


def _build_package_tree(package: str) -> List[str]:
    """Decompose *package* into an ordered list from leaf to root.

    Example::

        _build_package_tree("a.b.c")
        # → ["a.b.c", "a.b", "a"]

    Args:
        package: Dotted package name string.

    Returns:
        List of ancestor packages ordered from most-specific (leaf) to
        least-specific (root).

    Raises:
        ValueError: If *package* is empty or not a string.
    """
    if not package or not isinstance(package, str):
        raise ValueError(f"Invalid package name: {package!r}")
    tree = []
    current = package.strip(".")
    while current:
        tree.append(current)
        parts = current.rsplit(".", maxsplit=1)
        current = parts[0] if len(parts) > 1 else ""
    return tree


def _parse_config(job_package_name: str, config_file_name: str = CONFIG_FILE_NAME) -> Dict:
    """Read and YAML-parse a single config resource file.

    Args:
        job_package_name: Dotted package name that contains the file.
        config_file_name: Name of the YAML file (default: ``"config.yaml"``).

    Returns:
        Parsed dict, or an empty dict if the file is empty.
    """
    raw = _read_resource(job_package_name, config_file_name)
    return yaml.safe_load(raw) or {}


def deep_merge_dict(parent: Dict, child: Dict) -> Dict:
    """Recursively merge *child* into *parent* (child values win).

    Rules:

    - Scalar and non-dict values: child wins.
    - Both dicts: recurse.
    - Both lists: delegate to :func:`_merge_list_elements`.
    - Key only in parent: keep parent value.

    Args:
        parent: The base dict (lower priority).
        child: The override dict (higher priority).

    Returns:
        New merged dict; neither *parent* nor *child* is mutated.
    """
    if not isinstance(parent, dict) or not isinstance(child, dict):
        return child if child is not None else parent
    result = dict(child)
    for key, value in parent.items():
        if key not in result:
            result[key] = value
        elif isinstance(value, dict) and isinstance(result[key], dict):
            result[key] = deep_merge_dict(value, result[key])
        elif isinstance(value, list) and isinstance(result.get(key), list):
            result[key] = _merge_list_elements(value, result[key])
    return result


def _merge_list_elements(parent_list: List, child_list: List) -> List:
    """Merge two lists of dicts by matching on the ``"name"`` key.

    Items present in *child_list* override the corresponding item in
    *parent_list* (matched by ``item["name"]``).  Items that only exist
    in *parent_list* are preserved; new items in *child_list* are appended.

    For lists that do not contain dicts (e.g. plain string lists), the
    *child_list* takes priority and *parent_list* is discarded.

    Args:
        parent_list: Base list (lower priority).
        child_list: Override list (higher priority).

    Returns:
        New merged list.
    """
    if not parent_list or not child_list:
        return child_list or parent_list

    if all(isinstance(e, dict) for e in parent_list + child_list):
        child_by_name: Dict[Any, Dict] = {}
        for item in child_list:
            name = item.get("name")
            if name is not None:
                child_by_name[name] = item

        result = []
        seen_names = set()
        for item in parent_list:
            name = item.get("name")
            if name is not None and name in child_by_name:
                merged = {**item, **child_by_name[name]}
                result.append(merged)
            else:
                result.append(item)
            if name is not None:
                seen_names.add(name)

        for item in child_list:
            name = item.get("name")
            if name is not None and name not in seen_names:
                result.append(item)

        return result

    return child_list


def _apply_args_to_configs(config: Dict) -> Dict:
    """Render Jinja2 templates in ``sources``, ``sinks``, and ``engine_config``.

    Only the sections that commonly contain dynamic paths/values are
    rendered.  The ``custom`` dict is used as the template context.

    Args:
        config: Fully-merged raw config dict.

    Returns:
        The same dict with Jinja2 templates resolved in-place.
    """
    custom = config.get("custom", {})
    if not custom:
        return config

    for key in ("sources", "sinks", "engine_config"):
        if key in config:
            config[key] = _render_jinja(config[key], custom)

    return config


def _render_jinja(obj: Any, args: Dict) -> Any:
    """Render a Jinja2 template string (or object coerced to string) safely.

    The rendered string is parsed back via :func:`ast.literal_eval` first
    (handles Python literals like numbers, booleans, lists), then via
    :func:`yaml.safe_load` (handles YAML structures).  If both fail, the
    raw rendered string is returned.

    No ``eval()`` is used anywhere in this pipeline.

    Args:
        obj: The object to render.  Non-string objects are coerced via
            ``str()`` before being treated as a template.
        args: Variables available inside the Jinja2 template.

    Returns:
        The rendered and re-parsed Python object.
    """
    template = Template(str(obj))
    template.globals.update(functions)
    rendered = template.render(**args)

    try:
        return ast.literal_eval(rendered)
    except (ValueError, SyntaxError):
        pass

    try:
        return yaml.safe_load(rendered)
    except yaml.YAMLError:
        pass

    return rendered
