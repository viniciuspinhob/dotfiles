"""Global plugin registry for engines and connectors.

Engines and connectors register themselves with decorators so that the
rest of the framework can resolve them by name without importing the
optional dependencies up front.

Example — registering a custom engine::

    from dataduct.core.registry import register_engine
    from dataduct.engines.base import EngineAdapter

    @register_engine("polars")
    class PolarsEngineAdapter(EngineAdapter):
        ...

Example — registering a custom connector::

    from dataduct.core.registry import register_connector
    from dataduct.connectors.base import BaseExtractor

    @register_connector("delta", "extractor")
    class DeltaExtractor(BaseExtractor):
        ...
"""

from typing import Any, Dict, Type

_connector_registry: Dict[str, Dict[str, Type]] = {
    "extractor": {},
    "loader": {},
}

_engine_registry: Dict[str, Type] = {}


def register_connector(format_name: str, kind: str):
    """Class decorator that registers a connector in the global registry.

    Args:
        format_name: The format key (e.g. ``"csv"``, ``"parquet"``, ``"jdbc"``).
        kind: Either ``"extractor"`` or ``"loader"``.

    Returns:
        The original class, unchanged.

    Example::

        @register_connector("csv", "extractor")
        class CsvExtractor(BaseExtractor):
            ...
    """
    def decorator(cls):
        _connector_registry[kind][format_name] = cls
        return cls
    return decorator


def get_connector(format_name: str, kind: str) -> Type:
    """Retrieve a connector class from the registry.

    Args:
        format_name: The format key (e.g. ``"csv"``).
        kind: Either ``"extractor"`` or ``"loader"``.

    Returns:
        The registered connector class.

    Raises:
        ConnectorNotFound: When no connector is registered for the given
            *format_name* / *kind* combination.
    """
    from dataduct.core.exceptions import ConnectorNotFound

    registry = _connector_registry.get(kind, {})
    if format_name not in registry:
        available = list(registry.keys())
        raise ConnectorNotFound(
            f"Connector '{format_name}' ({kind}) not found. Available: {available}"
        )
    return registry[format_name]


def register_engine(name: str):
    """Class decorator that registers a compute engine in the global registry.

    Args:
        name: The engine key (e.g. ``"spark"``, ``"duckdb"``).

    Returns:
        The original class, unchanged.

    Example::

        @register_engine("spark")
        class SparkEngineAdapter(EngineAdapter):
            ...
    """
    def decorator(cls):
        _engine_registry[name] = cls
        return cls
    return decorator


def get_engine(name: str) -> Type:
    """Retrieve an engine class from the registry.

    Args:
        name: The engine key (e.g. ``"spark"``).

    Returns:
        The registered engine class.

    Raises:
        EngineNotFound: When no engine is registered under *name*.
    """
    from dataduct.core.exceptions import EngineNotFound

    if name not in _engine_registry:
        available = list(_engine_registry.keys())
        raise EngineNotFound(
            f"Engine '{name}' not found. Available: {available}"
        )
    return _engine_registry[name]


def list_connectors(kind: str = None) -> Dict[str, Any]:
    """Return a snapshot of the connector registry.

    Args:
        kind: If provided, return only connectors of that kind
            (``"extractor"`` or ``"loader"``).  If *None*, return the full
            two-level mapping.

    Returns:
        A dict mapping format names to connector classes (when *kind* is
        given) or a dict of ``{kind: {format: class}}`` otherwise.
    """
    if kind:
        return dict(_connector_registry.get(kind, {}))
    return {k: dict(v) for k, v in _connector_registry.items()}


def list_engines() -> Dict[str, Type]:
    """Return a snapshot of the engine registry.

    Returns:
        A dict mapping engine names to engine adapter classes.
    """
    return dict(_engine_registry)
