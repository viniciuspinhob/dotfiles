from dataduct.integrations.airflow.operator import DataductOperator

__all__ = ["DataductOperator"]
