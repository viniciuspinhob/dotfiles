from __future__ import annotations

import logging
from typing import Any, Dict, Optional, Sequence

from airflow.models import BaseOperator
from airflow.utils.context import Context

logger = logging.getLogger(__name__)


class DataductOperator(BaseOperator):
    """Airflow operator that executes a dataduct job.

    Uses the dataduct programmatic API (JobFactory + Engine) to build
    config, instantiate the engine, and run the job within the Airflow
    task lifecycle.

    Supports Airflow template rendering on job_package_name, env, custom,
    and engine fields — so you can use macros like ``{{ ds }}`` in custom
    parameters.

    Example::

        DataductOperator(
            task_id="landing_to_raw",
            job_package_name="examples.orders_marketplace.jdbc_to_raw",
            engine="spark",
            env="dev",
            custom={"dt_referencia": "{{ ds }}"},
        )
    """

    template_fields: Sequence[str] = ("job_package_name", "env", "custom", "engine")

    def __init__(
        self,
        *,
        job_package_name: str,
        engine: Optional[str] = None,
        env: Optional[str] = None,
        custom: Optional[Dict[str, Any]] = None,
        engine_config: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.job_package_name = job_package_name
        self.engine = engine
        self.env = env
        self.custom = custom or {}
        self.engine_config = engine_config or {}

    def execute(self, context: Context) -> None:
        from dataduct.core.job.factory import JobFactory
        from dataduct.engines import load_engine

        logger.info(
            "DataductOperator: job=%s engine=%s env=%s custom=%s",
            self.job_package_name,
            self.engine,
            self.env,
            self.custom,
        )

        config = JobFactory.build_config(
            job_package_name=self.job_package_name,
            custom=self.custom,
            env=self.env,
        )

        engine_name = self.engine or config.get("engine", "spark")
        engine_cfg = self.engine_config or config.get("engine_config", {})

        engine_instance = load_engine(engine_name, engine_cfg)
        try:
            job = JobFactory.get(config, engine=engine_instance)
            job.execute()
            logger.info("DataductOperator: job %s completed.", self.job_package_name)
        finally:
            engine_instance.stop_session()
