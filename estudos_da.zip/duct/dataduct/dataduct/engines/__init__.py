"""Engine loading with lazy registration.

Engines are registered via ``@register_engine`` decorators inside their
own modules.  This module imports those modules on first use so that the
optional dependencies (pyspark, duckdb) are never imported unless an
engine is actually requested.

Public API
----------
- :func:`load_engine` — create and start an engine by name.
- :func:`register_engine` — decorator (re-exported from registry).
- :func:`get_engine` — retrieve an engine class from the registry.
"""

import logging

from dataduct.core.registry import get_engine, list_engines, register_engine
from dataduct.engines.base import EngineAdapter

logger = logging.getLogger(__name__)

__all__ = ["EngineAdapter", "register_engine", "get_engine", "load_engine"]

_engines_registered = False


def load_engine(name: str, config: dict = None) -> EngineAdapter:
    """Instantiate and start a registered engine.

    Triggers lazy registration of all built-in engines (Spark, DuckDB)
    on first call, then looks up *name* in the registry, creates an
    instance, and calls :meth:`~dataduct.engines.base.EngineAdapter.create_session`.

    Args:
        name: Engine identifier (e.g. ``"spark"``, ``"duckdb"``).
        config: Engine-specific config dict forwarded to
            :meth:`~dataduct.engines.base.EngineAdapter.create_session`.
            Pass ``None`` or ``{}`` for defaults.

    Returns:
        A started :class:`~dataduct.engines.base.EngineAdapter` instance.

    Raises:
        ValueError: When the engine name is not registered (usually means
            the optional extra is not installed).
        ImportError: When the engine's underlying library is missing.
    """
    _ensure_engines_registered()
    try:
        engine_cls = get_engine(name)
    except Exception:
        available = list(list_engines().keys())
        raise ValueError(
            f"Engine {name!r} not found. Available: {available}. "
            f"Make sure the engine's extra is installed (e.g. pip install dataduct[{name}])"
        )
    logger.debug("Loading engine '%s'", name)
    engine = engine_cls()
    engine.create_session(config or {})
    return engine


def _ensure_engines_registered() -> None:
    """Import built-in engine modules exactly once per process.

    Uses a module-level boolean guard so repeated calls are a no-op.
    Missing optional dependencies are silently skipped.
    """
    global _engines_registered
    if _engines_registered:
        return
    try:
        import dataduct.engines.spark  # noqa: F401
        logger.debug("Spark engine registered")
    except ImportError:
        logger.debug("Spark engine not available (pyspark not installed)")
    try:
        import dataduct.engines.duckdb  # noqa: F401
        logger.debug("DuckDB engine registered")
    except ImportError:
        logger.debug("DuckDB engine not available (duckdb not installed)")
    _engines_registered = True
