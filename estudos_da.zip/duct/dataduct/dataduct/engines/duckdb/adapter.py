"""DuckDB engine adapter for dataduct.

Wraps a DuckDB in-memory or file-backed connection and exposes the
:class:`~dataduct.engines.base.EngineAdapter` interface.  DuckDB and
PyArrow are optional dependencies; the adapter raises a helpful
:class:`ImportError` if they are missing.

Installation::

    pip install dataduct[duckdb]
    # or: pip install duckdb pyarrow

Config keys (all optional)
---------------------------
- ``database`` (str): Path to a DuckDB file, or ``":memory:"`` (default).
- ``extensions`` (list[str]): DuckDB extensions to install and load
  (e.g. ``["httpfs", "parquet"]``).
- ``settings`` (dict): DuckDB ``SET`` statements.  Only keys present in
  :data:`_ALLOWED_SETTINGS` are accepted to prevent injection.

Security
--------
- Path traversal (``..``) is blocked in :func:`_validate_path`.
- SQL identifiers are single-quote-escaped in :func:`_sanitize_identifier`.
- DuckDB settings keys are restricted to :data:`_ALLOWED_SETTINGS`.
"""

import logging
import os
from typing import Any, Dict, Optional

from dataduct.core.registry import register_engine
from dataduct.engines.base import EngineAdapter

logger = logging.getLogger(__name__)

_ALLOWED_SETTINGS = {
    "threads", "memory_limit", "temp_directory", "max_memory",
    "worker_threads", "enable_progress_bar",
}

_ALLOWED_FORMATS = {"csv", "parquet", "json"}


def _sanitize_identifier(value: str) -> str:
    """Escape single quotes in *value* to prevent SQL injection.

    Args:
        value: Raw string value to sanitize.

    Returns:
        String with single quotes doubled (``'`` → ``''``).
    """
    safe = value.replace("'", "''")
    return safe


def _validate_path(path: str) -> str:
    """Validate that *path* does not contain path-traversal sequences.

    Args:
        path: File system path to validate.

    Returns:
        The original *path* if it is safe.

    Raises:
        ValueError: If *path* is empty or contains ``..`` components.
    """
    if not path:
        raise ValueError("Path cannot be empty")
    normalized = os.path.normpath(path)
    if ".." in normalized.split(os.sep):
        raise ValueError(f"Path traversal not allowed: {path!r}")
    return path


def _validate_setting_key(key: str) -> str:
    """Ensure *key* is in the DuckDB settings allowlist.

    Args:
        key: DuckDB setting name to validate.

    Returns:
        The original *key* if allowed.

    Raises:
        ValueError: If *key* is not in :data:`_ALLOWED_SETTINGS`.
    """
    if key not in _ALLOWED_SETTINGS:
        raise ValueError(
            f"DuckDB setting {key!r} is not in the allowed list. "
            f"Allowed: {sorted(_ALLOWED_SETTINGS)}"
        )
    return key


@register_engine("duckdb")
class DuckDBEngineAdapter(EngineAdapter):
    """Compute engine backed by DuckDB (in-memory or file-backed).

    The adapter is registered under the key ``"duckdb"`` so it can be
    selected via ``engine: duckdb`` in config.yaml or ``--engine duckdb``
    on the CLI.
    """

    def __init__(self):
        self._session = None

    def create_session(self, config: Optional[Dict] = None) -> Any:
        """Open a DuckDB connection, load extensions, and apply settings.

        Args:
            config: Engine config dict.  Recognised keys:
                ``database``, ``extensions``, ``settings``.

        Returns:
            The active DuckDB :class:`duckdb.DuckDBPyConnection`.

        Raises:
            ImportError: If DuckDB is not installed.
            ValueError: If a settings key is not in :data:`_ALLOWED_SETTINGS`.
        """
        try:
            import duckdb
        except ImportError:
            raise ImportError(
                "DuckDB is not installed. Install it with: pip install dataduct[duckdb] "
                "or: pip install duckdb pyarrow"
            )

        config = config or {}
        database = config.get("database", ":memory:")
        logger.debug("Creating DuckDB session (database=%s)", database)
        self._session = duckdb.connect(database=database)

        extensions = config.get("extensions", [])
        for ext in extensions:
            logger.debug("Loading DuckDB extension: %s", ext)
            self._session.install_extension(ext)
            self._session.load_extension(ext)

        settings = config.get("settings", {})
        for key, value in settings.items():
            safe_key = _validate_setting_key(key)
            safe_value = _sanitize_identifier(str(value))
            self._session.execute(f"SET {safe_key} = '{safe_value}'")

        return self._session

    def stop_session(self):
        """Close the DuckDB connection."""
        if self._session:
            logger.debug("Closing DuckDB session")
            self._session.close()
            self._session = None

    @property
    def session(self) -> Any:
        """The active DuckDB connection, or ``None``."""
        return self._session

    def read(self, format: str, **options) -> Any:
        """Read data from a file path into a DuckDB relation.

        Supported formats: ``csv``, ``parquet``, ``json``.  Unknown formats
        fall back to a generic ``SELECT * FROM '{path}'`` query.

        Args:
            format: Data format string.
            **options: Reader options.  Always required: ``path``.
                Format-specific:

                - CSV: ``header`` (bool, default ``True``),
                  ``delimiter`` (str, default ``","``).
                - Parquet / JSON: no additional options.

        Returns:
            A DuckDB :class:`duckdb.DuckDBPyRelation`.

        Raises:
            ValueError: If ``path`` is missing or contains traversal
                sequences.
        """
        path = options.get("path")
        if not path:
            raise ValueError(f"Cannot read format '{format}' without path")

        safe_path = _sanitize_identifier(_validate_path(str(path)))
        logger.debug("DuckDB read: format=%s path=%s", format, safe_path)

        if format == "csv":
            header = options.get("header", True)
            delimiter = options.get("delimiter", ",")
            safe_delim = _sanitize_identifier(str(delimiter))
            header_val = "true" if str(header).lower() in ("true", "1") else "false"
            return self._session.sql(
                f"SELECT * FROM read_csv('{safe_path}', header={header_val}, delim='{safe_delim}')"
            )
        elif format == "parquet":
            return self._session.sql(f"SELECT * FROM read_parquet('{safe_path}')")
        elif format == "json":
            return self._session.sql(f"SELECT * FROM read_json('{safe_path}')")
        else:
            return self._session.sql(f"SELECT * FROM '{safe_path}'")

    def write(self, data: Any, format: str, **options) -> None:
        """Write *data* to a file using DuckDB's ``COPY`` statement.

        Supported write formats: ``csv``, ``parquet``, ``json``.

        Args:
            data: A DuckDB relation or any object that can be registered
                as a DuckDB view.
            format: Target format.
            **options: Writer options:

                - ``path`` (str, required): Output file or directory path.
                - ``mode`` (str): ``"overwrite"`` (default) or
                  ``"append"``.  Append for Parquet is implemented by
                  merging existing and new data.
                - ``partition_by`` (str | list[str]): Partition columns.

        Raises:
            ValueError: If ``path`` is missing, contains traversal
                sequences, or if the format is unsupported.
        """
        path = options.get("path")
        if not path:
            raise ValueError("Cannot write without a path")

        safe_path = _sanitize_identifier(_validate_path(str(path)))
        mode = options.get("mode", "overwrite")
        partition_by = options.get("partition_by")

        format_map = {"csv": "CSV", "parquet": "PARQUET", "json": "JSON"}
        fmt = format_map.get(format)
        if not fmt:
            raise ValueError(
                f"Unsupported write format: {format!r}. Supported: {list(format_map)}"
            )

        logger.debug("DuckDB write: format=%s path=%s mode=%s", format, safe_path, mode)

        if mode == "append" and format == "parquet" and os.path.exists(safe_path):
            self._write_append_parquet(data, safe_path)
            return

        extra = ", HEADER" if format == "csv" else ""

        if partition_by:
            if isinstance(partition_by, str):
                partition_by = [partition_by]
            cols = ", ".join(f'"{c}"' for c in partition_by)
            extra_clause = f"{extra}, PARTITION_BY ({cols}), OVERWRITE_OR_IGNORE true"
            self._session.register("__write_temp", data)
            try:
                self._session.execute(
                    f"COPY (SELECT * FROM __write_temp) TO '{safe_path}' "
                    f"(FORMAT {fmt}{extra_clause})"
                )
            finally:
                self._session.unregister("__write_temp")
        else:
            self._session.register("__write_temp", data)
            try:
                self._session.execute(
                    f"COPY (SELECT * FROM __write_temp) TO '{safe_path}' (FORMAT {fmt}{extra})"
                )
            finally:
                self._session.unregister("__write_temp")

    def execute_sql(self, query: str) -> Any:
        """Execute *query* and return a DuckDB relation.

        Args:
            query: SQL string.  Temporary tables/views registered via
                :meth:`~dataduct.core.job.base.Job._register_as_view` are
                accessible by name.

        Returns:
            A :class:`duckdb.DuckDBPyRelation`.
        """
        logger.debug("DuckDB execute_sql: %s", query[:200])
        return self._session.sql(query)

    def _write_append_parquet(self, data: Any, path: str) -> None:
        """Append *data* to an existing Parquet file at *path*.

        Writes *data* to a temp file, then re-writes the combined result
        (existing + new) back to *path* using ``read_parquet(list)``.

        Args:
            data: New data to append.
            path: Path to the existing Parquet file.
        """
        import tempfile
        tmp_dir = tempfile.mkdtemp()
        tmp_path = os.path.join(tmp_dir, "new_data.parquet")
        self._session.register("__append_temp", data)
        try:
            self._session.execute(
                f"COPY (SELECT * FROM __append_temp) TO '{tmp_path}' (FORMAT PARQUET)"
            )
        finally:
            self._session.unregister("__append_temp")
        self._session.execute(
            f"COPY (SELECT * FROM read_parquet(['{path}', '{tmp_path}'])) "
            f"TO '{path}' (FORMAT PARQUET)"
        )
