from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter  # noqa: F401
