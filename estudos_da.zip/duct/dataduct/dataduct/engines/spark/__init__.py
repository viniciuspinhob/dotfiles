from dataduct.engines.spark.adapter import SparkEngineAdapter  # noqa: F401
