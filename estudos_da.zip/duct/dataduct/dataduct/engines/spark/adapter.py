"""PySpark engine adapter for dataduct.

Wraps a :class:`pyspark.sql.SparkSession` and exposes the
:class:`~dataduct.engines.base.EngineAdapter` interface.  PySpark is an
optional dependency; the adapter raises a helpful :class:`ImportError` if
the library is not installed.

Installation::

    pip install dataduct[spark]
    # or: pip install pyspark

Config keys (all optional)
---------------------------
- ``app_name`` (str): SparkSession application name. Default: ``"dataduct"``.
- ``master`` (str): Spark master URL (e.g. ``"local[*]"``).
- ``conf`` (dict): Arbitrary Spark config key/value pairs.
- ``packages`` (list[str]): Maven packages for
  ``spark.jars.packages``.
- ``jars`` (list[str]): Local JAR paths for ``spark.jars``.
"""

import logging
from typing import Any, Dict, Optional

from dataduct.core.registry import register_engine
from dataduct.engines.base import EngineAdapter

logger = logging.getLogger(__name__)


@register_engine("spark")
class SparkEngineAdapter(EngineAdapter):
    """Compute engine backed by Apache Spark (PySpark 3.5.x).

    The adapter is registered under the key ``"spark"`` so it can be
    selected via ``engine: spark`` in config.yaml or ``--engine spark``
    on the CLI.
    """

    def __init__(self):
        self._session = None

    def create_session(self, config: Optional[Dict] = None) -> Any:
        """Build and return a :class:`pyspark.sql.SparkSession`.

        Args:
            config: Engine config dict.  Recognised keys:
                ``app_name``, ``master``, ``conf``, ``packages``,
                ``jars``.

        Returns:
            The active :class:`pyspark.sql.SparkSession`.

        Raises:
            ImportError: If PySpark is not installed.
        """
        try:
            from pyspark.sql import SparkSession
        except ImportError:
            raise ImportError(
                "PySpark is not installed. Install it with: pip install dataduct[spark] "
                "or: pip install pyspark"
            )

        config = config or {}
        app_name = config.get("app_name", "dataduct")
        logger.debug("Creating Spark session (app_name=%s)", app_name)

        import os
        import sys
        python_exec = sys.executable
        if "PYSPARK_PYTHON" not in os.environ:
            os.environ["PYSPARK_PYTHON"] = python_exec
        if "PYSPARK_DRIVER_PYTHON" not in os.environ:
            os.environ["PYSPARK_DRIVER_PYTHON"] = python_exec

        builder = SparkSession.builder.appName(app_name)

        if config.get("master"):
            builder = builder.master(config["master"])

        builder = builder.config("spark.pyspark.python", os.environ["PYSPARK_PYTHON"])
        builder = builder.config("spark.pyspark.driver.python", os.environ["PYSPARK_DRIVER_PYTHON"])

        for key, value in config.get("conf", {}).items():
            builder = builder.config(key, value)

        packages = config.get("packages", [])
        if packages:
            builder = builder.config("spark.jars.packages", ",".join(packages))

        jars = config.get("jars", [])
        if jars:
            builder = builder.config("spark.jars", ",".join(jars))

        self._session = builder.getOrCreate()
        logger.debug("Spark session created (version=%s)", self._session.version)
        return self._session

    def stop_session(self) -> None:
        """Stop the SparkSession and release cluster resources."""
        if self._session:
            logger.debug("Stopping Spark session")
            self._session.stop()
            self._session = None

    @property
    def session(self) -> Any:
        """The active :class:`pyspark.sql.SparkSession`, or ``None``."""
        return self._session

    def read(self, format: str, **options) -> Any:
        """Read data into a Spark DataFrame.

        Args:
            format: Data source format (e.g. ``"csv"``, ``"parquet"``,
                ``"jdbc"``).
            **options: Reader options.  ``path`` and ``schema`` are popped
                and handled separately; remaining keys are passed via
                ``.options()``.

        Returns:
            A :class:`pyspark.sql.DataFrame`.
        """
        opts = dict(options)
        path = opts.pop("path", None)
        schema = opts.pop("schema", None)
        logger.debug("Spark read: format=%s path=%s", format, path)

        reader = self._session.read.format(format)
        if schema:
            reader = reader.schema(schema)
        if opts:
            reader = reader.options(**opts)

        return reader.load(path) if path else reader.load()

    def write(self, data: Any, format: str, **options) -> None:
        """Write a Spark DataFrame to the given format and path.

        Args:
            data: A :class:`pyspark.sql.DataFrame`.
            format: Output format (e.g. ``"parquet"``, ``"csv"``).
            **options: Writer options.  Special keys:

                - ``path`` (str): Output path.
                - ``mode`` (str): Write mode. Default: ``"overwrite"``.
                - ``partition_by`` (str | list[str]): Partition columns.

                Remaining keys are forwarded via ``.options()``.
        """
        opts = dict(options)
        path = opts.pop("path", None)
        mode = opts.pop("mode", "overwrite")
        partition_by = opts.pop("partition_by", None)
        logger.debug("Spark write: format=%s path=%s mode=%s", format, path, mode)

        writer = data.write.format(format).mode(mode)
        if opts:
            writer = writer.options(**opts)
        if partition_by:
            if isinstance(partition_by, str):
                partition_by = [partition_by]
            writer = writer.partitionBy(*partition_by)

        writer.save(path) if path else writer.save()

    def execute_sql(self, query: str) -> Any:
        """Execute a SQL query via the SparkSession.

        Args:
            query: SQL string.  Temporary views registered via
                :meth:`~dataduct.core.job.base.Job._register_as_view` are
                accessible by name.

        Returns:
            A :class:`pyspark.sql.DataFrame`.
        """
        logger.debug("Spark execute_sql: %s", query[:200])
        return self._session.sql(query)
