"""Abstract base class for all compute engine adapters.

Every engine (Spark, DuckDB, Polars, …) must subclass
:class:`EngineAdapter` and implement the five abstract methods.  The
framework interacts with engines exclusively through this interface, so
connectors and services remain engine-agnostic.

Adding a new engine
-------------------
1. Create ``dataduct/engines/{name}/adapter.py``.
2. Decorate the class with ``@register_engine("{name}")``.
3. Implement all abstract methods.
4. See ``docs/extending.md`` for a full worked example.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class EngineAdapter(ABC):
    """Protocol that all compute engines must satisfy.

    Implementations handle session lifecycle, data reading/writing, and
    SQL execution.  Connectors call these methods rather than importing
    engine-specific libraries directly.
    """

    @abstractmethod
    def create_session(self, config: Optional[Dict] = None) -> Any:
        """Initialise and return the underlying engine session.

        Called once by :func:`~dataduct.engines.load_engine` after the
        adapter is instantiated.

        Args:
            config: Engine-specific configuration dict (e.g. Spark
                ``app_name``, DuckDB ``database`` path).

        Returns:
            The native session object (``SparkSession``, DuckDB connection,
            …).

        Raises:
            ImportError: If the engine's optional dependency is not
                installed.
        """
        raise NotImplementedError

    @abstractmethod
    def stop_session(self):
        """Shutdown the engine session and release all resources.

        Called in the CLI's ``finally`` block to ensure clean teardown
        even when a job fails.
        """
        raise NotImplementedError

    @abstractmethod
    def read(self, format: str, **options) -> Any:
        """Read data in *format* and return a lazy or in-memory dataset.

        Args:
            format: Format string recognised by the engine
                (e.g. ``"csv"``, ``"parquet"``, ``"jdbc"``).
            **options: Format-specific options forwarded to the engine
                reader (e.g. ``path``, ``header``, ``schema``).

        Returns:
            A dataset in the engine's native type (Spark DataFrame, DuckDB
            Relation, …).
        """
        raise NotImplementedError

    @abstractmethod
    def write(self, data: Any, format: str, **options) -> None:
        """Write *data* to *format*.

        Args:
            data: Dataset to persist.
            format: Target format (e.g. ``"parquet"``).
            **options: Format-specific options (e.g. ``path``, ``mode``,
                ``partition_by``).
        """
        raise NotImplementedError

    @abstractmethod
    def execute_sql(self, query: str) -> Any:
        """Execute a SQL query and return the result.

        Args:
            query: SQL string to execute.  Sources that have been
                registered as temp views can be referenced by name.

        Returns:
            Result in the engine's native dataset type.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def session(self) -> Any:
        """The underlying native session object (read-only).

        Returns:
            ``SparkSession``, DuckDB connection, or equivalent.
        """
        raise NotImplementedError
