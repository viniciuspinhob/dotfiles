"""dataduct — lightweight, modular, engine-agnostic ETL framework.

Public API
----------
The following names are available at the top-level package and represent
the stable extension points:

- :data:`__version__` — package version string.
- :class:`Job` — abstract base for all job implementations.
- :class:`Steps` — before/after hook registry for jobs.
- :class:`JobFactory` — resolves a job package name to a :class:`Job`
  instance.
- :class:`EngineAdapter` — abstract base for compute engines.
- :class:`BaseExtractor` — abstract base for data extractors.
- :class:`BaseLoader` — abstract base for data loaders.
- :func:`register_connector` — decorator to register custom connectors.
- :func:`get_connector` — retrieve a connector class from the registry.

Quick example::

    from dataduct import JobFactory
    from dataduct.engines import load_engine

    config = JobFactory.build_config("myproject.my_job", env="dev")
    engine = load_engine(config.get("engine", "duckdb"), config.get("engine_config", {}))
    job = JobFactory.get(config, engine=engine)
    job.execute()
    engine.stop_session()
"""

try:
    from importlib.metadata import PackageNotFoundError, version
    try:
        __version__ = version("dataduct")
    except PackageNotFoundError:
        __version__ = "0.1.0"
except ImportError:
    __version__ = "0.1.0"

from dataduct.connectors.base import BaseExtractor, BaseLoader
from dataduct.core.job.base import Job, Steps
from dataduct.core.job.factory import JobFactory
from dataduct.core.registry import get_connector, register_connector
from dataduct.engines.base import EngineAdapter

__all__ = [
    "__version__",
    "Job",
    "Steps",
    "JobFactory",
    "EngineAdapter",
    "BaseExtractor",
    "BaseLoader",
    "register_connector",
    "get_connector",
]
