"""Parquet connector — extractor."""

from typing import Any, Optional

from dataduct.connectors.base import BaseExtractor
from dataduct.core.registry import register_connector
from dataduct.engines.base import EngineAdapter


@register_connector("parquet", "extractor")
class ParquetExtractor(BaseExtractor):
    """Extractor for Apache Parquet files.

    Delegates reading to the injected
    :class:`~dataduct.engines.base.EngineAdapter`.

    Config keys
    -----------
    - ``path`` (str, required): File path, directory, or glob pattern.
    - ``schema``: Optional schema object (Spark StructType or similar).
    """

    def __init__(self, engine: Optional[EngineAdapter] = None, **kwargs):
        super().__init__(engine=engine, **kwargs)
        self._path = kwargs.get("path")
        self._schema = kwargs.get("schema")
        self._options = {k: v for k, v in kwargs.items() if k not in ("path", "schema")}

    def extract(self) -> Any:
        """Read Parquet data using the engine and return a dataset.

        Returns:
            Engine-native dataset (Spark DataFrame or DuckDB relation).

        Raises:
            RuntimeError: If no engine is provided.
        """
        if self._engine:
            return self._engine.read(
                "parquet",
                path=self._path,
                schema=self._schema,
                **self._options,
            )
        raise RuntimeError("No engine provided for Parquet extraction")
