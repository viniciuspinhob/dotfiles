"""Parquet connector — loader."""

from typing import Any, Optional

from dataduct.connectors.base import BaseLoader
from dataduct.core.registry import register_connector
from dataduct.engines.base import EngineAdapter


@register_connector("parquet", "loader")
class ParquetLoader(BaseLoader):
    """Loader that writes data to Apache Parquet format.

    Delegates writing to the injected
    :class:`~dataduct.engines.base.EngineAdapter`.

    Config keys
    -----------
    - ``path`` (str, required): Output file or directory path.
    - ``mode`` (str): Write mode (``"overwrite"`` or ``"append"``).
      Default: ``"overwrite"``.  DuckDB implements append by merging
      existing + new Parquet files.
    - ``partition_by`` (str | list[str]): Partition column(s).
    """

    def __init__(self, engine: Optional[EngineAdapter] = None, **kwargs):
        super().__init__(engine=engine, **kwargs)
        self._path = kwargs.get("path")
        self._mode = kwargs.get("mode", "overwrite")
        self._partition_by = kwargs.get("partition_by")
        self._options = {k: v for k, v in kwargs.items() if k not in ("path", "mode", "partition_by")}

    def save(self, data: Any) -> None:
        """Write *data* to the configured Parquet path.

        Calls :meth:`~dataduct.connectors.base.BaseLoader._track` before
        writing so that catalog registration has access to the data.

        Args:
            data: Engine-native dataset to persist.

        Raises:
            RuntimeError: If no engine is provided.
        """
        if self._engine:
            self._track(data)
            self._engine.write(
                data,
                "parquet",
                path=self._path,
                mode=self._mode,
                partition_by=self._partition_by,
                **self._options,
            )
            return
        raise RuntimeError("No engine provided for Parquet loading")
