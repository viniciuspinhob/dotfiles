"""Connector factories with lazy registration.

All built-in connectors are imported once (guard-clause pattern) on first
use.  The factories resolve format names to extractor/loader classes via
the global registry.

Public API
----------
- :class:`ExtractorFactory` — create extractor instances by format name.
- :class:`LoaderFactory` — create loader instances by format name.
"""

import logging
from typing import Dict

from dataduct.connectors.base import BaseExtractor, BaseLoader
from dataduct.core.exceptions import SinkInvalidFormat, SinkMissingFormat, SourceInvalidFormat, SourceMissingFormat
from dataduct.core.registry import get_connector

logger = logging.getLogger(__name__)

_connectors_registered = False


def _ensure_connectors_registered() -> None:
    """Import all built-in connector modules exactly once per process.

    Uses a module-level boolean guard so repeated calls are a no-op.
    """
    global _connectors_registered
    if _connectors_registered:
        return
    import dataduct.connectors.csv  # noqa: F401
    import dataduct.connectors.delta  # noqa: F401
    import dataduct.connectors.jdbc  # noqa: F401
    import dataduct.connectors.object_storage  # noqa: F401
    import dataduct.connectors.parquet  # noqa: F401
    _connectors_registered = True


class ExtractorFactory:
    """Static factory for creating :class:`~dataduct.connectors.base.BaseExtractor` instances."""

    @staticmethod
    def get(config: Dict, engine=None) -> BaseExtractor:
        """Resolve *config[\"format\"]* to an extractor class and instantiate it.

        Args:
            config: Source config dict.  The ``"format"`` key is popped
                before the remaining keys are forwarded as kwargs to the
                extractor constructor.
            engine: Active compute engine passed to the extractor.

        Returns:
            An initialised :class:`~dataduct.connectors.base.BaseExtractor`.

        Raises:
            SourceMissingFormat: If the ``"format"`` key is absent.
            SourceInvalidFormat: If no extractor is registered for the
                given format.
        """
        _ensure_connectors_registered()
        config = dict(config)
        format_name = config.pop("format", None)
        if not format_name:
            raise SourceMissingFormat("Source config missing 'format' field")
        try:
            extractor_cls = get_connector(format_name, "extractor")
        except Exception as exc:
            from dataduct.core.registry import list_connectors
            available = list(list_connectors("extractor").keys())
            raise SourceInvalidFormat(
                f"Unknown source format: {format_name!r}. Available: {available}"
            ) from exc
        logger.debug("Creating extractor for format '%s'", format_name)
        return extractor_cls(engine=engine, **config)


class LoaderFactory:
    """Static factory for creating :class:`~dataduct.connectors.base.BaseLoader` instances."""

    @staticmethod
    def get(config: Dict, engine=None) -> BaseLoader:
        """Resolve *config[\"format\"]* to a loader class and instantiate it.

        Args:
            config: Sink config dict.  The ``"format"`` key is popped
                before the remaining keys are forwarded as kwargs to the
                loader constructor.
            engine: Active compute engine passed to the loader.

        Returns:
            An initialised :class:`~dataduct.connectors.base.BaseLoader`.

        Raises:
            SinkMissingFormat: If the ``"format"`` key is absent.
            SinkInvalidFormat: If no loader is registered for the given
                format.
        """
        _ensure_connectors_registered()
        config = dict(config)
        format_name = config.pop("format", None)
        if not format_name:
            raise SinkMissingFormat("Sink config missing 'format' field")
        try:
            loader_cls = get_connector(format_name, "loader")
        except Exception as exc:
            from dataduct.core.registry import list_connectors
            available = list(list_connectors("loader").keys())
            raise SinkInvalidFormat(
                f"Unknown sink format: {format_name!r}. Available: {available}"
            ) from exc
        logger.debug("Creating loader for format '%s'", format_name)
        return loader_cls(engine=engine, **config)


__all__ = ["BaseExtractor", "BaseLoader", "ExtractorFactory", "LoaderFactory"]
