"""Delta Lake connector — extractor."""

from typing import Any, Optional

from dataduct.connectors.base import BaseExtractor
from dataduct.core.registry import register_connector
from dataduct.engines.base import EngineAdapter

_SKIP_KEYS = frozenset({"path", "version", "timestamp"})


@register_connector("delta", "extractor")
class DeltaExtractor(BaseExtractor):
    """Extractor for Delta Lake tables.

    Delegates reading to the injected
    :class:`~dataduct.engines.base.EngineAdapter` (Spark required).

    Config keys
    -----------
    - ``path`` (str, required): Delta table location (e.g. ``s3a://bucket/delta/tabela/``).
    - ``version`` (int, optional): Time travel by table version.
    - ``timestamp`` (str, optional): Time travel by timestamp.
    """

    def __init__(self, engine: Optional[EngineAdapter] = None, **kwargs):
        super().__init__(engine=engine, **kwargs)
        self._path = kwargs.get("path")
        self._version = kwargs.get("version")
        self._timestamp = kwargs.get("timestamp")
        self._options = {k: v for k, v in kwargs.items() if k not in _SKIP_KEYS}

    def extract(self) -> Any:
        if not self._engine:
            raise RuntimeError("No engine provided for Delta extraction")

        opts = dict(self._options)
        if self._version is not None:
            opts["versionAsOf"] = str(self._version)
        if self._timestamp:
            opts["timestampAsOf"] = self._timestamp

        return self._engine.read("delta", path=self._path, **opts)
