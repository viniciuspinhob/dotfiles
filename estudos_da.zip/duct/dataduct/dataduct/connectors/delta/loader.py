"""Delta Lake connector — loader."""

from typing import Any, Optional

from dataduct.connectors.base import BaseLoader
from dataduct.core.registry import register_connector
from dataduct.engines.base import EngineAdapter

_SKIP_KEYS = frozenset({"path", "mode", "partition_by", "merge_schema"})


@register_connector("delta", "loader")
class DeltaLoader(BaseLoader):
    """Loader that writes data to Delta Lake format.

    Delegates writing to the injected
    :class:`~dataduct.engines.base.EngineAdapter` (Spark required).

    Config keys
    -----------
    - ``path`` (str, required): Delta table location.
    - ``mode`` (str): Write mode. Default: ``"overwrite"``.
    - ``partition_by`` (str | list[str]): Partition columns.
    - ``merge_schema`` (bool): Enable schema merge on write. Default: ``False``.
    """

    def __init__(self, engine: Optional[EngineAdapter] = None, **kwargs):
        super().__init__(engine=engine, **kwargs)
        self._path = kwargs.get("path")
        self._mode = kwargs.get("mode", "overwrite")
        self._partition_by = kwargs.get("partition_by")
        self._merge_schema = kwargs.get("merge_schema", False)
        self._options = {k: v for k, v in kwargs.items() if k not in _SKIP_KEYS}

    def save(self, data: Any) -> None:
        if not self._engine:
            raise RuntimeError("No engine provided for Delta loading")

        self._track(data)
        opts = dict(self._options)
        if self._merge_schema:
            opts["mergeSchema"] = "true"

        self._engine.write(
            data,
            "delta",
            path=self._path,
            mode=self._mode,
            partition_by=self._partition_by,
            **opts,
        )
