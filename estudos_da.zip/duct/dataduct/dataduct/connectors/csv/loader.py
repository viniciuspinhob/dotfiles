"""CSV connector — loader."""

from typing import Any, Optional

from dataduct.connectors.base import BaseLoader
from dataduct.core.registry import register_connector
from dataduct.engines.base import EngineAdapter


@register_connector("csv", "loader")
class CsvLoader(BaseLoader):
    """Loader that writes data to a delimited text file (CSV/TSV).

    Delegates writing to the injected
    :class:`~dataduct.engines.base.EngineAdapter`.

    Config keys
    -----------
    - ``path`` (str, required): Output file path.
    - ``mode`` (str): Write mode (``"overwrite"`` or ``"append"``).
      Default: ``"overwrite"``.
    - ``header`` (bool): Write column headers. Default: ``True``.
    - ``delimiter`` (str): Column delimiter. Default: ``","``
      (use ``"\\t"`` for TSV).
    - ``partition_by`` (str | list[str]): Partition column(s).
    """

    def __init__(self, engine: Optional[EngineAdapter] = None, **kwargs):
        super().__init__(engine=engine, **kwargs)
        self._path = kwargs.get("path")
        self._mode = kwargs.get("mode", "overwrite")
        self._header = kwargs.get("header", True)
        self._delimiter = kwargs.get("delimiter", ",")
        self._partition_by = kwargs.get("partition_by")
        _skip = {"path", "mode", "header", "delimiter", "partition_by"}
        self._extra = {k: v for k, v in kwargs.items() if k not in _skip}

    def save(self, data: Any) -> None:
        """Write *data* to the configured CSV path.

        Calls :meth:`~dataduct.connectors.base.BaseLoader._track` before
        writing so that catalog registration has access to the data.

        Args:
            data: Engine-native dataset to persist.

        Raises:
            RuntimeError: If no engine is provided.
        """
        if self._engine:
            self._track(data)
            self._engine.write(
                data,
                "csv",
                path=self._path,
                mode=self._mode,
                header=str(self._header).lower(),
                delimiter=self._delimiter,
                partition_by=self._partition_by,
                **self._extra,
            )
            return
        raise RuntimeError("No engine provided for CSV loading")
