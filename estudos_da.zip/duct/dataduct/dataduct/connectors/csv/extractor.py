"""CSV connector — extractor."""

from typing import Any, Optional

from dataduct.connectors.base import BaseExtractor
from dataduct.core.registry import register_connector
from dataduct.engines.base import EngineAdapter


@register_connector("csv", "extractor")
class CsvExtractor(BaseExtractor):
    """Extractor for delimited text files (CSV/TSV).

    Delegates reading to the injected
    :class:`~dataduct.engines.base.EngineAdapter`.

    Config keys
    -----------
    - ``path`` (str, required): File path or glob pattern.
    - ``header`` (bool): Whether the first row is a header.
      Default: ``True``.
    - ``delimiter`` (str): Column delimiter. Default: ``","``
      (use ``"\\t"`` for TSV).
    """

    def __init__(self, engine: Optional[EngineAdapter] = None, **kwargs):
        super().__init__(engine=engine, **kwargs)
        self._path = kwargs.get("path")
        self._header = kwargs.get("header", True)
        self._delimiter = kwargs.get("delimiter", ",")
        self._options = {k: v for k, v in kwargs.items() if k not in ("path", "header", "delimiter")}

    def extract(self) -> Any:
        """Read CSV data using the engine and return a dataset.

        Returns:
            Engine-native dataset (Spark DataFrame or DuckDB relation).

        Raises:
            RuntimeError: If no engine is provided.
        """
        if self._engine:
            return self._engine.read(
                "csv",
                path=self._path,
                header=str(self._header).lower(),
                delimiter=self._delimiter,
                inferSchema="true",
                **self._options,
            )
        raise RuntimeError("No engine provided for CSV extraction")
