"""JDBC connector — loader."""

from typing import Any, Optional

from dataduct.connectors.base import BaseLoader
from dataduct.core.registry import register_connector
from dataduct.engines.base import EngineAdapter


@register_connector("jdbc", "loader")
class JdbcLoader(BaseLoader):
    """Loader that writes data to a relational database via JDBC.

    Credentials are resolved through
    :func:`~dataduct.services.credentials.resolve_credentials`.

    Config keys
    -----------
    - ``url`` (str, required): JDBC URL.
    - ``driver`` (str): JDBC driver class name.
    - ``table`` (str, required): Target table name.
    - ``mode`` (str): Write mode (``"append"``, ``"overwrite"``,
      ``"ignore"``, ``"error"``).  Default: ``"append"``.
    - ``credentials`` (dict): Credential config forwarded to
      :func:`~dataduct.services.credentials.resolve_credentials`.
    """

    def __init__(self, engine: Optional[EngineAdapter] = None, **kwargs):
        super().__init__(engine=engine, **kwargs)
        self._url = kwargs.get("url")
        self._driver = kwargs.get("driver")
        self._table = kwargs.get("table")
        self._mode = kwargs.get("mode", "append")
        self._credentials = kwargs.get("credentials", {})
        self._options = {k: v for k, v in kwargs.items() if k not in ("url", "driver", "table", "mode", "credentials")}

    def save(self, data: Any) -> None:
        """Write *data* to the configured JDBC table.

        Resolves credentials, builds JDBC write options, and delegates the
        write to the engine.

        Args:
            data: Engine-native dataset to persist.

        Raises:
            RuntimeError: If no engine is provided.
        """
        from dataduct.services.credentials import resolve_credentials

        user, password = resolve_credentials(self._credentials)

        if self._engine:
            self._track(data)
            jdbc_options = {
                "url": self._url,
                "dbtable": self._table,
                "user": user,
                "password": password,
                "mode": self._mode,
                **self._options,
            }
            if self._driver:
                jdbc_options["driver"] = self._driver

            self._engine.write(data, "jdbc", **jdbc_options)
            return

        raise RuntimeError("No engine provided for JDBC loading")
