"""JDBC connector — extractor."""

from typing import Any, Optional

from dataduct.connectors.base import BaseExtractor
from dataduct.core.registry import register_connector
from dataduct.engines.base import EngineAdapter


@register_connector("jdbc", "extractor")
class JdbcExtractor(BaseExtractor):
    """Extractor for relational databases via JDBC.

    Credentials are resolved through
    :func:`~dataduct.services.credentials.resolve_credentials` so that
    passwords are never stored as plain strings in job code.

    Config keys
    -----------
    - ``url`` (str, required): JDBC URL (e.g.
      ``"jdbc:postgresql://host:5432/db"``).
    - ``driver`` (str): JDBC driver class name
      (e.g. ``"org.postgresql.Driver"``).
    - ``table`` (str): Table name.  Mutually exclusive with ``query``.
    - ``query`` (str): SQL query to execute.  Wrapped in a subquery.
      Mutually exclusive with ``table``.
    - ``credentials`` (dict): Credential config forwarded to
      :func:`~dataduct.services.credentials.resolve_credentials`.
    """

    def __init__(self, engine: Optional[EngineAdapter] = None, **kwargs):
        super().__init__(engine=engine, **kwargs)
        self._url = kwargs.get("url")
        self._driver = kwargs.get("driver")
        self._table = kwargs.get("table")
        self._query = kwargs.get("query")
        self._credentials = kwargs.get("credentials", {})
        self._options = {k: v for k, v in kwargs.items() if k not in ("url", "driver", "table", "query", "credentials")}

    def extract(self) -> Any:
        """Connect to the JDBC source and return a dataset.

        Resolves credentials, builds JDBC options, and delegates the read
        to the engine.

        Returns:
            Engine-native dataset (typically a Spark DataFrame).

        Raises:
            RuntimeError: If no engine is provided.
        """
        from dataduct.services.credentials import resolve_credentials

        user, password = resolve_credentials(self._credentials)

        if self._engine:
            jdbc_options = {
                "url": self._url,
                "user": user,
                "password": password,
                **self._options,
            }
            if self._driver:
                jdbc_options["driver"] = self._driver
            if self._query:
                jdbc_options["dbtable"] = f"({self._query}) as subq"
            elif self._table:
                jdbc_options["dbtable"] = self._table

            return self._engine.read("jdbc", **jdbc_options)

        raise RuntimeError("No engine provided for JDBC extraction")
