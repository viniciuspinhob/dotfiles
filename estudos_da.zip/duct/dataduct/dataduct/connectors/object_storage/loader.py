"""Object Storage connector — loader (S3 / MinIO)."""

import io
from typing import Any, Optional

from dataduct.connectors.base import BaseLoader
from dataduct.core.registry import register_connector
from dataduct.engines.base import EngineAdapter


@register_connector("object_storage", "loader")
class ObjectStorageLoader(BaseLoader):
    """Loader that writes data to S3-compatible object storage.

    Two code paths depending on whether ``endpoint_url`` is set:

    - **No endpoint_url** (standard AWS S3): constructs an ``s3a://``
      path and delegates writing to the engine.
    - **With endpoint_url** (MinIO, LocalStack, …): serialises data via
      PyArrow and uploads using ``boto3.put_object``.

    Config keys
    -----------
    - ``bucket`` (str, required): S3 bucket name.
    - ``key`` / ``path`` (str, required): Destination object key.
    - ``file_format`` (str): Output format (``"parquet"`` or ``"csv"``).
      Default: ``"parquet"``.
    - ``mode`` (str): Write mode. Default: ``"overwrite"``.
    - ``endpoint_url`` (str): Custom endpoint for MinIO / LocalStack.
    - ``credentials`` (dict): Credential config forwarded to
      :func:`~dataduct.services.credentials.resolve_credentials`.
    - ``partition_by`` (str | list[str]): Partition column(s).
    """

    def __init__(self, engine: Optional[EngineAdapter] = None, **kwargs):
        super().__init__(engine=engine, **kwargs)
        self._bucket = kwargs.get("bucket")
        self._key = kwargs.get("key", kwargs.get("path", ""))
        self._file_format = kwargs.get("file_format", "parquet")
        self._mode = kwargs.get("mode", "overwrite")
        self._endpoint_url = kwargs.get("endpoint_url")
        self._credentials = kwargs.get("credentials", {})
        self._partition_by = kwargs.get("partition_by")
        _skip = {"bucket", "key", "path", "file_format", "mode", "endpoint_url", "credentials", "partition_by"}
        self._options = {k: v for k, v in kwargs.items() if k not in _skip}

    def save(self, data: Any) -> None:
        """Write *data* to the configured S3/MinIO path.

        Args:
            data: Engine-native dataset or PyArrow Table.

        Raises:
            ValueError: If serialisation of *data* fails.
        """
        self._track(data)
        if self._engine and self._endpoint_url is None:
            s3_path = f"s3a://{self._bucket}/{self._key}"
            self._engine.write(
                data,
                self._file_format,
                path=s3_path,
                mode=self._mode,
                partition_by=self._partition_by,
                **self._options,
            )
            return

        client = self._get_s3_client()
        raw_bytes = self._serialize(data)
        client.put_object(Bucket=self._bucket, Key=self._key, Body=raw_bytes)

    def _get_s3_client(self):
        """Create and return a boto3 S3 client.

        Returns:
            A configured ``boto3.client("s3", ...)`` instance.
        """
        import boto3

        from dataduct.services.credentials import resolve_credentials

        kwargs = {}
        if self._endpoint_url:
            kwargs["endpoint_url"] = self._endpoint_url

        user, password = resolve_credentials(self._credentials)
        if user and password:
            kwargs["aws_access_key_id"] = user
            kwargs["aws_secret_access_key"] = password

        return boto3.client("s3", **kwargs)

    def _serialize(self, data: Any) -> bytes:
        """Serialise *data* to bytes using PyArrow.

        Supported input types: Spark DataFrame, DuckDB relation, PyArrow
        Table, pandas DataFrame.

        Args:
            data: Dataset to serialise.

        Returns:
            Serialised bytes in the configured ``file_format``.

        Raises:
            ValueError: If *data* is not a recognised type or the format
                is unsupported.
        """
        import pyarrow as pa
        import pyarrow.csv as pa_csv
        import pyarrow.parquet as pq

        if hasattr(data, "toPandas"):
            pdf = data.toPandas()
            table = pa.Table.from_pandas(pdf)
        elif hasattr(data, "fetchdf"):
            pdf = data.fetchdf()
            table = pa.Table.from_pandas(pdf)
        elif isinstance(data, pa.Table):
            table = data
        else:
            import pandas as pd
            if isinstance(data, pd.DataFrame):
                table = pa.Table.from_pandas(data)
            else:
                raise ValueError(f"Cannot serialize data type: {type(data)}")

        buf = io.BytesIO()
        if self._file_format == "parquet":
            pq.write_table(table, buf)
        elif self._file_format == "csv":
            pa_csv.write_csv(table, buf)
        else:
            raise ValueError(f"Unsupported format for object_storage serialization: {self._file_format}")

        return buf.getvalue()
