"""Object Storage connector — extractor (S3 / MinIO)."""

import io
from typing import Any, Optional

from dataduct.connectors.base import BaseExtractor
from dataduct.core.registry import register_connector
from dataduct.engines.base import EngineAdapter


@register_connector("object_storage", "extractor")
class ObjectStorageExtractor(BaseExtractor):
    """Extractor for files stored in S3-compatible object storage.

    Two code paths depending on whether ``endpoint_url`` is set:

    - **No endpoint_url** (standard AWS S3): constructs an ``s3a://``
      path and delegates reading to the engine (requires the engine's
      Hadoop AWS connector).
    - **With endpoint_url** (MinIO, LocalStack, …): downloads the file
      directly via ``boto3`` and either reads it through the engine (via
      a temp file) or via PyArrow if no engine is available.

    Config keys
    -----------
    - ``bucket`` (str, required): S3 bucket name.
    - ``key`` / ``path`` (str, required): Object key within the bucket.
    - ``file_format`` (str): File format to read (``"parquet"`` or
      ``"csv"``).  Default: ``"parquet"``.
    - ``endpoint_url`` (str): Custom endpoint for MinIO / LocalStack.
    - ``credentials`` (dict): Credential config forwarded to
      :func:`~dataduct.services.credentials.resolve_credentials`.
    """

    def __init__(self, engine: Optional[EngineAdapter] = None, **kwargs):
        super().__init__(engine=engine, **kwargs)
        self._bucket = kwargs.get("bucket")
        self._key = kwargs.get("key", kwargs.get("path", ""))
        self._file_format = kwargs.get("file_format", "parquet")
        self._endpoint_url = kwargs.get("endpoint_url")
        self._credentials = kwargs.get("credentials", {})
        _skip = {"bucket", "key", "path", "file_format", "endpoint_url", "credentials"}
        self._options = {k: v for k, v in kwargs.items() if k not in _skip}

    def extract(self) -> Any:
        """Read an object from S3/MinIO and return a dataset.

        Returns:
            Engine-native dataset or PyArrow Table (when no engine is
            available).

        Raises:
            RuntimeError: If no engine and the format is not supported by
                the PyArrow fallback.
        """
        if self._engine and self._endpoint_url is None:
            s3_path = f"s3a://{self._bucket}/{self._key}"
            return self._engine.read(self._file_format, path=s3_path, **self._options)

        client = self._get_s3_client()
        response = client.get_object(Bucket=self._bucket, Key=self._key)
        raw_bytes = response["Body"].read()

        if self._engine:
            return self._load_with_engine(raw_bytes)

        return self._load_with_pyarrow(raw_bytes)

    def _get_s3_client(self):
        """Create and return a boto3 S3 client.

        Credentials and endpoint_url are applied if present.

        Returns:
            A configured ``boto3.client("s3", ...)`` instance.
        """
        import boto3

        from dataduct.services.credentials import resolve_credentials

        kwargs = {}
        if self._endpoint_url:
            kwargs["endpoint_url"] = self._endpoint_url

        user, password = resolve_credentials(self._credentials)
        if user and password:
            kwargs["aws_access_key_id"] = user
            kwargs["aws_secret_access_key"] = password

        return boto3.client("s3", **kwargs)

    def _load_with_engine(self, raw_bytes: bytes) -> Any:
        """Write *raw_bytes* to a temp file and read it via the engine.

        Args:
            raw_bytes: Raw file bytes downloaded from S3.

        Returns:
            Engine-native dataset.
        """
        import os
        import tempfile

        with tempfile.NamedTemporaryFile(suffix=f".{self._file_format}", delete=False) as f:
            f.write(raw_bytes)
            tmp_path = f.name

        try:
            return self._engine.read(self._file_format, path=tmp_path, **self._options)
        finally:
            os.unlink(tmp_path)

    def _load_with_pyarrow(self, raw_bytes: bytes) -> Any:
        """Deserialise *raw_bytes* using PyArrow without an engine.

        Args:
            raw_bytes: Raw file bytes downloaded from S3.

        Returns:
            A :class:`pyarrow.Table`.

        Raises:
            ValueError: If the format is not supported by this fallback.
        """
        import pyarrow.csv as pa_csv
        import pyarrow.parquet as pq

        if self._file_format == "parquet":
            return pq.read_table(io.BytesIO(raw_bytes))
        elif self._file_format == "csv":
            return pa_csv.read_csv(io.BytesIO(raw_bytes))
        else:
            raise ValueError(f"Cannot read format '{self._file_format}' without engine")
