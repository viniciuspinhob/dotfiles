"""Abstract base classes for connectors: extractors and loaders.

All connectors follow a two-class pattern:

- :class:`BaseExtractor` — reads data from a source.
- :class:`BaseLoader` — writes data to a sink and (optionally) triggers
  catalog registration after the write.

Connectors delegate all I/O to the injected
:class:`~dataduct.engines.base.EngineAdapter`, so they remain
engine-agnostic.  Concrete connectors register themselves via
:func:`~dataduct.core.registry.register_connector`.
"""

import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

from dataduct.engines.base import EngineAdapter

logger = logging.getLogger(__name__)


class BaseExtractor(ABC):
    """Abstract base for all data extractors.

    Subclasses must implement :meth:`extract` and register themselves
    with ``@register_connector(format, "extractor")``.

    Args:
        engine: Active compute engine.  ``None`` is allowed for testing.
        **kwargs: Format-specific options (e.g. ``path``, ``header``).
    """

    def __init__(self, engine: Optional[EngineAdapter] = None, **kwargs):
        self._engine = engine
        self._options = kwargs

    @abstractmethod
    def extract(self) -> Any:
        """Read and return data from the source.

        Returns:
            A dataset in the engine's native type (Spark DataFrame,
            DuckDB relation, PyArrow Table, …).

        Raises:
            RuntimeError: If no engine is provided and one is required.
        """
        raise NotImplementedError


class BaseLoader(ABC):
    """Abstract base for all data loaders (sinks).

    Subclasses must implement :meth:`save` and register themselves with
    ``@register_connector(format, "loader")``.

    After :meth:`save` completes, :meth:`after_save` is called by the job
    lifecycle to trigger optional catalog registration (Glue, Unity, …).

    Args:
        engine: Active compute engine.  ``None`` is allowed for testing.
        **kwargs: Format-specific options (e.g. ``path``, ``mode``,
            ``partition_by``).
    """

    def __init__(self, engine: Optional[EngineAdapter] = None, **kwargs):
        self._engine = engine
        self._options = kwargs
        self._catalog_config: Optional[Dict] = None
        self._engine_ref: Optional[EngineAdapter] = None
        self._last_data: Any = None

    @abstractmethod
    def save(self, data: Any) -> None:
        """Write *data* to the configured sink.

        Implementations should call :meth:`_track` before writing so that
        :meth:`after_save` has access to the data for schema inference.

        Args:
            data: Dataset to persist.

        Raises:
            RuntimeError: If no engine is provided and one is required.
        """
        raise NotImplementedError

    def set_catalog(self, catalog_config: Dict, engine: Optional[EngineAdapter] = None) -> None:
        """Attach a catalog config to this loader.

        Called by :meth:`~dataduct.core.job.base.Job.register_sinks` when
        a ``catalog`` block is present in the sink config.  The catalog is
        applied by :meth:`after_save` after the write completes.

        Args:
            catalog_config: Catalog configuration dict (must contain at
                minimum ``provider``, ``database``, ``table_name``).
            engine: Engine reference forwarded to the catalog provider.
        """
        self._catalog_config = catalog_config
        self._engine_ref = engine

    def _track(self, data: Any) -> None:
        """Store *data* for use by :meth:`after_save`.

        Should be called at the start of :meth:`save` before the actual
        write so that the data is available for schema inference even if
        the write raises.

        Args:
            data: The dataset about to be written.
        """
        self._last_data = data

    def after_save(self) -> None:
        """Register the last saved dataset in the configured catalog.

        Called unconditionally (in a ``finally`` block) by
        :meth:`~dataduct.core.job.base.Job.execute` after :meth:`save`
        has been called.  A no-op when no catalog config is attached or
        when :meth:`save` was never called.
        """
        if self._catalog_config and self._last_data is not None:
            import dataduct.services.catalog as _catalog_mod
            path = self._options.get("path") or getattr(self, "_path", None)
            partition_by = (
                self._options.get("partition_by") or getattr(self, "_partition_by", None)
            )
            logger.debug(
                "Applying catalog registration for path=%s provider=%s",
                path,
                self._catalog_config.get("provider"),
            )
            _catalog_mod.apply_catalog(
                data=self._last_data,
                catalog_config=self._catalog_config,
                path=path,
                engine=self._engine_ref,
                partition_by=partition_by,
            )
