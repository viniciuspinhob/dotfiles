# AGENTS.md — dataduct

Reference guide for AI coding assistants and developers working on the dataduct codebase.

---

## Commands

### Environment setup

```bash
# Create venv (Python 3.11) and install all deps
make venv && make install-all

# Core only (YAML + CLI, no engines)
pip install -e .

# With specific extras
pip install -e ".[duckdb]"     # DuckDB + PyArrow
pip install -e ".[spark]"      # PySpark
pip install -e ".[aws]"        # boto3 (S3, Glue)
pip install -e ".[unity]"      # requests + PyArrow (Unity Catalog REST)
pip install -e ".[dev]"        # pytest + ruff
pip install -e ".[all,dev]"    # everything
```

### Testing

```bash
make test              # all tests (122 expected to pass)
make test-cov          # with coverage report
make test-duckdb       # only DuckDB engine tests
make test-spark        # only Spark engine tests

# Run a single test file
.venv/bin/pytest tests/test_config.py -v

# Run with a keyword filter
.venv/bin/pytest -k "masking" -v
```

> **Prerequisites for Spark tests**: Java 17+, PySpark 3.5.3.
> DuckDB tests require `duckdb>=1.5` and `pyarrow>=15`.

### Lint & format

```bash
make lint      # ruff check dataduct/ tests/
make format    # ruff format dataduct/ tests/
```

Run lint before every commit. The CI gate requires zero ruff errors.

### Build

```bash
make build     # produces dist/ wheel + sdist
make clean     # removes build artifacts and __pycache__
```

### CLI

```bash
# Run a job
python -m dataduct run --job domain.my_job --engine duckdb

# With environment overlay (loads config-dev.yaml)
python -m dataduct run --job domain.my_job --env dev --engine duckdb

# With custom args (override config custom section)
python -m dataduct run --job domain.my_job -c '{"year": "2025"}'

# Dry-run: validate config and print as JSON, no execution
python -m dataduct run --job domain.my_job --dry-run

# Verbose debug logging
python -m dataduct --verbose run --job domain.my_job
```

---

## Architecture

### 5-layer structure

```
CLI (__main__.py)
  └── Core (core/)
        ├── config.py          YAML parsing + Jinja2 rendering
        ├── validators.py      Pre-execution config validation
        ├── registry.py        Plugin registry (engines + connectors)
        ├── exceptions.py      Typed exception hierarchy
        └── job/
              ├── base.py      Job ABC + Steps hook registry
              └── factory.py   JobFactory: config → Job instance
  └── Engines (engines/)
        ├── base.py            EngineAdapter ABC
        ├── spark/adapter.py   SparkEngineAdapter
        └── duckdb/adapter.py  DuckDBEngineAdapter
  └── Connectors (connectors/)
        ├── base.py            BaseExtractor + BaseLoader ABCs
        ├── csv/               CsvExtractor + CsvLoader
        ├── parquet/           ParquetExtractor + ParquetLoader
        ├── jdbc/              JdbcExtractor + JdbcLoader
        └── object_storage/    ObjectStorageExtractor + ObjectStorageLoader
  └── Services (services/)
        ├── credentials.py     resolve_credentials()
        ├── masking/           MaskingProvider ABC + HashMaskingProvider
        └── catalog/           CatalogProvider ABC + Glue/Unity/Unity REST
  └── Utils (utils/)
        └── bunch.py           Bunch (dict with attribute access)
```

### Job execution lifecycle

```
JobFactory.build_config()     Walk package tree, merge YAMLs, render Jinja2, validate
    │
    ▼
load_engine(name, config)     Lazy-register engines, instantiate, create_session()
    │
    ▼
JobFactory.get(config, engine)  Import {package}.job, find Job subclass, instantiate
    │
    ▼
job.execute()
    ├── register_sources()    Extract + masking + register as temp view
    ├── register_sinks()      Create loaders + attach catalog config
    ├── steps.run_before()    User before-hooks
    ├── job.run()             User business logic
    ├── steps.run_after()     User after-hooks
    └── finally:
          loader.after_save() Catalog registration for each sink
    │
    ▼
engine.stop_session()         Always called in CLI finally block
```

### Config merge order (highest priority wins)

```
CLI --custom  >  config-{env}.yaml  >  config.yaml  >  parent config  >  defaults
```

For job package `a.b.c`, the tree is walked `["a", "a.b", "a.b.c"]` (root to leaf).
Lists are merged by matching `"name"` keys. All other values: child wins.

---

## Code conventions

### Style

- Python 3.11+
- Line length: 120 (ruff enforced)
- No comments unless strictly necessary — use docstrings instead
- Google-style docstrings on all public modules, classes, and functions
- Type annotations on all function signatures
- No `eval()` anywhere

### Naming

| Entity | Convention | Example |
|--------|-----------|---------|
| Classes | PascalCase | `SparkEngineAdapter` |
| Functions / methods | snake_case | `build_config` |
| Module-level constants | UPPER_SNAKE | `_ALLOWED_SETTINGS` |
| Private helpers | leading underscore | `_validate_path` |
| Test functions | `test_` prefix | `test_csv_extractor_calls_engine` |

### Design patterns in use

| Pattern | Where | Purpose |
|---------|-------|---------|
| Abstract Factory | `EngineAdapter`, `BaseExtractor`, `BaseLoader` | Engine-agnostic connectors |
| Plugin Registry | `core/registry.py` | Extensible engines/connectors without modifying core |
| Decorator registration | `@register_engine`, `@register_connector` | Self-registering plugins |
| Lazy loading + guard clause | `engines/__init__.py`, `connectors/__init__.py` | Optional deps never imported unless used |
| Template Method | `Job.execute()` + abstract `Job.run()` | Framework controls lifecycle, user fills `run()` |
| Strategy | `MaskingProvider`, `CatalogProvider` | Swappable algorithms/services |
| Bunch | `utils/bunch.py` | Ergonomic dict-as-namespace for sources/sinks/custom |

### Security rules (never break these)

- **No `eval()`**: Jinja2 rendering uses `ast.literal_eval` then `yaml.safe_load` only.
- **SQL identifiers validated**: all SQL identifiers (table/db names) go through regex `^[a-zA-Z_][a-zA-Z0-9_]*$` before being placed in SQL strings.
- **Path traversal blocked**: `_validate_path()` in `duckdb/adapter.py` rejects paths containing `..`.
- **DuckDB settings whitelist**: only keys in `_ALLOWED_SETTINGS` can be SET via config.
- **Credentials warning**: `type: "direct"` in credentials config always emits a WARNING log.

---

## Navigation guide

### "Where is X?"

| What you want | File |
|--------------|------|
| Job base class & lifecycle | `dataduct/core/job/base.py` |
| Job instantiation from package name | `dataduct/core/job/factory.py` |
| YAML config merge logic | `dataduct/core/config.py` |
| Config validation rules | `dataduct/core/validators.py` |
| Plugin registry (add engine/connector) | `dataduct/core/registry.py` |
| Exception hierarchy | `dataduct/core/exceptions.py` |
| Jinja2 template functions | `dataduct/core/jinja_functions.py` |
| Engine ABC | `dataduct/engines/base.py` |
| Engine loader (load_engine) | `dataduct/engines/__init__.py` |
| Spark adapter | `dataduct/engines/spark/adapter.py` |
| DuckDB adapter | `dataduct/engines/duckdb/adapter.py` |
| Extractor/Loader ABCs | `dataduct/connectors/base.py` |
| Connector factories | `dataduct/connectors/__init__.py` |
| CSV connector | `dataduct/connectors/csv/` |
| Parquet connector | `dataduct/connectors/parquet/` |
| JDBC connector | `dataduct/connectors/jdbc/` |
| S3/MinIO connector | `dataduct/connectors/object_storage/` |
| Credential resolution | `dataduct/services/credentials.py` |
| Masking service API | `dataduct/services/masking/__init__.py` |
| Hash masking implementation | `dataduct/services/masking/hash.py` |
| Catalog service API | `dataduct/services/catalog/__init__.py` |
| AWS Glue provider | `dataduct/services/catalog/glue.py` |
| Databricks Unity (Spark SQL) | `dataduct/services/catalog/unity.py` |
| Unity Catalog REST | `dataduct/services/catalog/unity_rest.py` |
| Schema inference (PyArrow) | `dataduct/services/catalog/schema_inference.py` |
| Table format enum | `dataduct/services/catalog/table_format.py` |
| Bunch utility | `dataduct/utils/bunch.py` |
| CLI entry point | `dataduct/__main__.py` |
| Package public API | `dataduct/__init__.py` |

### Test files

| Test file | What it covers |
|-----------|---------------|
| `tests/test_bunch.py` | Bunch attribute access, set, delete, repr |
| `tests/test_cli.py` | CLI dry-run, custom args, error paths |
| `tests/test_config.py` | deep_merge_dict, _merge_list_elements, _build_package_tree |
| `tests/test_config_extended.py` | Jinja2 rendering, edge cases, build() from package |
| `tests/test_validators.py` | All 14+ validation scenarios |
| `tests/test_job.py` | Job init, Steps hooks |
| `tests/test_job_factory_e2e.py` | E2E CSV→Parquet pipeline, masking E2E |
| `tests/test_registry.py` | register/get connector and engine |
| `tests/connectors/test_csv.py` | CsvExtractor + CsvLoader |
| `tests/connectors/test_parquet.py` | ParquetExtractor + ParquetLoader |
| `tests/connectors/test_jdbc.py` | JdbcExtractor (table/query/env creds) + JdbcLoader |
| `tests/connectors/test_object_storage.py` | ObjectStorageExtractor/Loader |
| `tests/engines/test_duckdb.py` | DuckDB session, read/write CSV+Parquet |
| `tests/engines/test_spark.py` | Spark session, read/write CSV+Parquet, execute_sql |
| `tests/services/test_masking.py` | HashMaskingProvider sha256, multiple cols, determinism |
| `tests/services/test_masking_extended.py` | md5, unknown algorithm, nonexistent col, credentials |
| `tests/services/test_catalog.py` | Glue + Unity provider instantiation and operations |
| `tests/services/test_catalog_table_format.py` | TableFormat, SchemaInference, UnityCatalogRestProvider |

---

## Extending the framework

### Add a new engine

1. Create `dataduct/engines/{name}/adapter.py` and `__init__.py`.
2. Subclass `EngineAdapter` and decorate with `@register_engine("{name}")`.
3. Implement: `create_session`, `stop_session`, `session`, `read`, `write`, `execute_sql`.
4. The engine is auto-registered on first import via `_ensure_engines_registered()`.
5. See `docs/extending.md` for a full Polars example.

### Add a new connector

1. Create `dataduct/connectors/{format}/extractor.py` and `loader.py`.
2. Subclass `BaseExtractor` / `BaseLoader`; decorate with `@register_connector("{format}", "extractor"|"loader")`.
3. Add an `__init__.py` that imports both classes.
4. Add the import to `connectors/__init__.py → _ensure_connectors_registered()`.
5. Add `"{format}"` to `_VALID_SOURCE_FORMATS` / `_VALID_SINK_FORMATS` in `core/validators.py`.

### Add a masking provider

```python
from dataduct.services.masking.base import MaskingProvider
from dataduct.services.masking import register_masking_provider

class MyProvider(MaskingProvider):
    def mask(self, data, columns_config, engine=None): ...
    def unmask(self, data, columns_config, engine=None): ...

register_masking_provider("my_algo", MyProvider)
```

Add `"my_algo"` to `_VALID_MASKING_PROVIDERS` in `core/validators.py`.

### Add a catalog provider

```python
from dataduct.services.catalog.base import CatalogProvider
from dataduct.services.catalog import register_catalog_provider

class MyProvider(CatalogProvider):
    def register_table(self, path, database, table_name, ...): ...
    def drop_table(self, database, table_name): ...
    def table_exists(self, database, table_name): ...
    def create_database(self, database, description=None): ...

register_catalog_provider("my_catalog", MyProvider)
```

Add `"my_catalog"` to `_VALID_CATALOG_PROVIDERS` in `core/validators.py`.

---

## Dependencies

### Core (always installed)
- `PyYAML>=6.0` — YAML parsing
- `Jinja2>=3.1` — config templating
- `click>=8.1` — CLI

### Optional extras
| Extra | Packages | When needed |
|-------|----------|-------------|
| `duckdb` | `duckdb>=0.10`, `pyarrow>=15.0` | DuckDB engine + Parquet/schema inference |
| `spark` | `pyspark>=3.4` | Spark engine + Unity Catalog (Spark SQL) |
| `aws` | `boto3>=1.34` | S3/MinIO object storage + AWS Glue catalog |
| `unity` | `requests>=2.28`, `pyarrow>=15.0` | Unity Catalog REST API |
| `all` | all above | Everything |
| `dev` | `pytest>=8.0`, `pytest-mock>=3.12`, `pytest-cov>=4.1`, `ruff>=0.4` | Testing + linting |

### Runtime environment (tested combination)
- Python 3.11.15
- PySpark 3.5.3
- DuckDB 1.5.4
- Java 17 (required for Spark)
- macOS arm64 / Linux x86_64

---

## YAML config reference

### Minimal config

```yaml
engine: duckdb    # or spark

sources:
  - name: input
    format: csv
    path: "data/input.csv"
    header: true

sinks:
  - name: output
    format: parquet
    path: "/tmp/output.parquet"
    mode: overwrite
```

### Full config with all services

```yaml
engine: spark

engine_config:
  app_name: "my-job"
  master: "local[*]"

custom:
  year: "2025"
  bucket: "my-bucket"

sources:
  - name: raw_data
    format: parquet
    path: "s3a://{{ env_var('BUCKET') }}/raw/{{ year }}/"
    masking:
      provider: hash
      columns:
        - column: cpf
          algorithm: sha256
        - column: email
          algorithm: sha256

sinks:
  - name: curated_data
    format: parquet
    path: "s3a://{{ env_var('BUCKET') }}/curated/{{ year }}/"
    mode: overwrite
    partition_by: ["dt_referencia"]
    catalog:
      provider: glue
      database: "my_domain_curated"
      table_name: "raw_data"
      description: "Processed data with PII masked"
      region: "us-east-1"
```

### Credentials config

```yaml
# Recommended (production)
credentials:
  type: env
  user_var: DB_USER
  password_var: DB_PASSWORD

# Development only — emits a WARNING
credentials:
  type: direct
  user: postgres
  password: secret
```

---

## Documentation

Full technical documentation is in `docs/`:

| File | Content |
|------|---------|
| `docs/architecture.md` | Layer diagram, execution flow, patterns, security, logging |
| `docs/config.md` | YAML structure, merge rules, Jinja2, validation |
| `docs/engines.md` | EngineAdapter ABC, Spark config, DuckDB config |
| `docs/connectors.md` | All connectors with full options tables |
| `docs/services.md` | Masking + Catalog (Glue/Unity/Unity REST) |
| `docs/extending.md` | Step-by-step guides: add engine/connector/service |
| `docs/TECH_DEBT.md` | Prioritised list of known technical debt |
| `CHANGELOG.md` | Version history |
