# Extensibilidade

O dataduct foi projetado para ser estendido sem modificar o código existente. Este guia mostra como adicionar novas engines, conectores e serviços.

---

## Adicionar Nova Engine

Exemplo: adicionar suporte a **Polars**.

### 1. Criar o diretório

```
dataduct/engines/polars/
├── __init__.py
└── adapter.py
```

### 2. Implementar o adapter

```python
# dataduct/engines/polars/adapter.py
from typing import Any, Dict, Optional

from dataduct.engines.base import EngineAdapter
from dataduct.core.registry import register_engine


@register_engine("polars")
class PolarsEngineAdapter(EngineAdapter):
    def __init__(self):
        self._session = None

    def create_session(self, config: Optional[Dict] = None) -> Any:
        import polars as pl
        self._session = pl
        return self._session

    def stop_session(self):
        self._session = None

    @property
    def session(self) -> Any:
        return self._session

    def read(self, format: str, **options) -> Any:
        import polars as pl
        path = options.get("path")

        if format == "csv":
            return pl.read_csv(path)
        elif format == "parquet":
            return pl.read_parquet(path)
        elif format == "json":
            return pl.read_json(path)
        else:
            raise ValueError(f"Unsupported format: {format}")

    def write(self, data: Any, format: str, **options) -> None:
        path = options.get("path")

        if format == "csv":
            data.write_csv(path)
        elif format == "parquet":
            data.write_parquet(path)
        elif format == "json":
            data.write_json(path)
        else:
            raise ValueError(f"Unsupported format: {format}")

    def execute_sql(self, query: str) -> Any:
        import polars as pl
        return pl.SQLContext(frames=self._registered_frames).execute(query)
```

### 3. Registrar o import

```python
# dataduct/engines/polars/__init__.py
from dataduct.engines.polars.adapter import PolarsEngineAdapter  # noqa: F401
```

### 4. Adicionar ao auto-discovery

Em `dataduct/engines/__init__.py`, adicionar:

```python
def _ensure_engines_registered():
    ...
    try:
        import dataduct.engines.polars  # noqa: F401
    except ImportError:
        pass
```

### 5. Usar

```bash
python -m dataduct run --job meu.job --engine polars
```

---

## Adicionar Novo Conector

Exemplo: adicionar suporte a **Delta Lake**.

### 1. Criar o diretório

```
dataduct/connectors/delta/
├── __init__.py
├── extractor.py
└── loader.py
```

### 2. Implementar o extractor

```python
# dataduct/connectors/delta/extractor.py
from typing import Any, Optional

from dataduct.connectors.base import BaseExtractor
from dataduct.core.registry import register_connector
from dataduct.engines.base import EngineAdapter


@register_connector("delta", "extractor")
class DeltaExtractor(BaseExtractor):
    def __init__(self, engine: Optional[EngineAdapter] = None, **kwargs):
        super().__init__(engine=engine, **kwargs)
        self._path = kwargs.get("path")
        self._version = kwargs.get("version")
        self._timestamp = kwargs.get("timestamp")
        self._options = {k: v for k, v in kwargs.items()
                        if k not in ("path", "version", "timestamp")}

    def extract(self) -> Any:
        if self._engine:
            opts = dict(self._options)
            if self._version is not None:
                opts["versionAsOf"] = str(self._version)
            if self._timestamp:
                opts["timestampAsOf"] = self._timestamp

            return self._engine.read("delta", path=self._path, **opts)

        raise RuntimeError("No engine provided for Delta extraction")
```

### 3. Implementar o loader

```python
# dataduct/connectors/delta/loader.py
from typing import Any, Optional

from dataduct.connectors.base import BaseLoader
from dataduct.core.registry import register_connector
from dataduct.engines.base import EngineAdapter


@register_connector("delta", "loader")
class DeltaLoader(BaseLoader):
    def __init__(self, engine: Optional[EngineAdapter] = None, **kwargs):
        super().__init__(engine=engine, **kwargs)
        self._path = kwargs.get("path")
        self._mode = kwargs.get("mode", "overwrite")
        self._partition_by = kwargs.get("partition_by")
        self._merge_schema = kwargs.get("merge_schema", False)
        self._options = {k: v for k, v in kwargs.items()
                        if k not in ("path", "mode", "partition_by", "merge_schema")}

    def save(self, data: Any) -> None:
        if self._engine:
            opts = dict(self._options)
            if self._merge_schema:
                opts["mergeSchema"] = "true"

            self._engine.write(
                data, "delta",
                path=self._path,
                mode=self._mode,
                partition_by=self._partition_by,
                **opts,
            )
            return

        raise RuntimeError("No engine provided for Delta loading")
```

### 4. Registrar imports

```python
# dataduct/connectors/delta/__init__.py
from dataduct.connectors.delta.extractor import DeltaExtractor  # noqa: F401
from dataduct.connectors.delta.loader import DeltaLoader  # noqa: F401
```

### 5. Adicionar ao auto-discovery

Em `dataduct/connectors/__init__.py`:

```python
def _ensure_connectors_registered():
    ...
    import dataduct.connectors.delta  # noqa: F401
```

### 6. Usar

```yaml
sources:
  - name: tabela_delta
    format: delta
    path: "s3a://bucket/delta/minha_tabela/"
    version: 5

sinks:
  - name: saida_delta
    format: delta
    path: "s3a://bucket/delta/resultado/"
    mode: overwrite
    partition_by: ["dt_referencia"]
    merge_schema: true
```

---

## Adicionar Novo Serviço de Credenciais

Exemplo: adicionar suporte a **AWS SSM Parameter Store**.

### 1. Criar o módulo

```python
# dataduct/services/credentials_ssm.py
import boto3
from typing import Tuple


def resolve_ssm_credentials(config: dict) -> Tuple[str, str]:
    """Resolve credenciais do AWS SSM Parameter Store."""
    ssm = boto3.client("ssm")

    user_param = config.get("user_param")
    pass_param = config.get("password_param")

    user = ssm.get_parameter(Name=user_param, WithDecryption=True)["Parameter"]["Value"]
    password = ssm.get_parameter(Name=pass_param, WithDecryption=True)["Parameter"]["Value"]

    return user, password
```

### 2. Integrar ao resolve_credentials

```python
# dataduct/services/credentials.py
def resolve_credentials(config: dict) -> Tuple[str, str]:
    if not config:
        return "", ""

    cred_type = config.get("type", "env")

    if cred_type == "env":
        ...
    elif cred_type == "direct":
        ...
    elif cred_type == "ssm":
        from dataduct.services.credentials_ssm import resolve_ssm_credentials
        return resolve_ssm_credentials(config)

    return "", ""
```

### 3. Usar

```yaml
sources:
  - name: banco
    format: jdbc
    url: "jdbc:postgresql://prod-host:5432/db"
    credentials:
      type: ssm
      user_param: "/prod/db/username"
      password_param: "/prod/db/password"
```

---

## Adicionar Suporte a dbt

Para integrar dbt como engine, a abordagem recomendada:

### Conceito

O dbt não é uma engine de processamento como Spark/DuckDB. É um transformador SQL.
A integração faz mais sentido como um **Step (hook)** ou **serviço auxiliar**.

### Opção A: dbt como Step (pré/pós processamento)

```python
# dataduct/services/dbt.py
import subprocess


def run_dbt(job):
    """Executa dbt run como step before do job."""
    project_dir = job.custom.get("dbt_project_dir", ".")
    target = job.custom.get("dbt_target", "dev")

    subprocess.run(
        ["dbt", "run", "--project-dir", project_dir, "--target", target],
        check=True,
    )
```

Uso no job:
```python
class MeuJob(Job):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from dataduct.services.dbt import run_dbt
        self.steps.before(run_dbt)

    def run(self):
        # Dados já transformados pelo dbt
        ...
```

### Opção B: dbt como Engine

```python
@register_engine("dbt")
class DbtEngineAdapter(EngineAdapter):
    """Engine que executa modelos dbt e expõe resultados."""

    def create_session(self, config=None):
        # Inicializa conexão com warehouse alvo do dbt
        ...

    def execute_sql(self, query):
        # Executa no warehouse
        ...

    def read(self, format, **options):
        # Lê modelo materializado
        model = options.get("model")
        return self.execute_sql(f"SELECT * FROM {model}")
```

---

## Checklist para Novas Extensões

### Nova Engine
- [ ] Criar `dataduct/engines/{nome}/adapter.py`
- [ ] Implementar `EngineAdapter` ABC (6 métodos)
- [ ] Decorar com `@register_engine("nome")`
- [ ] Criar `__init__.py` com import
- [ ] Adicionar ao `_ensure_engines_registered()`
- [ ] Adicionar requirements-{nome}.txt se necessário
- [ ] Escrever testes em `tests/engines/test_{nome}.py`

### Novo Conector
- [ ] Criar `dataduct/connectors/{formato}/`
- [ ] Implementar `extractor.py` (herda `BaseExtractor`)
- [ ] Implementar `loader.py` (herda `BaseLoader`)
- [ ] Decorar com `@register_connector("formato", "extractor"/"loader")`
- [ ] Criar `__init__.py` com imports
- [ ] Adicionar ao `_ensure_connectors_registered()`
- [ ] Escrever testes em `tests/connectors/test_{formato}.py`

### Novo Serviço
- [ ] Criar módulo em `dataduct/services/`
- [ ] Usar lazy imports se dependência opcional
- [ ] Integrar via hook (Steps) ou chamada explícita no connector
- [ ] Escrever testes
