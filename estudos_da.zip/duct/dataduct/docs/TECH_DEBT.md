# Débitos Técnicos

Documento vivo com os itens de melhoria pendentes, priorizados por impacto. Atualizado a cada ciclo de desenvolvimento.

**Última revisão**: 2026-07-08
**Versão atual**: 0.1.0

---

## Legenda de Prioridade

| Prioridade | Critério |
|------------|----------|
| 🔴 Alta | Bloqueia uso em produção ou é risco de segurança |
| 🟡 Média | Melhora qualidade/manutenibilidade mas não bloqueia |
| 🟢 Baixa | Nice-to-have, pode esperar |

---

## Pendentes

### 🟡 Credenciais SSM / Vault

**Contexto**: Hoje apenas `env` e `direct` são suportados. Em produção AWS, o padrão é usar SSM Parameter Store.

**Impacto**: Sem SSM, jobs em prod precisam injetar credenciais manualmente como env vars.

**Caminho de implementação**:
```
dataduct/services/credentials_ssm.py
  └── resolve_ssm_credentials(config) → Tuple[str, str]
      ├── boto3.client("ssm")
      ├── get_parameter(Name=config["user_param"], WithDecryption=True)
      └── get_parameter(Name=config["password_param"], WithDecryption=True)
```

Integrar em `services/credentials.py`:
```python
elif cred_type == "ssm":
    from dataduct.services.credentials_ssm import resolve_ssm_credentials
    return resolve_ssm_credentials(config)
```

Uso:
```yaml
credentials:
  type: ssm
  user_param: "/prod/db/username"
  password_param: "/prod/db/password"
```

---

### 🟡 Retry / Resiliência em operações remotas

**Contexto**: JDBC connections, S3 operations e Glue API calls não têm retry. Falhas transientes (timeout, throttle) quebram jobs.

**Impacto**: Jobs em produção podem falhar por problemas temporários de rede.

**Caminho de implementação**:
```
dataduct/utils/retry.py
  └── with_retry(func, max_attempts=3, backoff_seconds=2, exceptions=(Exception,))
```

Aplicar como decorator nos pontos críticos:
- `GlueCatalogProvider.register_table()`
- `GlueCatalogProvider.table_exists()`
- `ObjectStorageExtractor.extract()` (via boto3)
- `JdbcExtractor.extract()` (connection open)

---

### 🟡 Testes de integração AWS (boto3 com moto)

**Contexto**: Os testes de `ObjectStorageExtractor/Loader` e `GlueCatalogProvider` usam mocks simples, não testam o comportamento real da API boto3.

**Impacto**: Bugs de integração com S3/Glue só aparecem em execução real.

**Caminho de implementação**:
```bash
pip install moto[s3,glue]
```

```python
# tests/services/test_catalog_glue_integration.py
import boto3
from moto import mock_aws

@mock_aws
def test_register_table_creates_in_glue():
    ...

# tests/connectors/test_object_storage_integration.py
@mock_aws
def test_extractor_reads_from_s3():
    ...
```

---

### 🟢 Migrar `setup.py` → `pyproject.toml`

**Contexto**: `setup.py` é o formato legado. PEP 517/518/621 definem `pyproject.toml` como padrão moderno.

**Impacto**: Apenas DX — não afeta funcionalidade.

**Ação**: Substituir `setup.py` por `pyproject.toml` com `[build-system]` + `[project]`.

---

### 🟢 `py.typed` marker

**Contexto**: Para que consumers da lib possam usar mypy/pyright com type-checking, é necessário um arquivo `py.typed` na raiz do pacote.

**Ação**:
```bash
touch dataduct/py.typed
```
Adicionar ao `MANIFEST.in`:
```
include dataduct/py.typed
```

---

### 🟢 Cleanup de temp tables DuckDB em erro no masking

**Contexto**: Em `HashMaskingProvider._apply_select()`, se a segunda `session.execute()` falhar, a temp table `__masking_src_{uuid}` pode ficar no banco.

**Impacto**: Baixo — as tabelas são temporárias (TEMP TABLE) e são destruídas ao fechar a conexão. Com UUIDs, não há colisão entre execuções.

**Ação**: Adicionar `try/finally` para garantir cleanup mesmo em erro:
```python
try:
    session.execute(f"CREATE OR REPLACE TEMP TABLE {src_table} AS SELECT * FROM data")
    session.execute(f"CREATE OR REPLACE TEMP TABLE {res_table} AS ...")
finally:
    session.execute(f"DROP TABLE IF EXISTS {src_table}")
```

---

### 🟢 Remover `sys.path.insert` do `conftest.py`

**Contexto**: `tests/conftest.py` tem um `sys.path.insert` que foi necessário antes de `pip install -e .` estar configurado.

**Ação**: Verificar se ainda é necessário com `.venv311` ativo e remover se não for.

---

## Resolvidos (v0.1.0)

| Item | Fase | Resolução |
|------|------|-----------|
| `eval()` RCE em config Jinja2 | 1A | `ast.literal_eval` + `yaml.safe_load` |
| SQL injection DuckDB adapter | 1B | `_sanitize_identifier` + `_validate_path` + allowlist |
| SQL injection Unity/Glue catalog | 1C | `_validate_identifier` regex + escape |
| Credenciais plaintext sem aviso | 1D | Warning em log para `type: direct` |
| Zero logging | 2A | `logging.getLogger(__name__)` em todos os módulos |
| Sem validação de config YAML | 2B | `core/validators.py` com erros cumulativos |
| Job sem try/finally | 2C | `after_save` sempre executa; erros logados |
| DuckDB ignora `mode`/`partition_by` | 2D | Implementado via `COPY ... PARTITION_BY` |
| Mensagens de erro genéricas para deps ausentes | 3A | ImportError com instrução de install |
| Acesso direto a `_catalog_config` | 3B | API pública `set_catalog(config, engine)` |
| Colisão de nomes de temp tables | 3C | UUID sufixo: `__masking_src_{uuid12}` |
| Versão duplicada em dois arquivos | 3D | `importlib.metadata.version()` como source |
| Delta Lake connector | — | `dataduct/connectors/delta/` + testes |
| Sem testes de CLI | 4A | `tests/test_cli.py` com `CliRunner` |
| Sem testes de `config.build()` | 4B | `tests/test_config_extended.py` |
| Sem testes de `JobFactory` / e2e | 4C | `tests/test_job_factory_e2e.py` |
| Sem testes de md5 / edge cases masking | 4D | `tests/services/test_masking_extended.py` |
