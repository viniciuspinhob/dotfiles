# Conectores

Conectores implementam a leitura (extractor) e escrita (loader) de dados em diferentes formatos e sistemas.

## Visão Geral

Cada conector é composto por:
- **Extractor** (`BaseExtractor`): lê dados e retorna o tipo nativo da engine
- **Loader** (`BaseLoader`): recebe dados e persiste no destino

Conectores delegam operações de I/O para o `EngineAdapter`, tornando-os engine-agnostic.

---

## CSV

### Extractor

```yaml
sources:
  - name: vendas
    format: csv
    path: "data/vendas.csv"
    header: true
    delimiter: ","
```

| Opção | Tipo | Default | Descrição |
|-------|------|---------|-----------|
| `path` | str | — | Caminho do arquivo |
| `header` | bool | `true` | Primeira linha é cabeçalho |
| `delimiter` | str | `","` | Separador de campos |

Opções extras são passadas diretamente à engine (ex: `inferSchema`, `encoding`).

### Loader

```yaml
sinks:
  - name: saida
    format: csv
    path: "/output/dados.csv"
    mode: overwrite
    header: true
    delimiter: ";"
    partition_by: ["ano"]
```

| Opção | Tipo | Default | Descrição |
|-------|------|---------|-----------|
| `path` | str | — | Caminho de saída |
| `mode` | str | `"overwrite"` | Modo de escrita (overwrite, append, ignore, error) |
| `header` | bool | `true` | Incluir cabeçalho |
| `delimiter` | str | `","` | Separador |
| `partition_by` | list/str | — | Colunas para particionamento |

---

## Parquet

### Extractor

```yaml
sources:
  - name: dados
    format: parquet
    path: "s3a://bucket/camada/tabela/"
    schema: "id INT, nome STRING, valor DOUBLE"
```

| Opção | Tipo | Default | Descrição |
|-------|------|---------|-----------|
| `path` | str | — | Caminho do(s) arquivo(s) |
| `schema` | str | — | Schema DDL para forçar tipos |

### Loader

```yaml
sinks:
  - name: resultado
    format: parquet
    path: "/output/resultado/"
    mode: overwrite
    partition_by: ["dt_referencia"]
```

| Opção | Tipo | Default | Descrição |
|-------|------|---------|-----------|
| `path` | str | — | Caminho de saída |
| `mode` | str | `"overwrite"` | Modo (overwrite, append, ignore, error) |
| `partition_by` | list/str | — | Colunas para particionamento |

---

## JDBC

Conecta a bancos de dados relacionais (PostgreSQL, MySQL, SQL Server, Oracle, etc).

### Extractor

```yaml
sources:
  - name: clientes
    format: jdbc
    url: "jdbc:postgresql://localhost:5432/mydb"
    driver: "org.postgresql.Driver"
    table: "public.clientes"
    credentials:
      type: env
      user_var: "DB_USER"
      password_var: "DB_PASS"
```

Com query customizada:
```yaml
sources:
  - name: clientes_ativos
    format: jdbc
    url: "jdbc:postgresql://localhost:5432/mydb"
    driver: "org.postgresql.Driver"
    query: "SELECT * FROM clientes WHERE ativo = true"
    credentials:
      type: direct
      user: "admin"
      password: "secret123"
```

| Opção | Tipo | Default | Descrição |
|-------|------|---------|-----------|
| `url` | str | — | JDBC connection URL |
| `driver` | str | — | Classe do driver JDBC |
| `table` | str | — | Tabela para ler (mutuamente exclusivo com `query`) |
| `query` | str | — | SQL query customizada |
| `credentials` | dict | — | Configuração de credenciais (ver abaixo) |

### Loader

```yaml
sinks:
  - name: resultado
    format: jdbc
    url: "jdbc:postgresql://localhost:5432/mydb"
    driver: "org.postgresql.Driver"
    table: "public.resultado"
    mode: append
    credentials:
      type: env
      user_var: "DB_USER"
      password_var: "DB_PASS"
```

| Opção | Tipo | Default | Descrição |
|-------|------|---------|-----------|
| `url` | str | — | JDBC connection URL |
| `driver` | str | — | Classe do driver JDBC |
| `table` | str | — | Tabela destino |
| `mode` | str | `"append"` | Modo (append, overwrite, ignore, error) |
| `credentials` | dict | — | Configuração de credenciais |

### Credenciais

```yaml
# Tipo 1: Variáveis de ambiente
credentials:
  type: env
  user_var: "DB_USER"         # Nome da env var com username
  password_var: "DB_PASS"     # Nome da env var com password

# Tipo 2: Direto (apenas dev local)
credentials:
  type: direct
  user: "admin"
  password: "secret123"
```

---

## Object Storage (S3 / MinIO)

Conecta a armazenamento de objetos compatível com S3.

### Extractor

```yaml
# Via engine (Spark com s3a://)
sources:
  - name: dados_lake
    format: object_storage
    bucket: "dataduct-curated"
    key: "vendas/dt_referencia=2024-01-01/"
    file_format: parquet

# Via boto3 (MinIO ou endpoint customizado)
sources:
  - name: dados_minio
    format: object_storage
    bucket: "my-bucket"
    key: "data/arquivo.parquet"
    file_format: parquet
    endpoint_url: "http://localhost:9000"
    credentials:
      type: env
      user_var: "MINIO_ACCESS_KEY"
      password_var: "MINIO_SECRET_KEY"
```

| Opção | Tipo | Default | Descrição |
|-------|------|---------|-----------|
| `bucket` | str | — | Nome do bucket |
| `key` | str | — | Caminho do objeto (alias: `path`) |
| `file_format` | str | `"parquet"` | Formato do arquivo (parquet, csv, json) |
| `endpoint_url` | str | — | URL do endpoint (para MinIO/localstack) |
| `credentials` | dict | — | Credenciais de acesso |

**Comportamento**:
- Sem `endpoint_url`: usa `s3a://` via engine (Spark) — ideal para produção
- Com `endpoint_url`: usa boto3 diretamente — ideal para dev local com MinIO

### Loader

```yaml
sinks:
  - name: saida_s3
    format: object_storage
    bucket: "dataduct-curated"
    key: "vendas/processado/"
    file_format: parquet
    mode: overwrite
    partition_by: ["ano", "mes"]

# Com MinIO
sinks:
  - name: saida_minio
    format: object_storage
    bucket: "output-bucket"
    key: "resultado.parquet"
    file_format: parquet
    endpoint_url: "http://localhost:9000"
    credentials:
      type: env
      user_var: "MINIO_ACCESS_KEY"
      password_var: "MINIO_SECRET_KEY"
```

| Opção | Tipo | Default | Descrição |
|-------|------|---------|-----------|
| `bucket` | str | — | Nome do bucket |
| `key` | str | — | Caminho do objeto |
| `file_format` | str | `"parquet"` | Formato (parquet, csv) |
| `mode` | str | `"overwrite"` | Modo de escrita |
| `endpoint_url` | str | — | Endpoint customizado |
| `partition_by` | list/str | — | Particionamento (apenas via engine) |
| `credentials` | dict | — | Credenciais de acesso |

---

## Factory Pattern

Conectores são resolvidos automaticamente pelo campo `format`:

```
config.yaml → format: "csv" → ExtractorFactory → CsvExtractor
config.yaml → format: "parquet" → LoaderFactory → ParquetLoader
```

Registro é feito via decorator:

```python
@register_connector("csv", "extractor")
class CsvExtractor(BaseExtractor):
    ...

@register_connector("csv", "loader")
class CsvLoader(BaseLoader):
    ...
```

## Listar conectores disponíveis

```python
from dataduct.core.registry import list_connectors

print(list_connectors("extractor"))
# {'csv': CsvExtractor, 'parquet': ParquetExtractor, 'jdbc': JdbcExtractor, 'object_storage': ObjectStorageExtractor}

print(list_connectors("loader"))
# {'csv': CsvLoader, 'parquet': ParquetLoader, 'jdbc': JdbcLoader, 'object_storage': ObjectStorageLoader}
```
