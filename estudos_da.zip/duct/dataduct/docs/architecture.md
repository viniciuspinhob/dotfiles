# Arquitetura

## Visão Geral

O dataduct é organizado em 5 camadas com dependências unidirecionais (camadas superiores dependem das inferiores, nunca o contrário):

```
┌──────────────────────────────────────────────────────────────────┐
│                      CLI (__main__.py)                           │
│              --job --env --engine --custom --verbose             │
├──────────────────────────────────────────────────────────────────┤
│                           CORE                                   │
│   ┌───────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────────┐   │
│   │  Config   │ │   Job    │ │ Registry │ │    Validators    │   │
│   │ (YAML +   │ │ (ABC +   │ │ (plugin  │ │ (schema check    │   │
│   │  Jinja2)  │ │  Steps)  │ │  lookup) │ │  before run)     │   │
│   └───────────┘ └──────────┘ └──────────┘ └──────────────────┘   │
├──────────────────────────────────────────────────────────────────┤
│           ENGINES                       CONNECTORS               │
│   ┌──────────────────────┐   ┌──────────────────────────────┐    │
│   │  EngineAdapter (ABC) │   │  BaseExtractor (ABC)         │    │
│   │  ├── Spark (3.5.x)   │   │  BaseLoader (ABC)            │    │
│   │  └── DuckDB (1.5.x)  │   │  ├── CSV                     │    │
│   └──────────────────────┘   │  ├── Parquet                 │    │
│                              │  ├── JDBC                    │    │
│                              │  └── Object Storage (S3)     │    │
│                              └──────────────────────────────┘    │
├──────────────────────────────────────────────────────────────────┤
│                         SERVICES                                 │
│  ┌──────────────┐  ┌────────────────────┐  ┌──────────────────┐  │
│  │ Credentials  │  │  Masking           │  │  Catalog         │  │
│  │ (env / warn) │  │  ├── HashProvider  │  │  ├── Glue        │  │
│  └──────────────┘  │  └── (extensível)  │  │  ├── Unity       │  │
│                    └────────────────────┘  │  └── (extensível)│  │
│                                            └──────────────────┘  │
├──────────────────────────────────────────────────────────────────┤
│                           UTILS                                  │
│   ┌──────────────────────────────────────────────────────────┐   │
│   │  Bunch (dict com acesso por atributo)                    │   │
│   └──────────────────────────────────────────────────────────┘   │
└──────────────────────────────────────────────────────────────────┘
```

---

## Fluxo de Execução Completo

```
CLI: python -m dataduct [--verbose] run --job X --env Y --engine Z --custom '{}'
│
├── 1. Logging configurado
│       ├── --verbose → DEBUG (todos os módulos)
│       └── default  → INFO (py4j/pyspark silenciados)
│
├── 2. json.loads(--custom) → custom_args dict
│       └── JSONDecodeError → sys.exit(1) com mensagem clara
│
├── 3. JobFactory.build_config(job_package, custom, env)
│       ├── _build_package_tree("a.b.c") → ["a.b.c", "a.b", "a"]
│       ├── Para cada pacote (raiz → folha):
│       │     ├── Lê config.yaml (se existir)
│       │     └── Overlay config-{env}.yaml (se --env fornecido)
│       ├── deep_merge_dict() — child sobrescreve parent
│       │     ├── dicts: merge recursivo
│       │     └── listas: match por campo "name", merge item a item
│       ├── _apply_args_to_configs() — renderiza Jinja2
│       │     ├── ast.literal_eval() — parse seguro (sem eval())
│       │     └── yaml.safe_load() — fallback seguro
│       └── validate_config() — valida campos obrigatórios e tipos
│               └── ConfigError se inválido (todos os erros juntos)
│
├── 4. Se --dry-run: imprime JSON do config e termina
│
├── 5. load_engine(engine_name, engine_config)
│       ├── _ensure_engines_registered() (guard: uma vez só)
│       ├── get_engine(name) → EngineAdapter class
│       │     └── ImportError amigável se dep não instalada
│       ├── engine_cls()
│       └── engine.create_session(config)
│
├── 6. JobFactory.get(config, engine, dry_run)
│       ├── importlib.import_module("{package}.job")
│       │     └── JobNotFound se módulo não existe
│       └── Encontra subclasse de Job via inspect.getmembers()
│
├── 7. job.execute()                          ← try/finally garantido
│       ├── register_sources(config.sources)
│       │     ├── cfg.pop("name") — obrigatório, KeyError → ValueError claro
│       │     ├── cfg.pop("masking", None) — extraído antes de passar ao factory
│       │     ├── ExtractorFactory.get(cfg, engine) → BaseExtractor
│       │     │     └── _ensure_connectors_registered() (guard: uma vez só)
│       │     ├── extractor.extract() → DataFrame/Relation
│       │     ├── [SE masking] apply_masking(data, config, engine)
│       │     │     └── HashMaskingProvider: tabelas temp com UUID (sem colisão)
│       │     ├── self._sources[name] = data
│       │     └── _register_as_view(name, data)
│       │           ├── Spark: df.createOrReplaceTempView(name)
│       │           └── DuckDB: session.register(name, relation)
│       │
│       ├── register_sinks(config.sinks)
│       │     ├── cfg.pop("catalog", None)
│       │     ├── LoaderFactory.get(cfg, engine) → BaseLoader
│       │     └── [SE catalog] loader.set_catalog(config, engine)
│       │
│       ├── steps.run_before(job)
│       ├── job.run()                         ← lógica do usuário
│       ├── steps.run_after(job)
│       │
│       └── [finally] para cada sink:
│               ├── loader.after_save()
│               │     └── [SE catalog configurado E data não-nula]
│               │           └── apply_catalog(data, config, path, engine, partition_by)
│               └── exceções logadas mas não re-lançadas
│
└── 8. engine.stop_session()                  ← no bloco finally da CLI
```

---

## Design Patterns

| Pattern | Onde | Propósito |
|---------|------|-----------|
| **Abstract Factory** | `ExtractorFactory`, `LoaderFactory` | Cria conectores a partir do campo `format` |
| **Registry** | `core/registry.py` | Registra engines e conectores via decorators |
| **Strategy** | `EngineAdapter` ABC | Troca engine sem alterar código do job |
| **Template Method** | `Job.execute()` | Ciclo de vida fixo com extensão via hooks |
| **Plugin** | `@register_engine`, `@register_connector` | Extensão sem modificar código existente |
| **Lazy Loading** | Engines, connectors, serviços | Deps opcionais importadas no momento de uso |
| **Guard Clause** | `_ensure_*_registered()` | Registra plugins uma única vez por processo |

---

## Segurança

### Jinja2 / Config

O sistema de config renderiza templates Jinja2 usando apenas parsers seguros:

```python
# ANTES (vulnerável — execução arbitrária de código)
eval(rendered)

# DEPOIS (seguro)
ast.literal_eval(rendered)   # parse de literais Python
yaml.safe_load(rendered)     # fallback: parse YAML seguro
```

Nenhuma forma de executar código Python arbitrário via config.

### SQL — DuckDB

Paths e identificadores são sanitizados antes de usar em SQL:

```python
def _sanitize_identifier(value: str) -> str:
    safe = value.replace("'", "''")   # escapa aspas simples
    return safe

def _validate_path(path: str) -> str:
    normalized = os.path.normpath(path)
    if ".." in normalized.split(os.sep):
        raise ValueError(f"Path traversal not allowed: {path!r}")
    return path
```

### SQL — Catalog (Unity/Glue)

Nomes de databases, tabelas e schemas são validados por regex antes de usar em SQL:

```python
_IDENTIFIER_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")

def _validate_identifier(value: str, field: str) -> str:
    if not _IDENTIFIER_RE.match(value):
        raise ValueError(f"Catalog {field} {value!r} contains invalid characters.")
    return value
```

### DuckDB Settings Whitelist

Configurações SET do DuckDB só são aceitas se estiverem na allowlist:

```python
_ALLOWED_SETTINGS = {
    "threads", "memory_limit", "temp_directory", "max_memory",
    "worker_threads", "enable_progress_bar",
}
```

### Credenciais

```yaml
# SEGURO — lê de variável de ambiente
credentials:
  type: env
  user_var: "DB_USER"
  password_var: "DB_PASS"

# EVITAR EM PRODUÇÃO — gera WARNING no log
credentials:
  type: direct
  user: "admin"
  password: "secret"   # WARNING: plaintext in config
```

---

## Observabilidade (Logging)

Todos os módulos usam `logging.getLogger(__name__)`. O nível é controlado pela CLI:

```bash
# INFO (default) — mostra início/fim de jobs, warnings
python -m dataduct run --job X

# DEBUG — mostra cada read/write, SQL executado, config final
python -m dataduct --verbose run --job X
```

Hierarquia de loggers:

```
dataduct
├── dataduct.cli
├── dataduct.core.config
├── dataduct.core.job.base
├── dataduct.core.validators
├── dataduct.engines.spark.adapter
├── dataduct.engines.duckdb.adapter
├── dataduct.connectors
├── dataduct.services.masking.hash
├── dataduct.services.catalog.glue
└── dataduct.services.catalog.unity
```

Em modo DEBUG com Spark, `py4j` e `pyspark` são silenciados automaticamente para reduzir ruído.

---

## Validação de Config

`core/validators.py` valida o config **antes de executar** qualquer operação. Todos os erros são coletados e reportados juntos:

```
ConfigError: Config validation failed:
  - sources[0]: missing required field 'name'
  - sources[1].masking.provider: must be one of ['hash'], got 'faker'
  - sinks[0].catalog: missing required field 'table_name'
  - engine: must be one of ['duckdb', 'spark'], got 'polars'
```

O que é validado:

| Campo | Validação |
|-------|-----------|
| `sources` / `sinks` | Ao menos um deve existir |
| `source.name` | Obrigatório |
| `source.format` | Obrigatório |
| `sink.name` | Obrigatório |
| `sink.format` | Obrigatório |
| `engine` | Deve ser `spark` ou `duckdb` se fornecido |
| `masking.provider` | Deve ser `hash` |
| `masking.columns[].column` | Cada coluna deve ter campo `column` |
| `catalog.provider` | Deve ser `glue` ou `unity` |
| `catalog.database` | Obrigatório se catalog presente |
| `catalog.table_name` | Obrigatório se catalog presente |

---

## Error Handling

### No Job.execute()

```python
def execute(self) -> None:
    try:
        self.register_sources(...)
        self.register_sinks(...)
        self._steps.run_before(self)
        self.run()
        self._steps.run_after(self)
    except Exception:
        logger.exception("Job '%s' failed during execution", job_name)
        raise  # re-lança para propagar até a CLI
    finally:
        # SEMPRE executa — mesmo se run() falhar
        for name, loader in self._sinks.items():
            try:
                loader.after_save()   # catalog registration
            except Exception:
                logger.exception("after_save failed for sink '%s'", name)
                # NÃO re-lança — evita mascarar o erro original
```

### Na CLI

```python
try:
    job_instance.execute()
except Exception as exc:
    click.echo(f"Error executing job: {exc}", err=True)
    sys.exit(1)
finally:
    engine_instance.stop_session()   # sempre libera recursos
```

---

## Módulos e Responsabilidades

| Módulo | Responsabilidade |
|--------|-----------------|
| `core/config.py` | Parse YAML, merge hierárquico, Jinja2 seguro |
| `core/validators.py` | Validação de schema antes de executar |
| `core/registry.py` | Registro global de engines e connectors |
| `core/job/base.py` | Ciclo de vida do job, hooks, registro de sources/sinks |
| `core/job/factory.py` | Resolve package → config → Job instance |
| `engines/base.py` | EngineAdapter ABC |
| `engines/spark/` | SparkEngineAdapter (PySpark 3.5.x) |
| `engines/duckdb/` | DuckDBEngineAdapter (mode, partition_by, settings) |
| `connectors/base.py` | BaseExtractor, BaseLoader com set_catalog() público |
| `connectors/*/` | Extractor + Loader por formato |
| `services/credentials.py` | Resolução de credenciais (env vars, direct) |
| `services/masking/` | Anonimização PII declarativa (hash one-way) |
| `services/catalog/` | Registro em catálogos de metadados (Glue, Unity) |
| `utils/bunch.py` | Dict com acesso por atributo |
| `__main__.py` | CLI, logging config, error handling |
