# Sistema de Configuração

O dataduct usa YAML como formato de configuração, com suporte a herança hierárquica, overlays por ambiente e templating Jinja2.

## Estrutura de um Job

```
meu_dominio/
├── __init__.py
├── config.yaml              # Config base (produção)
├── config-dev.yaml          # Overlay para desenvolvimento
├── config-uat.yaml          # Overlay para homologação
│
└── meu_job/
    ├── __init__.py
    ├── config.yaml          # Config específica do job
    ├── config-dev.yaml      # Overlay dev do job
    └── job.py               # Lógica do job
```

## Formato do config.yaml

```yaml
# Obrigatórios
type: python                   # Tipo do job (apenas python na v1)
engine: duckdb                 # Engine de processamento (spark | duckdb)

sources:                       # Lista de fontes de dados
  - name: nome_da_fonte       # Nome para acessar via self.sources.nome_da_fonte
    format: csv                # Tipo do conector (csv | parquet | jdbc | object_storage)
    # ... opções específicas do conector

sinks:                         # Lista de destinos
  - name: nome_do_destino     # Nome para acessar via self.sinks.nome_do_destino
    format: parquet            # Tipo do conector
    # ... opções específicas do conector

# Opcionais
engine_config:                 # Configuração da engine
  master: "local[*]"          # (Spark) master URL
  conf:                        # (Spark) configurações adicionais
    spark.sql.adaptive.enabled: "true"
  database: ":memory:"         # (DuckDB) caminho do banco

custom:                        # Variáveis customizadas
  dominio: "vendas"
  dt_referencia: "2024-01-01"
```

## Hierarquia de Merge

A configuração é construída por deep merge, da mais genérica para a mais específica:

```
Prioridade (baixa → alta):

1. DEFAULT_CONFIG (vazio)
2. Config do pacote raiz         (meu_dominio/config.yaml)
3. Config do pacote intermediário (se existir)
4. Config do job                 (meu_dominio/meu_job/config.yaml)
5. Overlay de ambiente           (config-{env}.yaml em cada nível)
6. Orchestration args            (--custom via CLI)
```

### Exemplo prático

**meu_dominio/config.yaml** (config do domínio):
```yaml
engine: spark
engine_config:
  master: "local[*]"

custom:
  dominio: "vendas"
```

**meu_dominio/meu_job/config.yaml** (config do job):
```yaml
type: python

sources:
  - name: dados
    format: parquet
    path: "s3://bucket/{{ dominio }}/raw/"

sinks:
  - name: resultado
    format: parquet
    path: "s3://bucket/{{ dominio }}/curated/"
    mode: overwrite
```

**meu_dominio/meu_job/config-dev.yaml** (overlay dev):
```yaml
engine: duckdb
engine_config:
  database: ":memory:"

sources:
  - name: dados
    path: "./data/local/vendas.parquet"

sinks:
  - name: resultado
    path: "/tmp/output/"
```

**Resultado final (env=dev)**:
```yaml
type: python
engine: duckdb
engine_config:
  database: ":memory:"
sources:
  - name: dados
    format: parquet
    path: "./data/local/vendas.parquet"
sinks:
  - name: resultado
    format: parquet
    path: "/tmp/output/"
    mode: overwrite
custom:
  dominio: "vendas"
```

## Regras de Merge

### Dicionários
Merge recursivo. Valores do child sobrescrevem o parent:
```yaml
# Parent: {a: 1, b: {x: 10, y: 20}}
# Child:  {b: {y: 99, z: 30}}
# Result: {a: 1, b: {x: 10, y: 99, z: 30}}
```

### Listas de dicts
Match por campo `name`. Merge item a item:
```yaml
# Parent sources:
#   - name: src1, format: csv, path: /old
# Child sources:
#   - name: src1, path: /new
# Result:
#   - name: src1, format: csv, path: /new
```

Itens no child que não existem no parent são adicionados.

## Jinja2 Templating

As seções `sources`, `sinks` e `engine_config` suportam Jinja2 templates:

```yaml
sources:
  - name: dados
    format: parquet
    path: "s3://{{ env_var('BUCKET_NAME') }}/{{ dominio }}/{{ dt_referencia }}/"
```

### Funções disponíveis

| Função | Descrição | Exemplo |
|--------|-----------|---------|
| `env_var(name, default)` | Lê variável de ambiente | `{{ env_var('DB_HOST', 'localhost') }}` |
| `get_env_var(name, default)` | Alias de env_var | `{{ get_env_var('API_KEY') }}` |

### Variáveis disponíveis

Todas as chaves em `custom` ficam disponíveis como variáveis Jinja2:

```yaml
custom:
  dominio: "vendas"
  ano: "2024"

sources:
  - name: dados
    path: "/data/{{ dominio }}/{{ ano }}/"   # → /data/vendas/2024/
```

Variáveis passadas via `--custom` na CLI têm precedência sobre as do YAML.

## CLI e Custom Args

```bash
# Custom args via JSON
python -m dataduct run --job meu.job \
  --env prod \
  --custom '{"dt_referencia": "2024-06-15", "modo": "full"}'

# Dry-run: mostra config final sem executar
python -m dataduct run --job meu.job --env dev --dry-run
```

## Campos Automáticos

O config final inclui campos injetados automaticamente:

| Campo | Valor |
|-------|-------|
| `job_package_name` | Nome completo do pacote do job |
| `dt_execution` | ISO timestamp da execução |

## Validação Automática

O config é validado automaticamente **antes de qualquer execução** via `core/validators.py`. Todos os erros são coletados e reportados juntos numa única exceção `ConfigError`:

```
ConfigError: Config validation failed:
  - sources[0]: missing required field 'name'
  - sources[1].masking.provider: must be one of ['hash'], got 'faker'
  - sinks[0].catalog: missing required field 'table_name'
  - engine: must be one of ['duckdb', 'spark'], got 'polars'
```

### O que é validado

| Campo | Regra |
|-------|-------|
| `sources` / `sinks` | Ao menos um deve estar presente |
| `source.name` | Obrigatório em cada source |
| `source.format` | Obrigatório em cada source |
| `sink.name` | Obrigatório em cada sink |
| `sink.format` | Obrigatório em cada sink |
| `engine` | Deve ser `spark` ou `duckdb` se fornecido |
| `masking.provider` | Deve ser `hash` (providers disponíveis) |
| `masking.columns[].column` | Cada item deve ter campo `column` |
| `catalog.provider` | Deve ser `glue` ou `unity` |
| `catalog.database` | Obrigatório quando `catalog` está presente |
| `catalog.table_name` | Obrigatório quando `catalog` está presente |

Use `--dry-run` para validar sem executar e inspecionar o config final:

```bash
python -m dataduct run --job meu.job --env dev --dry-run
```

## Segurança no Jinja2

O dataduct **não usa `eval()`** para renderizar templates. A renderização é feita com parsers seguros em sequência:

```
Jinja2 render → ast.literal_eval() → yaml.safe_load() → string pura
```

Isso garante que mesmo um config YAML malicioso ou um `--custom` com conteúdo arbitrário **não pode executar código Python**.

```yaml
# SEGURO: renderiza para string literal
path: "s3://{{ env_var('BUCKET') }}/dados/"

# SEGURO: renderiza para lista de dicts
sources: "{{ minhas_sources }}"   # ← ast.literal_eval faz parse seguro

# NÃO EXECUTA: ignorado como string
path: "__import__('os').system('rm -rf /')"   # retorna a própria string
```

## CLI e Custom Args

```bash
# Custom args via JSON (sobrescreve valores do YAML)
python -m dataduct run --job meu.job \
  --env prod \
  --custom '{"dt_referencia": "2024-06-15", "modo": "full"}'

# Dry-run: valida config + mostra JSON final sem executar
python -m dataduct run --job meu.job --env dev --dry-run

# Verbose: mostra config completo no log durante execução
python -m dataduct --verbose run --job meu.job
```

## Campos Automáticos

O config final inclui campos injetados automaticamente:

| Campo | Valor |
|-------|-------|
| `job_package_name` | Nome completo do pacote do job |
| `dt_execution` | ISO timestamp UTC da execução (ex: `2024-06-15T14:30+00:00`) |
