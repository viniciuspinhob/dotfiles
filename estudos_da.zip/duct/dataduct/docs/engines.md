# Engines

Engines são o motor de processamento do dataduct. Cada engine implementa a interface `EngineAdapter` e fornece capacidades de leitura, escrita e execução SQL.

## EngineAdapter ABC

```python
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class EngineAdapter(ABC):
    @abstractmethod
    def create_session(self, config: Optional[Dict] = None) -> Any:
        """Inicializa a sessão de processamento."""

    @abstractmethod
    def stop_session(self):
        """Encerra a sessão e libera recursos."""

    @abstractmethod
    def read(self, format: str, **options) -> Any:
        """Lê dados no formato especificado. Retorna o tipo nativo da engine."""

    @abstractmethod
    def write(self, data: Any, format: str, **options) -> None:
        """Escreve dados no formato especificado."""

    @abstractmethod
    def execute_sql(self, query: str) -> Any:
        """Executa uma query SQL e retorna o resultado."""

    @property
    @abstractmethod
    def session(self) -> Any:
        """Referência à sessão ativa."""
```

## SparkEngineAdapter

Engine baseada em Apache Spark. Ideal para workloads distribuídos e integração com ecossistema Hadoop/S3.

### Instalação

```bash
pip install pyspark==3.5.3
```

> **Versão validada**: PySpark 3.5.3 com Python 3.11. Versões anteriores do Python (< 3.11) e mais recentes (> 3.13) podem ter incompatibilidades de serialização.
> Lembre-se de configurar `spark.driver.bindAddress: localhost` em ambientes locais macOS.

### Configuração

```yaml
engine: spark
engine_config:
  app_name: "meu-job"
  master: "local[*]"          # local[N], yarn, k8s://..., spark://...
  conf:
    spark.sql.adaptive.enabled: "true"
    spark.driver.bindAddress: "localhost"   # obrigatório em macOS local
    spark.driver.host: "localhost"          # obrigatório em macOS local
    spark.sql.sources.partitionOverwriteMode: "dynamic"
  packages:
    - "io.delta:delta-spark_2.12:3.1.0"
  jars:
    - "s3://bucket/libs/custom.jar"
```

### Parâmetros de engine_config

| Parâmetro | Tipo | Default | Descrição |
|-----------|------|---------|-----------|
| `app_name` | str | `"dataduct"` | Nome da aplicação Spark |
| `master` | str | — | Spark master URL |
| `conf` | dict | `{}` | Configurações spark.* |
| `packages` | list | `[]` | Maven packages (spark.jars.packages) |
| `jars` | list | `[]` | JARs extras (spark.jars) |

### Tipos de retorno

- `read()` → `pyspark.sql.DataFrame`
- `execute_sql()` → `pyspark.sql.DataFrame`

### Exemplo de uso direto

```python
from dataduct.engines.spark.adapter import SparkEngineAdapter

engine = SparkEngineAdapter()
engine.create_session({
    "app_name": "analise",
    "master": "local[4]",
    "conf": {"spark.driver.bindAddress": "localhost"},
})

df = engine.read("parquet", path="s3a://bucket/data/")
result = engine.execute_sql("SELECT count(*) FROM table")
engine.write(df, "parquet", path="/output/", mode="overwrite", partition_by=["ano"])

engine.stop_session()
```

---

## DuckDBEngineAdapter

Engine baseada em DuckDB. Ideal para processamento local, prototipagem rápida e workloads analíticos single-node.

### Instalação

```bash
pip install duckdb>=0.10 pyarrow>=15.0
```

### Configuração

```yaml
engine: duckdb
engine_config:
  database: ":memory:"        # ou caminho para arquivo .duckdb
  extensions:
    - "httpfs"
    - "postgres_scanner"
  settings:
    threads: "4"
    memory_limit: "2GB"
```

### Parâmetros de engine_config (DuckDB)

| Parâmetro | Tipo | Default | Descrição |
|-----------|------|---------|-----------|
| `database` | str | `":memory:"` | Caminho do banco (`:memory:` para in-memory) |
| `extensions` | list | `[]` | Extensões DuckDB para instalar/carregar |
| `settings` | dict | `{}` | Configurações SET do DuckDB (ver allowlist abaixo) |

### Settings permitidos (allowlist de segurança)

Por segurança, apenas as seguintes chaves são aceitas em `settings`:

| Setting | Exemplo | Descrição |
|---------|---------|-----------|
| `threads` | `"4"` | Número de threads de processamento |
| `memory_limit` | `"4GB"` | Limite de memória |
| `temp_directory` | `"/tmp/duckdb"` | Diretório para arquivos temporários |
| `max_memory` | `"8GB"` | Memória máxima |
| `worker_threads` | `"2"` | Threads para workers |
| `enable_progress_bar` | `"true"` | Barra de progresso |

Chaves fora dessa lista lançam `ValueError` imediatamente.

### Modo de escrita (`mode`)

| Modo | Comportamento |
|------|--------------|
| `overwrite` (default) | Substitui o arquivo/diretório completamente |
| `append` | Para Parquet: lê existente + novo, re-escreve combinado |

> **Nota**: DuckDB não suporta `append` nativo em arquivo único. O modo `append` para Parquet é implementado via merge temporário.

### Particionamento (`partition_by`)

```yaml
sinks:
  - name: resultado
    format: parquet
    path: "/output/resultado/"
    partition_by: ["ano", "mes"]   # lista ou string
```

DuckDB usa `PARTITION_BY` do `COPY` command. O diretório de saída conterá subdiretórios por partição.

### Formatos suportados nativamente

| Formato | read | write |
|---------|------|-------|
| CSV | `read_csv()` | `COPY ... FORMAT CSV` |
| Parquet | `read_parquet()` | `COPY ... FORMAT PARQUET` |
| JSON | `read_json()` | `COPY ... FORMAT JSON` |

### Tipos de retorno

- `read()` → `duckdb.DuckDBPyRelation`
- `execute_sql()` → `duckdb.DuckDBPyRelation`

### Exemplo de uso direto

```python
from dataduct.engines.duckdb.adapter import DuckDBEngineAdapter

engine = DuckDBEngineAdapter()
engine.create_session({"database": ":memory:"})

data = engine.read("csv", path="data/vendas.csv", header=True, delimiter=",")
result = engine.execute_sql("SELECT cidade, SUM(valor) FROM vendas GROUP BY cidade")
engine.write(result, "parquet", path="/tmp/resumo.parquet")

engine.stop_session()
```

---

## Seleção de Engine

### Via config.yaml

```yaml
engine: duckdb   # ou spark
```

### Via CLI (override)

```bash
python -m dataduct run --job meu.job --engine spark
```

O `--engine` da CLI tem precedência sobre o YAML.

### Quando usar cada engine

| Cenário | Engine recomendada |
|---------|-------------------|
| Desenvolvimento local / prototipagem | DuckDB |
| Dados < 10GB single-node | DuckDB |
| Pipelines distribuídos / cluster | Spark |
| Integração com ecossistema Hadoop/S3 nativo | Spark |
| Testes unitários rápidos | DuckDB |
| Produção em EMR/Dataproc/K8s | Spark |

---

## Registro de Views

Quando um job registra sources, o framework automaticamente registra os dados como views na engine:

- **Spark**: `df.createOrReplaceTempView(name)`
- **DuckDB**: `session.register(name, relation)`

Isso permite usar SQL diretamente referenciando sources pelo nome:

```python
class MeuJob(Job):
    def run(self):
        # self.sources.vendas já está registrado como view "vendas"
        result = self.engine.execute_sql("""
            SELECT cidade, SUM(valor) as total
            FROM vendas
            WHERE ano = '2024'
            GROUP BY cidade
        """)
        self.sinks.resumo.save(result)
```
