# Serviços (Services)

Serviços são módulos transversais que se integram ao pipeline de forma **declarativa via YAML**, sem exigir alterações no `job.py`. São ativados automaticamente quando a configuração correspondente está presente no `config.yaml`.

---

## Visão Geral

```
┌─────────────────────────────────────────────────────────┐
│                     Job.execute()                        │
│                                                          │
│  register_sources()                                      │
│    ├── extractor.extract() → dados brutos               │
│    └── [SE source.masking] → apply_masking() → mascarado│
│                                                          │
│  steps.run_before(job)                                   │
│  job.run()                                               │
│  steps.run_after(job)                                    │
│                                                          │
│  for loader in sinks:                                    │
│    ├── loader.save(data)                                 │
│    └── loader.after_save()                               │
│          └── [SE sink.catalog] → apply_catalog()        │
└─────────────────────────────────────────────────────────┘
```

---

## Masking (Anonimização PII)

O módulo de masking aplica transformações de anonimização em colunas sensíveis **após a extração** dos dados, antes de disponibilizá-los para o `job.run()`.

### Configuração

```yaml
sources:
  - name: clientes
    format: parquet
    path: "s3a://bucket/raw/clientes/"
    masking:
      provider: hash          # Provedor de masking (padrão: hash)
      columns:
        - column: cpf
          algorithm: sha256   # sha256 (padrão) ou md5
        - column: email
          algorithm: sha256
        - column: telefone
          algorithm: sha256
```

### Comportamento

- Colunas listadas em `columns` são substituídas por seu hash
- Colunas **não** listadas passam intactas
- O masking é **irreversível** (one-way hash)
- Determinístico: o mesmo valor sempre produz o mesmo hash
- Engine-agnostic: funciona com Spark e DuckDB

### Provedores disponíveis

| Provider | Algoritmos | Descrição |
|----------|-----------|-----------|
| `hash` | sha256, md5 | Hash criptográfico one-way |

### HashMaskingProvider

Implementação padrão. Usa SQL nativo da engine para aplicar o hash:

- **DuckDB**: `sha256(cast(coluna as varchar))`
- **Spark**: `sha2(cast(coluna as string), 256)`

#### Resultado

| Input | Output (sha256) |
|-------|-----------------|
| `"alice@example.com"` | `"ff8d9819fc0e12..."` (64 chars hex) |
| `"123.456.789-00"` | `"a1b2c3d4e5f6..."` (64 chars hex) |

### API programática

```python
from dataduct.services.masking import apply_masking, get_masking_provider

# Via helper (forma recomendada)
masked_data = apply_masking(
    data=df,
    masking_config={
        "provider": "hash",
        "columns": [
            {"column": "cpf", "algorithm": "sha256"},
            {"column": "email", "algorithm": "sha256"},
        ],
    },
    engine=engine,
)

# Via provider diretamente
from dataduct.services.masking.hash import HashMaskingProvider
provider = HashMaskingProvider()
masked = provider.mask(df, [{"column": "cpf", "algorithm": "sha256"}], engine=engine)
```

### Registrar provider customizado

```python
from dataduct.services.masking.base import MaskingProvider
from dataduct.services.masking import register_masking_provider


class FakerMaskingProvider(MaskingProvider):
    def mask(self, data, columns_config, engine=None):
        # Substitui por dados fictícios com Faker
        ...

    def unmask(self, data, columns_config, engine=None):
        raise NotImplementedError("Faker masking is irreversible")


register_masking_provider("faker", FakerMaskingProvider)
```

Uso no YAML:
```yaml
masking:
  provider: faker
  columns:
    - column: nome
    - column: endereco
```

---

## Catalog (Catalogação de Tabelas)

O módulo de catalog registra/atualiza tabelas em catálogos de metadados **após o salvamento** de cada sink.

### Configuração

```yaml
sinks:
  - name: clientes_curated
    format: parquet
    path: "s3a://bucket/curated/clientes/"
    mode: overwrite
    partition_by: ["dt_referencia"]
    catalog:
      provider: glue                # ou unity
      database: "vendas_curated"
      table_name: "clientes"
      description: "Tabela de clientes anonimizados"
      properties:
        owner: "data-engineering"
        classification: "internal"
      # Para Glue:
      region: "us-east-1"           # opcional
      # Para Unity:
      catalog: "main"               # Unity catalog name
```

### Comportamento

1. Após `loader.save(data)`, se `catalog` está configurado:
2. `create_database(database)` — cria o banco se não existir
3. `table_exists(database, table_name)` — verifica se tabela existe
4. Se não existe: `register_table(...)` cria a tabela
5. Se já existe: `register_table(...)` atualiza os metadados

---

## AWS Glue Data Catalog

```yaml
sinks:
  - name: resultado
    format: parquet
    path: "s3a://dataduct-curated/vendas/resultado/"
    partition_by: ["dt_referencia"]
    catalog:
      provider: glue
      database: "vendas_curated"
      table_name: "resultado_vendas"
      description: "Resultado das vendas processadas"
      region: "us-east-1"
```

### Parâmetros

| Parâmetro | Tipo | Default | Descrição |
|-----------|------|---------|-----------|
| `database` | str | — | Database no Glue |
| `table_name` | str | — | Nome da tabela |
| `description` | str | — | Descrição da tabela |
| `properties` | dict | `{}` | Propriedades extras da tabela |
| `region` | str | AWS default | Region do Glue |

### Schema automático

O `GlueCatalogProvider` extrai o schema automaticamente:
- De **Spark DataFrames**: via `df.schema.fields`
- De **pandas DataFrames**: via `df.dtypes`

### Instalação

```bash
pip install -r requirements-aws.txt
```

---

## Databricks Unity Catalog

```yaml
sinks:
  - name: resultado
    format: delta
    path: "s3a://bucket/delta/resultado/"
    catalog:
      provider: unity
      catalog: "main"           # Unity catalog name
      database: "vendas"
      table_name: "resultado_vendas"
      description: "Resultado de vendas"
```

### Parâmetros

| Parâmetro | Tipo | Default | Descrição |
|-----------|------|---------|-----------|
| `catalog` | str | `"main"` | Nome do Unity Catalog |
| `database` | str | — | Schema/database no Unity |
| `table_name` | str | — | Nome da tabela |
| `description` | str | — | Descrição da tabela |
| `properties` | dict | `{}` | Table properties (TBLPROPERTIES) |

### Requisitos

- Requer SparkSession ativa com acesso ao Unity Catalog configurado
- Usa Delta Lake como formato padrão
- A SparkSession deve ter o `spark.databricks.unityCatalog.enabled = true`

---

## Catalog ABC — Implementar Provider Customizado

```python
from typing import Any, Dict, List, Optional

from dataduct.services.catalog.base import CatalogProvider
from dataduct.services.catalog import register_catalog_provider


class IcebergCatalogProvider(CatalogProvider):
    def __init__(self, catalog_uri: str = None, **kwargs):
        self._catalog_uri = catalog_uri

    def register_table(
        self,
        path: str,
        database: str,
        table_name: str,
        data: Any = None,
        engine: Any = None,
        partition_by: Optional[List[str]] = None,
        description: Optional[str] = None,
        properties: Optional[Dict] = None,
    ) -> None:
        spark = engine.session
        full_name = f"{database}.{table_name}"
        spark.sql(f"""
            CREATE TABLE IF NOT EXISTS {full_name}
            USING iceberg
            LOCATION '{path}'
        """)

    def drop_table(self, database: str, table_name: str) -> None:
        ...

    def table_exists(self, database: str, table_name: str) -> bool:
        ...

    def create_database(self, database: str, description: Optional[str] = None) -> None:
        ...


register_catalog_provider("iceberg", IcebergCatalogProvider)
```

Uso:
```yaml
catalog:
  provider: iceberg
  catalog_uri: "http://iceberg-rest:8181"
  database: "analytics"
  table_name: "minha_tabela"
```

---

## Combinando Masking + Catalog

Exemplo completo de pipeline de dados PII:

```yaml
type: python
engine: spark

sources:
  - name: clientes_raw
    format: parquet
    path: "s3a://dataduct-raw/clientes/"
    masking:
      provider: hash
      columns:
        - column: cpf
          algorithm: sha256
        - column: email
          algorithm: sha256
        - column: telefone
          algorithm: sha256

sinks:
  - name: clientes_curated
    format: parquet
    path: "s3a://dataduct-curated/clientes/"
    mode: overwrite
    partition_by: ["dt_referencia"]
    catalog:
      provider: glue
      database: "dominio_curated"
      table_name: "clientes"
      description: "Clientes com dados PII anonimizados"
      region: "us-east-1"
```

**job.py**:
```python
from dataduct.core.job.base import Job


class ClientesCuratedJob(Job):
    def run(self):
        # self.sources.clientes_raw já está mascarado (cpf, email, telefone = hashes)
        resultado = self.engine.execute_sql("""
            SELECT *
            FROM clientes_raw
            WHERE dt_referencia = '{{ dt_referencia }}'
        """)
        # Após .save(), o Glue Catalog é atualizado automaticamente
        self.sinks.clientes_curated.save(resultado)
```

---

## Unity Catalog OSS (REST API)

Alternativa ao `unity` que funciona com o servidor open-source do Unity Catalog via REST, sem exigir Spark.

```yaml
sinks:
  - name: resultado
    format: parquet
    path: "s3a://bucket/parquet/resultado/"
    catalog:
      provider: unity_rest
      host: "http://localhost:8080"
      token: "seu_token"       # opcional
      catalog_name: "main"
      database: "vendas"
      table_name: "resultado_vendas"
      description: "Resultado de vendas"
      # Schema explícito (opcional — inferido do Parquet se omitido)
      schema:
        - name: id
          type: LONG
        - name: valor
          type: DOUBLE
        - name: dt_referencia
          type: DATE
```

### Parâmetros

| Parâmetro | Tipo | Default | Descrição |
|-----------|------|---------|-----------|
| `host` | str | — | URL do servidor Unity Catalog OSS |
| `token` | str | `None` | Bearer token de autenticação |
| `catalog_name` | str | `"main"` | Nome do catálogo |
| `database` | str | — | Schema/database |
| `table_name` | str | — | Nome da tabela |
| `table_format` | str | `"parquet"` | Formato da tabela |
| `schema` | list | `None` | Schema explícito (priority 1) |

### Resolução de schema (priority order)

1. `schema` explícito no config
2. Leitura do header do arquivo Parquet gerado (via PyArrow)
3. Introspecção do dataset em memória (Spark DF, pandas DF, DuckDB relation)
4. Sem schema (tabela registrada sem colunas)

### Instalação

```bash
pip install dataduct[unity]
# ou: pip install requests pyarrow
```

---

## Estrutura do Módulo services/

```
dataduct/services/
├── __init__.py
├── credentials.py              # Resolução de credenciais (env vars)
├── masking/
│   ├── __init__.py             # apply_masking(), get/register provider
│   ├── base.py                 # MaskingProvider ABC
│   └── hash.py                 # HashMaskingProvider (sha256, md5)
└── catalog/
    ├── __init__.py             # apply_catalog(), get/register provider
    ├── base.py                 # CatalogProvider ABC
    ├── glue.py                 # GlueCatalogProvider (boto3)
    ├── unity.py                # UnityCatalogProvider (Spark SQL)
    ├── unity_rest.py           # UnityCatalogRestProvider (REST API)
    ├── schema_inference.py     # ColumnInfo + inferência via PyArrow
    └── table_format.py         # TableFormat enum (parquet/delta/iceberg/hudi)
```
